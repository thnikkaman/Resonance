# Resonance Alpha 3.0

A SwiftUI iPhone music-player prototype with Finder/Files transfer, recursive indexing, SQLite storage, FLAC/Vorbis metadata parsing, embedded artwork, playback queues, favorites, smart collections, playlists, persistent metadata edits, and artist artwork overrides.

## Install without erasing the library

Install Alpha 3.0 directly over Alpha 2.9 using the same bundle identifier and signing configuration. Do not delete the installed app first. Deleting it removes the app's Documents folder, SQLite database, favorites, recent-play history, playlists, metadata overrides, artist artwork overrides, playback bookmarks, and imported music.

## Requested Now Playing revision

- Removed the tap-to-open full-screen artwork behavior.
- The large Now Playing artwork is now a horizontal page carousel.
- The current artwork follows the finger during a swipe.
- Swipe left to reveal and select the next track.
- Swipe right to reveal and select the previous track.
- A partial swipe snaps back without changing playback.
- The title, artist, album, duration, controls, and scrubber update only after the new artwork page is selected.
- The progress scrubber remains outside the artwork pager and continues to handle seeking independently.

## New phase: playback bookmarks

- A bookmark button appears on the Now Playing secondary-control row.
- Add a bookmark at the current track position.
- Saved positions persist after closing or upgrading Resonance.
- Tap a saved bookmark to seek directly to it.
- Swipe left on a bookmark to delete it.
- A badge shows how many bookmarks are saved for the current track.
- Duplicate bookmarks within two seconds of an existing bookmark are ignored.

## New phase: reorder the playback queue

- Open Playback Queue and press Edit.
- Drag upcoming tracks into a different order.
- The current track remains fixed at the top.
- Reordering preserves the newly selected upcoming order for automatic track advancement.
- Existing tap-to-play, swipe-to-delete, and Clear Upcoming Tracks actions remain available.

## Hexadecimal scale alignment

- The sixteen 0–F marks remain evenly spaced.
- Each mark represents the high-nibble positions 00, 10, 20 through F0.
- The final F remains directly above the F0 slider position rather than the FF endpoint.

## Suggested tests

1. Install Alpha 3.0 over Alpha 2.9 and verify the existing library, playlists, favorites, artwork overrides, and metadata edits remain.
2. On Now Playing, slowly drag the artwork left and right and confirm the current and adjacent covers visibly move together.
3. Release a short drag and confirm the artwork snaps back without changing tracks.
4. Complete a swipe and confirm the newly centered artwork matches the track that begins playing.
5. Confirm tapping artwork no longer opens a full-screen viewer.
6. Add multiple bookmarks to one track, restart Resonance, and verify they persist.
7. Tap a bookmark and confirm the player seeks to that exact position.
8. Open the queue, press Edit, reorder upcoming tracks, and confirm automatic playback follows the new order.
9. Confirm the Settings F label remains aligned above F0.

## Compatibility baseline

Alpha 3.0 preserves the successful Alpha 2.1–2.9 compatibility fixes, including the current-SDK `MetadataReader.swift` corrections, asynchronous AV metadata loading, Swift 6-safe `AVAudioPlayerDelegate` proxying, actor-safe database schema creation, safe Core Foundation ownership, Finder File Sharing, document-relative paths, and the resolved orientation and `withUnsafeBytes` warnings.

The locally applied Alpha 2.7 `SmartLibraryViews.swift` correction remains included. New `Section` declarations in this build also use explicit `content`, `header`, and `footer` closures to avoid the same current-SDK initializer errors.

## Mac preflight build

Before signing for the iPhone 17 Pro, run `Tools/PreflightBuild.sh` from Terminal on the Mac. It performs a clean unsigned simulator build so current-SDK SwiftUI and Swift-concurrency compiler errors are caught before device installation.
