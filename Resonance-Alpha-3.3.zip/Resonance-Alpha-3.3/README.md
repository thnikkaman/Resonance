# Resonance Alpha 3.3

Version 0.3.3, build 33.

## Explicit surround downmix

Alpha 3.3 replaces AVAudioMixerNode's implicit multichannel conversion with an Apple Matrix Mixer audio unit and an explicit channel matrix.

For a six-channel FLAC source using the standard FLAC channel order:

- Front left routes only to stereo left.
- Front right routes only to stereo right.
- Center routes equally to stereo left and right.
- LFE/subwoofer routes equally to stereo left and right.
- Rear left routes only to stereo left.
- Rear right routes only to stereo right.

Center and rear channels use a -3 dB coefficient and LFE uses a -6 dB coefficient. The stereo output retains 50% summing headroom to reduce clipping when several full-scale channels are active at once.

## New diagnostics phase

Settings > Playback now includes:

- Active channel routing text from the real playback graph.
- A 5.1 Routing Monitor showing each channel assignment.
- A headroom indicator.
- Clear fallback status if the explicit matrix cannot be instantiated.

## Testing

1. Install over Alpha 3.2 using the same bundle identifier. Do not delete the installed app.
2. Play a known 5.1 FLAC channel-identification file.
3. Confirm rear-left is audible only on the left and rear-right only on the right.
4. Confirm center and LFE are audible through both outputs.
5. Open Settings > Playback and confirm Active channel routing starts with `Explicit 5.1`.
6. Test a normal stereo file and confirm the status changes to native stereo routing.
7. Test a 5.1 album transition to confirm gapless preload still works between tracks with matching channel counts.

## Compile preflight

Run `Tools/PreflightBuild.sh` on the Mac before device installation. It performs a clean unsigned simulator build with strict concurrency checking.
