# Resonance Alpha 3.7.2 — Post-start Playback Crash Hotfix

Version: **0.3.7.2**  
Build: **39**

Install directly over Alpha 3.7.1 with the same bundle identifier and signing team. Do not delete the installed app first, because uninstalling removes the local library, playlists, metadata overrides, credentials, and cached remote catalog.

## Observed problem

- Local and remote playback reported successful startup and then the app terminated.
- The persisted Alpha 3.7.1 startup diagnostic therefore placed the failure after backend creation and initial playback startup.
- The remaining shared asynchronous boundary was Lock Screen artwork delivery plus the first playback status timer tick.

## Focused change

Alpha 3.7.2 keeps the Alpha 3.7.1 backend rollback and changes one post-start behavior:

- Lock Screen artwork is decoded and resized to a maximum 1024-point dimension on the main actor before it is supplied to MediaPlayer.
- The `MPMediaItemArtwork` request handler now returns an already-prepared image and performs no UIKit drawing, decoding, or thumbnail creation.
- A new **Show album artwork on Lock Screen** switch provides an immediate compatibility fallback without removing in-app artwork.

Local gapless scheduling, explicit 5.1 routing, legacy local fallback, remote single-item playback, queue behavior, metadata, and library state are otherwise preserved.

## Error reporting

Settings now includes **Reported Errors**:

- The newest reported error is displayed in red.
- Up to 30 timestamped errors are retained across launches.
- Errors can be copied as plain text or cleared.
- Playback, audio-session, decoder, remote-stream, remote-catalog, and library-scanner failures feed the log when the app receives an error rather than being terminated by iOS.

Settings also shows two persisted playback diagnostics:

- **Last playback startup stage**
- **Last playback runtime stage**

The runtime stage distinguishes Lock Screen publication from the first playback timer tick. If the app still terminates, reopen it and report both values plus the red error text.

## Compile compatibility carried forward

- `RemoteLibraryStore.swift` wraps the joined normalized artist value in `String(...).lowercased()`.
- Alpha 3.6 `nonisolated static` fixes remain present.
- Optional Subsonic `starred`, `created`, and `played` fields remain present.
- All previous MetadataReader, SwiftUI Section, actor-isolation, SQLite, Core Foundation, and PlayerViews fixes remain present.

## Validation performed here

- Every Swift source parsed in Swift 6 mode.
- `Info.plist` and the Xcode project passed `plutil` validation.
- The regression suite checked previous compatibility fixes and new hotfix invariants.
- The final ZIP passed an archive integrity test.

A definitive runtime result requires a current-Xcode build and playback test on the physical iPhone.
