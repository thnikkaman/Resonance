# Alpha 3.7.2 Playback Hotfix Validation

## Reproduction

- Device: iPhone 17 Pro, latest iOS
- Previous build: Alpha 3.7.1
- Local symptom: selecting a local track terminated the app after Settings persisted “Local playback started successfully.”
- Remote symptom: selecting a remote track also terminated the app.
- Affected layer: shared post-start playback integration.

## Evidence

The startup marker is written after:

1. Backend preparation
2. Starting playback
3. Track-start history callback
4. Initial Now Playing metadata publication
5. Scheduling the playback status task

The crash therefore occurred asynchronously after startup returned. The dynamic `MPMediaItemArtwork` handler was shared by local and remote playback and previously performed UIKit thumbnail work when MediaPlayer requested an image.

## Change contract

- Lever: eliminate dynamic image processing from the MediaPlayer artwork callback.
- Expected result: playback remains alive after the successful startup marker.
- Preserved behavior: local/remote queue semantics, seeking, background audio, local gapless playback, 5.1 matrix, artwork presence, metadata, favorites, playlists, and history.
- New risk: Lock Screen artwork may be downscaled to 1024 points.
- Rollback: disable **Show album artwork on Lock Screen**, or restore the prior `updateNowPlaying` artwork block.

## Physical-device test sequence

1. Open Settings and clear Reported Errors.
2. Leave **Show album artwork on Lock Screen** enabled.
3. Play one local stereo file.
4. Reopen Settings and verify:
   - Startup stage: `Local playback started successfully`
   - Runtime stage: `First playback timer tick completed`
5. Play a local 5.1 FLAC and verify explicit routing is unchanged.
6. Play a Navidrome track and verify the remote player remains open.
7. Lock the phone and confirm title, artist, album, elapsed time, and artwork appear.
8. If a crash remains, disable Lock Screen artwork and repeat local and remote playback.
9. Copy the red error history and report both persisted playback stages.

## Pass conditions

- No process termination when starting local or remote playback.
- The first playback timer tick completes.
- Lock Screen artwork does not block or terminate playback.
- Disabling Lock Screen artwork removes only Lock Screen artwork.
- Local 5.1 routing, gapless preload, remote seeking, and queue controls remain functional.
