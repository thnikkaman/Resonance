# Resonance Alpha 2.4

A SwiftUI iPhone music-player prototype with Finder/Files transfer, recursive folder indexing, SQLite storage, FLAC/Vorbis metadata parsing, embedded artwork, playback queues, favorites, smart collections, and persistent playlists.

## Install without erasing the library

Install Alpha 2.4 directly over Alpha 2.3 using the same bundle identifier and signing configuration. Do not delete the installed app first. Deleting it removes the app's Documents folder, SQLite database, favorites, recent-play history, playlists, and imported music.

## New and fixed in Alpha 2.4

### Playlist manager is now a primary Library destination

- A Playlists button appears at the top of the main Library screen.
- Playlists have been removed from the Browse Library By picker.
- The playlist manager has its own search field and Add a Playlist controls.
- Empty add-to-playlist actions now say Add a Playlist and open the playlist workflow.

### Reliable album and track additions

- Adding a track, current song, or complete album opens a dedicated playlist picker.
- One tap on a playlist adds the requested tracks and dismisses the picker.
- Complete albums are saved in one persistent update instead of one update per track.
- Duplicate tracks are ignored.

### Playlist artwork

- Playlist rows display artwork resolved from any track in the playlist.
- The playlist detail header displays album artwork instead of a generic placeholder when artwork is available.
- Playlist track rows inherit artwork from another track on the same album when needed.

### Playlist deletion

- Swipe left or press and hold a playlist in the manager to delete it.
- Open a playlist and use Playlist Actions > Delete Playlist.
- Deletion requires confirmation and never deletes audio files.

### Shared-folder scanning

- Removed the 20-second periodic scan.
- Resonance scans on first launch, whenever the app returns to the foreground, after a Files/Finder import, or when the manual Scan button is pressed.

## Finder transfer workflow

1. Launch Resonance once so the `Resonance Music` folder exists.
2. Connect the iPhone to the Mac.
3. Select the iPhone in Finder and open **Files**.
4. Open **Resonance Alpha > Resonance Music**.
5. Drop in audio files, artist folders, or complete folder trees.
6. Bring Resonance to the foreground or press the scan button.

## Suggested Alpha 2.4 tests

1. Install directly over Alpha 2.3 and confirm existing music and playlists remain.
2. Verify the Playlists shortcut is visible at the top of Library.
3. Confirm Playlists no longer appears under Browse Library By.
4. With no playlists, choose Add a Playlist from a track or album action and create one.
5. Add a complete album and verify one tap adds it and closes the picker.
6. Confirm artwork appears in the playlist manager, playlist header, and playlist track rows.
7. Delete a playlist by swipe/press-and-hold and from inside the playlist; confirm music files remain.
8. Leave the app open for more than 20 seconds and verify no periodic scan begins.
9. Add music through Finder, return to Resonance, and verify the foreground scan indexes it.

## Compatibility baseline

Alpha 2.4 preserves the successful Alpha 2.1–2.3 compatibility fixes, including the current-SDK MetadataReader changes, asynchronous AV metadata loading, Swift 6-safe AVAudioPlayerDelegate proxying, actor-safe database schema creation, safe Core Foundation ownership, Finder File Sharing, document-relative paths, and the resolved orientation and withUnsafeBytes warnings.
