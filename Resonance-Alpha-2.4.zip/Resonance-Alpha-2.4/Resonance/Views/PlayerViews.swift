import SwiftUI

struct NowPlayingView: View {
    @EnvironmentObject private var player: PlayerController
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var settings: AppSettings
    @State private var showingQueue = false
    @State private var showingArtwork = false
    @State private var showingPlaylistPicker = false
    let openLibrary: () -> Void

    private var currentTrackIsFavorite: Bool {
        guard let track = player.currentTrack else { return false }
        return library.isFavorite(track)
    }

    var body: some View {
        VStack(spacing: 16) {
            Spacer(minLength: 4)

            Button {
                if player.currentTrack != nil { showingArtwork = true }
            } label: {
                ArtworkView(
                    data: player.currentTrack.flatMap { player.artworkData(for: $0) },
                    embedded: player.currentTrack.map { player.artworkIsEmbedded(for: $0) } ?? true,
                    size: 286
                )
                .shadow(radius: 18, y: 8)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Show full-screen album artwork")

            VStack(spacing: 5) {
                Text(player.currentTrack?.title ?? "Nothing Playing")
                    .font(.title2.bold())
                    .lineLimit(1)
                Text(player.currentTrack.map { "\($0.artist) — \($0.album)" } ?? "Choose music from your library")
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }

            TrackScrubber()
                .frame(maxWidth: 320)

            HStack(spacing: 23) {
                Button(action: player.previous) {
                    Image(systemName: "backward.fill")
                }
                .accessibilityLabel("Previous track")

                Button { player.skip(by: -15) } label: {
                    Image(systemName: "gobackward.15")
                }
                .accessibilityLabel("Rewind 15 seconds")

                Button(action: player.toggle) {
                    Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 42))
                }
                .accessibilityLabel(player.isPlaying ? "Pause" : "Play")

                Button { player.skip(by: 15) } label: {
                    Image(systemName: "goforward.15")
                }
                .accessibilityLabel("Jump ahead 15 seconds")

                Button(action: player.next) {
                    Image(systemName: "forward.fill")
                }
                .accessibilityLabel("Next track")
            }
            .font(.title2)

            HStack(spacing: 28) {
                Button {
                    if let track = player.currentTrack { library.toggleFavorite(track) }
                } label: {
                    Image(systemName: currentTrackIsFavorite ? "heart.fill" : "heart")
                        .foregroundStyle(currentTrackIsFavorite ? settings.accentColor : .secondary)
                }
                .disabled(player.currentTrack == nil)
                .accessibilityLabel(currentTrackIsFavorite ? "Remove from favorites" : "Add to favorites")

                Button(action: player.toggleShuffle) {
                    Image(systemName: "shuffle")
                        .foregroundStyle(player.shuffleEnabled ? settings.accentColor : .secondary)
                }
                .accessibilityLabel(player.shuffleEnabled ? "Turn shuffle off" : "Turn shuffle on")

                Button(action: player.cycleRepeatMode) {
                    Image(systemName: player.repeatMode.systemImage)
                        .foregroundStyle(player.repeatMode == .off ? Color.secondary : settings.accentColor)
                        .overlay(alignment: .topTrailing) {
                            if player.repeatMode == .all {
                                Circle()
                                    .fill(settings.accentColor)
                                    .frame(width: 5, height: 5)
                                    .offset(x: 3, y: -3)
                            }
                        }
                }
                .accessibilityLabel(player.repeatMode.rawValue)

                Button { showingQueue = true } label: {
                    Image(systemName: "list.bullet")
                }
                .accessibilityLabel("Show playback queue")

                Menu {
                    ForEach(SleepTimerOption.allCases) { option in
                        Button {
                            player.setSleepTimer(option)
                        } label: {
                            if option == player.sleepTimerOption {
                                Label(option.rawValue, systemImage: "checkmark")
                            } else {
                                Text(option.rawValue)
                            }
                        }
                    }
                } label: {
                    Image(systemName: player.sleepTimerOption == .off ? "moon.zzz" : "moon.zzz.fill")
                        .foregroundStyle(player.sleepTimerOption == .off ? Color.secondary : settings.accentColor)
                }
                .accessibilityLabel("Sleep timer: \(player.sleepTimerLabel)")
            }
            .font(.title3)

            HStack(spacing: 10) {
                Image(systemName: "speaker.fill")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Slider(value: $player.volume, in: 0...1)
                Image(systemName: "speaker.wave.3.fill")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: 300)

            if player.sleepTimerOption != .off {
                Label("Sleep timer: \(player.sleepTimerLabel)", systemImage: "moon.zzz.fill")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            HStack {
                Button(action: openLibrary) {
                    HStack(spacing: 6) {
                        Text("Browse Library")
                        Image(systemName: "chevron.right")
                    }
                }
                .buttonStyle(.bordered)

                Button(action: player.stop) {
                    Label("Stop", systemImage: "stop.fill")
                }
                .buttonStyle(.bordered)
            }
            Spacer(minLength: 4)
        }
        .padding(24)
        .navigationTitle("Now Playing")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button(action: openLibrary) {
                    Label("Library", systemImage: "chevron.left")
                }
            }
            ToolbarItemGroup(placement: .topBarTrailing) {
                if player.currentTrack != nil {
                    Button {
                        showingPlaylistPicker = true
                    } label: {
                        Image(systemName: "text.badge.plus")
                    }
                    .accessibilityLabel(library.playlists.isEmpty ? "Add a playlist" : "Add current track to playlist")
                }

                Button { showingQueue = true } label: {
                    Label("Queue", systemImage: "list.bullet")
                }
            }
        }
        .sheet(isPresented: $showingQueue) {
            PlaybackQueueView()
                .presentationDetents([.medium, .large])
        }
        .sheet(isPresented: $showingPlaylistPicker) {
            if let track = player.currentTrack {
                PlaylistPickerSheet(tracks: [track])
                    .presentationDetents([.medium, .large])
            }
        }
        .fullScreenCover(isPresented: $showingArtwork) {
            FullScreenArtworkView()
        }
        .contentShape(Rectangle())
        .gesture(
            DragGesture(minimumDistance: 45)
                .onEnded { value in
                    if value.startLocation.x < 36 && value.translation.width > 70 {
                        openLibrary()
                    }
                }
        )
    }
}

private struct TrackScrubber: View {
    @EnvironmentObject private var player: PlayerController
    @EnvironmentObject private var settings: AppSettings
    @State private var previewTime: Double?
    @State private var fingerX: CGFloat = 0

    private var displayedTime: Double { previewTime ?? player.elapsed }
    private var isScrubbing: Bool { previewTime != nil }

    var body: some View {
        VStack(spacing: 0) {
            GeometryReader { proxy in
                let width = max(proxy.size.width, 1)
                let duration = max(player.duration, 1)
                let ratio = min(max(displayedTime / duration, 0), 1)
                let thumbX = width * ratio
                let bubbleWidth: CGFloat = 66
                let bubbleX = min(max(0, fingerX - bubbleWidth / 2), max(0, width - bubbleWidth))

                ZStack(alignment: .topLeading) {
                    if isScrubbing {
                        Text(formatScrubTime(displayedTime))
                            .font(.caption2.monospacedDigit().weight(.semibold))
                            .foregroundStyle(settings.contrastingAccentTextColor)
                            .frame(width: bubbleWidth)
                            .padding(.vertical, 5)
                            .background(settings.accentColor, in: Capsule())
                            .offset(x: bubbleX, y: 0)
                    }

                    Capsule()
                        .fill(.secondary.opacity(0.28))
                        .frame(height: 4)
                        .offset(y: 38)

                    Capsule()
                        .fill(settings.accentColor)
                        .frame(width: max(4, thumbX), height: 4)
                        .offset(y: 38)

                    Circle()
                        .fill(settings.accentColor)
                        .frame(width: isScrubbing ? 22 : 16, height: isScrubbing ? 22 : 16)
                        .shadow(radius: isScrubbing ? 3 : 1)
                        .offset(x: min(max(0, thumbX - (isScrubbing ? 11 : 8)), width - (isScrubbing ? 22 : 16)), y: isScrubbing ? 29 : 32)
                        .animation(.easeOut(duration: 0.12), value: isScrubbing)
                }
                .frame(width: width, height: 58)
                .contentShape(Rectangle())
                .highPriorityGesture(
                    DragGesture(minimumDistance: 0, coordinateSpace: .local)
                        .onChanged { value in
                            guard player.currentTrack != nil else { return }
                            fingerX = min(max(0, value.location.x), width)
                            // A drag covering 80% of the visible bar reaches the full track.
                            let normalized = min(max(fingerX / max(1, width * 0.8), 0), 1)
                            previewTime = normalized * duration
                        }
                        .onEnded { _ in
                            guard let previewTime else { return }
                            player.seek(to: previewTime)
                            self.previewTime = nil
                        }
                )
                .accessibilityElement(children: .ignore)
                .accessibilityLabel("Track position")
                .accessibilityValue(formatScrubTime(displayedTime))
                .accessibilityAdjustableAction { direction in
                    switch direction {
                    case .increment: player.skip(by: 15)
                    case .decrement: player.skip(by: -15)
                    @unknown default: break
                    }
                }
            }
            .frame(height: 58)

            HStack {
                Text(format(displayedTime))
                Spacer()
                Text("−\(format(max(0, player.duration - displayedTime)))")
            }
            .font(.caption.monospacedDigit())
            .foregroundStyle(.secondary)
        }
        .opacity(player.currentTrack == nil ? 0.45 : 1)
    }

    private func formatScrubTime(_ seconds: Double) -> String {
        guard seconds.isFinite, seconds >= 0 else { return "0:00" }
        return String(format: "%d:%02d", Int(seconds) / 60, Int(seconds) % 60)
    }
}

private struct FullScreenArtworkView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var player: PlayerController
    @EnvironmentObject private var settings: AppSettings

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            if let track = player.currentTrack,
               let data = player.artworkData(for: track),
               let image = UIImage(data: data) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .ignoresSafeArea(edges: .horizontal)
            } else {
                Image(systemName: "music.note")
                    .font(.system(size: 100))
                    .foregroundStyle(.secondary)
            }

            VStack {
                HStack {
                    Spacer()
                    Button { dismiss() } label: {
                        Image(systemName: "xmark.circle.fill")
                            .font(.largeTitle)
                            .symbolRenderingMode(.palette)
                            .foregroundStyle(settings.accentColor, .black.opacity(0.65))
                    }
                    .accessibilityLabel("Close artwork")
                }
                .padding()
                Spacer()
                if let track = player.currentTrack {
                    VStack(spacing: 4) {
                        Text(track.title).font(.headline)
                        Text(track.artist).font(.subheadline)
                    }
                    .foregroundStyle(.white)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 12)
                    .background(.black.opacity(0.65), in: Capsule())
                    .padding(.bottom, 28)
                }
            }
        }
    }
}

struct PlaybackQueueView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var player: PlayerController

    var body: some View {
        NavigationStack {
            List {
                if let current = player.currentTrack {
                    Section("Now Playing") {
                        queueRow(current, isCurrent: true)
                    }
                }

                Section("Up Next") {
                    if player.upcomingTracks.isEmpty {
                        ContentUnavailableView(
                            "Queue Is Empty",
                            systemImage: "text.line.last.and.arrowtriangle.forward",
                            description: Text("Choose an album or song to create a new playback queue.")
                        )
                    } else {
                        ForEach(player.upcomingTracks) { track in
                            Button {
                                player.playQueueItem(track)
                            } label: {
                                queueRow(track, isCurrent: false)
                            }
                            .buttonStyle(.plain)
                        }
                        .onDelete(perform: player.removeUpcoming)

                        Button(role: .destructive) {
                            player.clearUpcoming()
                        } label: {
                            Label("Clear Upcoming Tracks", systemImage: "trash")
                        }
                    }
                }
            }
            .navigationTitle("Playback Queue")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }

    private func queueRow(_ track: Track, isCurrent: Bool) -> some View {
        HStack(spacing: 10) {
            ArtworkView(
                data: player.artworkData(for: track),
                embedded: player.artworkIsEmbedded(for: track),
                size: 44
            )
            if isCurrent {
                PlayingTrackVisualizer(track: track)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(track.title)
                    .font(.subheadline.weight(isCurrent ? .semibold : .regular))
                    .lineLimit(1)
                Text("\(track.artist) — \(track.album)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer()
            if isCurrent {
                Image(systemName: player.isPlaying ? "speaker.wave.2.fill" : "pause.fill")
                    .foregroundStyle(.tint)
            }
        }
        .contentShape(Rectangle())
    }
}

struct MiniPlayerView: View {
    @EnvironmentObject private var player: PlayerController
    let openNowPlaying: () -> Void

    var body: some View {
        HStack(spacing: 10) {
            Button(action: openNowPlaying) {
                HStack(spacing: 10) {
                    if let track = player.currentTrack {
                        ArtworkView(
                            data: player.artworkData(for: track),
                            embedded: player.artworkIsEmbedded(for: track),
                            size: 42
                        )
                        PlayingTrackVisualizer(track: track)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(player.currentTrack?.title ?? "")
                            .font(.subheadline.weight(.semibold))
                            .lineLimit(1)
                        Text(player.currentTrack?.artist ?? "")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                }
            }
            .buttonStyle(.plain)

            Spacer()
            Button(action: player.toggle) {
                Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
            }
            Button(action: player.next) {
                Image(systemName: "forward.fill")
            }
        }
        .padding(8)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14))
        .shadow(radius: 5, y: 2)
    }
}
