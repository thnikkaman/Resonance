import SwiftUI

struct RootView: View {
    @EnvironmentObject private var player: PlayerController

    var body: some View {
        TabView {
            NavigationStack { NowPlayingView() }
                .tabItem { Label("Playing", systemImage: "music.note") }
            NavigationStack { LibraryView() }
                .tabItem { Label("Library", systemImage: "square.stack") }
            NavigationStack { SettingsView() }
                .tabItem { Label("Settings", systemImage: "gearshape") }
        }
        .safeAreaInset(edge: .bottom) {
            if player.currentTrack != nil { MiniPlayerView().padding(.horizontal, 8) }
        }
    }
}
