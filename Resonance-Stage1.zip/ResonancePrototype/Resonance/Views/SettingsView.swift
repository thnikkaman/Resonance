import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var library: LibraryStore
    private let palette = ["A855F7", "3B82F6", "14B8A6", "22C55E", "EAB308", "F97316", "EF4444"]

    var body: some View {
        Form {
            Section("Appearance") {
                Picker("Theme", selection: $settings.appearance) {
                    Text("System").tag("system"); Text("Light").tag("light"); Text("Dark").tag("dark")
                }.pickerStyle(.segmented)
                HStack {
                    ForEach(palette, id: \.self) { hex in
                        Button { settings.accentHex = hex } label: {
                            Circle().fill(Color(hex: hex) ?? .purple).frame(width: 30, height: 30)
                                .overlay { if settings.accentHex == hex { Image(systemName: "checkmark").foregroundStyle(.white) } }
                        }.buttonStyle(.plain)
                    }
                }
                TextField("Hex color", text: $settings.accentHex).textInputAutocapitalization(.characters)
                Toggle("Red outline for cached artwork", isOn: $settings.showArtworkWarning)
            }
            Section("Playback prototype") {
                Toggle("Preload next track", isOn: $settings.preloadNextTrack)
                LabeledContent("Local buffer", value: "\(Int(settings.localBufferMB)) MB")
                Slider(value: $settings.localBufferMB, in: 10...250, step: 10)
                Text("Stage 1 stores this preference. The low-level gapless engine is planned for Stage 2.").font(.caption).foregroundStyle(.secondary)
            }
            Section("Remote library placeholder") {
                TextField("Domain or IP address", text: .constant(""))
                TextField("Port", text: .constant(""))
                LabeledContent("Streaming buffer", value: "\(Int(settings.networkBufferMB)) MB")
                Slider(value: $settings.networkBufferMB, in: 10...250, step: 10)
                Text("Tailscale creates network reachability but does not prescribe an audio-server port. The server software will determine the default port.").font(.caption).foregroundStyle(.secondary)
            }
            Section("Library") {
                Button("Restore demo library") { Task { await library.resetDemoLibrary() } }
            }
            Section("Prototype status") {
                Label("Local import and indexing", systemImage: "checkmark.circle.fill")
                Label("Artist → albums → numbered tracks", systemImage: "checkmark.circle.fill")
                Label("Basic playback and lock-screen controls", systemImage: "checkmark.circle.fill")
                Label("Advanced gapless, metadata writing, artwork search and remote server", systemImage: "clock")
            }
        }.navigationTitle("Settings")
    }
}
