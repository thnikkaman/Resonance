import SwiftUI

struct NowPlayingView: View {
    @EnvironmentObject private var player: PlayerController

    var body: some View {
        VStack(spacing: 24) {
            Spacer()
            ArtworkView(data: player.currentTrack?.artworkData, embedded: player.currentTrack?.artworkIsEmbedded ?? true, size: 310)
                .shadow(radius: 18, y: 8)
            VStack(spacing: 5) {
                Text(player.currentTrack?.title ?? "Nothing Playing").font(.title2.bold()).lineLimit(1)
                Text(player.currentTrack.map { "\($0.artist) — \($0.album)" } ?? "Choose music from your library")
                    .foregroundStyle(.secondary).lineLimit(1)
            }
            VStack {
                Slider(value: Binding(get: { player.elapsed }, set: { player.seek(to: $0) }), in: 0...max(player.duration, 1))
                HStack { Text(format(player.elapsed)); Spacer(); Text("−\(format(max(0, player.duration-player.elapsed)))") }
                    .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
            }
            HStack(spacing: 42) {
                Button(action: player.previous) { Image(systemName: "backward.fill") }
                Button(action: player.toggle) { Image(systemName: player.isPlaying ? "pause.fill" : "play.fill").font(.system(size: 42)) }
                Button(action: player.next) { Image(systemName: "forward.fill") }
            }.font(.title2)
            Button(action: player.stop) { Label("Stop", systemImage: "stop.fill") }.buttonStyle(.bordered)
            Spacer()
        }
        .padding(24)
        .navigationTitle("Now Playing")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct MiniPlayerView: View {
    @EnvironmentObject private var player: PlayerController
    var body: some View {
        HStack(spacing: 10) {
            ArtworkView(data: player.currentTrack?.artworkData, embedded: player.currentTrack?.artworkIsEmbedded ?? true, size: 42)
            VStack(alignment: .leading) { Text(player.currentTrack?.title ?? "").font(.subheadline.weight(.semibold)); Text(player.currentTrack?.artist ?? "").font(.caption).foregroundStyle(.secondary) }
            Spacer()
            Button(action: player.toggle) { Image(systemName: player.isPlaying ? "pause.fill" : "play.fill") }
            Button(action: player.next) { Image(systemName: "forward.fill") }
        }
        .padding(8)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14))
    }
}
