import SwiftUI

@MainActor
final class AppSettings: ObservableObject {
    @AppStorage("appearance") private var appearanceRaw = "system"
    @AppStorage("accentHex") var accentHex = "A855F7"
    @AppStorage("albumLayout") private var albumLayoutRaw = AlbumLayout.grid.rawValue
    @AppStorage("showArtworkWarning") var showArtworkWarning = true
    @AppStorage("preloadNextTrack") var preloadNextTrack = true
    @AppStorage("localBufferMB") var localBufferMB = 64.0
    @AppStorage("networkBufferMB") var networkBufferMB = 128.0

    var appearance: String {
        get { appearanceRaw }
        set { appearanceRaw = newValue; objectWillChange.send() }
    }

    var albumLayout: AlbumLayout {
        get { AlbumLayout(rawValue: albumLayoutRaw) ?? .grid }
        set { albumLayoutRaw = newValue.rawValue; objectWillChange.send() }
    }

    var colorScheme: ColorScheme? {
        switch appearanceRaw {
        case "light": .light
        case "dark": .dark
        default: nil
        }
    }

    var accentColor: Color { Color(hex: accentHex) ?? .purple }
}

extension Color {
    init?(hex: String) {
        let cleaned = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        guard cleaned.count == 6, let value = UInt64(cleaned, radix: 16) else { return nil }
        self.init(
            .sRGB,
            red: Double((value >> 16) & 0xFF) / 255,
            green: Double((value >> 8) & 0xFF) / 255,
            blue: Double(value & 0xFF) / 255,
            opacity: 1
        )
    }
}
