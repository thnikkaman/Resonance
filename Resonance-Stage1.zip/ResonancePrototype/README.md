# Resonance — Stage 1 iPhone Prototype

A SwiftUI prototype for a local-first high-quality music player.

## Included now

- SwiftUI tab-based interface with light, dark, and system appearance
- Configurable accent hex and preset palette
- Recursive import from the iOS Files picker
- Copies imported audio into the app's Documents/Imported Music folder
- AVFoundation metadata reading and basic playback
- SQLite library persistence and indexing
- Browse by Artist, Album Artist, Album, or Song
- Artist pages display albums rather than one flattened song list
- Album tracks sort by disc number and track number
- Grid, compact-list, and large-list album layouts
- Play, pause, previous, next, seek, and stop controls
- Background audio mode and lock-screen transport commands
- Preferences for local/network buffers up to 250 MB
- Red 1 px border behavior for non-embedded artwork (data model/UI included)
- Demo library so the interface can be explored before importing files

## Deliberately deferred

- Custom low-level gapless/preloading engine
- Remote Tailscale server protocol and scanner
- Background folder watching
- Online artwork repository integration and artwork choice screen
- Metadata/tag writing and artwork embedding
- Equalizer, ReplayGain, crossfade, and advanced DSP

Those features require dedicated components and are planned for later stages. Stage 1 keeps their boundaries and settings visible without falsely claiming they are implemented.

## Build and install

1. Use macOS with a current Xcode version.
2. Unzip the project and open `Resonance.xcodeproj`.
3. Select the **Resonance** target, then **Signing & Capabilities**.
4. Choose your Apple development team.
5. Change the bundle identifier if Xcode reports that `com.example.ResonancePrototype` is unavailable.
6. Connect and trust your iPhone, select it as the run destination, and press **Run**.
7. On the phone, use Library → `+` to import audio from Files.

A free Apple Account can be used for device testing, though provisioning may need periodic renewal. App Store/TestFlight distribution requires the appropriate Apple developer enrollment.

## Notes

- Actual codec support depends on the iOS AVFoundation decoder available on the device. The importer recognizes FLAC, MP3, M4A, AAC, WAV, AIFF, CAF, and ALAC extensions.
- The demo tracks are UI-only and intentionally contain no audio files.
- Tailscale itself does not define an audio-streaming port. A later server component must define the port and protocol; the app should recommend that server's default rather than inventing a “Tailscale audio port.”
