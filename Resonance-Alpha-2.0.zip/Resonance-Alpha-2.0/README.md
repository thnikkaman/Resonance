# Resonance Alpha 2.0

Open `Resonance.xcodeproj` in Xcode, choose your Apple development team, connect your iPhone, and run the app.

Install Alpha 2.0 over the existing Resonance Alpha app using the same bundle identifier and signing configuration. Do not delete the existing app first if you want to preserve its database and imported music files.

## New in Alpha 2.0

### Requested correction

- The **Play All Albums** button now uses the complementary color of the selected theme for its label and icon, matching other text placed over the theme color.

### Playback-control phase

- Added **Shuffle** to the Now Playing screen.
- Added three repeat modes: **Off**, **Repeat All**, and **Repeat One**.
- Added a **Playback Queue** sheet showing the active track and all upcoming tracks.
- Tap an upcoming queue item to jump directly to it.
- Swipe an upcoming queue item to remove it, or use **Clear** to remove everything after the current track.
- Added a **volume slider** to Now Playing.
- Added a **sleep timer** with 15, 30, 45, and 60 minute choices, plus **End of Track**.
- Added queue position and queue length to lock-screen Now Playing information.
- Corrected lock-screen Play and Pause commands so Play cannot accidentally pause an already playing track and Pause cannot accidentally start one.
- Repeat All wraps from the last queue item to the first; Repeat One restarts the current track when it finishes.
- Shuffle preserves the current track and randomizes only the remaining queue.

## Current-SDK compatibility baseline

`Resonance/Services/MetadataReader.swift` carries forward the Alpha 1.9 compatibility fixes for:

- `'async' call in an autoclosure that does not support concurrency`
- `Initializer for conditional binding must have Optional type, not 'Data'`

The FLAC artwork fallback is resolved with explicit control flow rather than an async nil-coalescing expression, and metadata artwork loading uses one optional binding compatible with the current SDK.

## What to test

1. Confirm **Play All Albums** remains readable with several bright and dark theme colors.
2. Start an album, enable Shuffle, and verify only the tracks after the current one are randomized.
3. Cycle Repeat from Off → Repeat All → Repeat One → Off.
4. Open the queue from either queue button, tap a later track, and verify audio and displayed metadata change together.
5. Delete one upcoming queue item, then use Clear and confirm the current song keeps playing.
6. Test each sleep-timer duration and End of Track.
7. Change volume in Resonance and confirm playback level changes immediately.
8. Test Play, Pause, Next, Previous, and scrubbing from the lock screen.
9. Install over Alpha 1.9 without deleting it and confirm the existing imported library still plays.

## Still planned

- Preloaded lower-level gapless playback engine and configurable memory buffering
- Metadata/tag writing and batch editing
- Online artwork lookup and artwork embedding
- Functional private-server browsing and streaming
