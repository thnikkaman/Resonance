import SwiftUI

struct NowPlayingView: View {
    @EnvironmentObject private var player: PlayerController
    @EnvironmentObject private var settings: AppSettings
    @State private var showingQueue = false
    let openLibrary: () -> Void

    var body: some View {
        VStack(spacing: 18) {
            Spacer(minLength: 4)
            ArtworkView(
                data: player.currentTrack?.artworkData,
                embedded: player.currentTrack?.artworkIsEmbedded ?? true,
                size: 286
            )
            .shadow(radius: 18, y: 8)

            VStack(spacing: 5) {
                Text(player.currentTrack?.title ?? "Nothing Playing")
                    .font(.title2.bold())
                    .lineLimit(1)
                Text(player.currentTrack.map { "\($0.artist) — \($0.album)" } ?? "Choose music from your library")
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }

            VStack(spacing: 2) {
                GeometryReader { proxy in
                    Slider(
                        value: Binding(
                            get: { player.elapsed },
                            set: { player.seek(to: $0) }
                        ),
                        in: 0...max(player.duration, 1)
                    )
                    .frame(width: proxy.size.width * 0.8)
                    .frame(maxWidth: .infinity, alignment: .center)
                }
                .frame(height: 32)

                HStack {
                    Text(format(player.elapsed))
                    Spacer()
                    Text("−\(format(max(0, player.duration - player.elapsed)))")
                }
                .frame(maxWidth: .infinity)
                .padding(.horizontal, 10)
                .font(.caption.monospacedDigit())
                .foregroundStyle(.secondary)
            }

            HStack(spacing: 40) {
                Button(action: player.previous) {
                    Image(systemName: "backward.fill")
                }
                Button(action: player.toggle) {
                    Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 42))
                }
                Button(action: player.next) {
                    Image(systemName: "forward.fill")
                }
            }
            .font(.title2)

            HStack(spacing: 34) {
                Button(action: player.toggleShuffle) {
                    Image(systemName: "shuffle")
                        .foregroundStyle(player.shuffleEnabled ? settings.accentColor : .secondary)
                }
                .accessibilityLabel(player.shuffleEnabled ? "Turn shuffle off" : "Turn shuffle on")

                Button(action: player.cycleRepeatMode) {
                    Image(systemName: player.repeatMode.systemImage)
                        .foregroundStyle(player.repeatMode == .off ? Color.secondary : settings.accentColor)
                        .overlay(alignment: .topTrailing) {
                            if player.repeatMode == .all {
                                Circle()
                                    .fill(settings.accentColor)
                                    .frame(width: 5, height: 5)
                                    .offset(x: 3, y: -3)
                            }
                        }
                }
                .accessibilityLabel(player.repeatMode.rawValue)

                Button { showingQueue = true } label: {
                    Image(systemName: "list.bullet")
                }
                .accessibilityLabel("Show playback queue")

                Menu {
                    ForEach(SleepTimerOption.allCases) { option in
                        Button {
                            player.setSleepTimer(option)
                        } label: {
                            if option == player.sleepTimerOption {
                                Label(option.rawValue, systemImage: "checkmark")
                            } else {
                                Text(option.rawValue)
                            }
                        }
                    }
                } label: {
                    Image(systemName: player.sleepTimerOption == .off ? "moon.zzz" : "moon.zzz.fill")
                        .foregroundStyle(player.sleepTimerOption == .off ? Color.secondary : settings.accentColor)
                }
                .accessibilityLabel("Sleep timer: \(player.sleepTimerLabel)")
            }
            .font(.title3)

            HStack(spacing: 10) {
                Image(systemName: "speaker.fill")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Slider(value: $player.volume, in: 0...1)
                Image(systemName: "speaker.wave.3.fill")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: 300)

            if player.sleepTimerOption != .off {
                Label("Sleep timer: \(player.sleepTimerLabel)", systemImage: "moon.zzz.fill")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            HStack {
                Button(action: openLibrary) {
                    HStack(spacing: 6) {
                        Text("Browse Library")
                        Image(systemName: "chevron.right")
                    }
                }
                .buttonStyle(.bordered)

                Button(action: player.stop) {
                    Label("Stop", systemImage: "stop.fill")
                }
                .buttonStyle(.bordered)
            }
            Spacer(minLength: 4)
        }
        .padding(24)
        .navigationTitle("Now Playing")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button(action: openLibrary) {
                    Label("Library", systemImage: "chevron.left")
                }
            }
            ToolbarItem(placement: .topBarTrailing) {
                Button { showingQueue = true } label: {
                    Label("Queue", systemImage: "list.bullet")
                }
            }
        }
        .sheet(isPresented: $showingQueue) {
            PlaybackQueueView()
                .presentationDetents([.medium, .large])
        }
        .contentShape(Rectangle())
        .gesture(
            DragGesture(minimumDistance: 45)
                .onEnded { value in
                    if value.startLocation.x < 36 && value.translation.width > 70 {
                        openLibrary()
                    }
                }
        )
    }
}

struct PlaybackQueueView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var player: PlayerController

    var body: some View {
        NavigationStack {
            List {
                if let current = player.currentTrack {
                    Section("Now Playing") {
                        queueRow(current, isCurrent: true)
                    }
                }

                Section("Up Next") {
                    if player.upcomingTracks.isEmpty {
                        ContentUnavailableView(
                            "Queue Is Empty",
                            systemImage: "text.line.last.and.arrowtriangle.forward",
                            description: Text("Choose an album or song to create a new playback queue.")
                        )
                    } else {
                        ForEach(player.upcomingTracks) { track in
                            Button {
                                player.playQueueItem(track)
                            } label: {
                                queueRow(track, isCurrent: false)
                            }
                            .buttonStyle(.plain)
                        }
                        .onDelete(perform: player.removeUpcoming)

                        Button(role: .destructive) {
                            player.clearUpcoming()
                        } label: {
                            Label("Clear Upcoming Tracks", systemImage: "trash")
                        }
                    }
                }
            }
            .navigationTitle("Playback Queue")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }

    private func queueRow(_ track: Track, isCurrent: Bool) -> some View {
        HStack(spacing: 10) {
            ArtworkView(
                data: track.artworkData,
                embedded: track.artworkIsEmbedded,
                size: 44
            )
            if isCurrent {
                PlayingTrackVisualizer(track: track)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(track.title)
                    .font(.subheadline.weight(isCurrent ? .semibold : .regular))
                    .lineLimit(1)
                Text("\(track.artist) — \(track.album)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer()
            if isCurrent {
                Image(systemName: player.isPlaying ? "speaker.wave.2.fill" : "pause.fill")
                    .foregroundStyle(.tint)
            }
        }
        .contentShape(Rectangle())
    }
}

struct MiniPlayerView: View {
    @EnvironmentObject private var player: PlayerController
    let openNowPlaying: () -> Void

    var body: some View {
        HStack(spacing: 10) {
            Button(action: openNowPlaying) {
                HStack(spacing: 10) {
                    ArtworkView(
                        data: player.currentTrack?.artworkData,
                        embedded: player.currentTrack?.artworkIsEmbedded ?? true,
                        size: 42
                    )
                    if let track = player.currentTrack {
                        PlayingTrackVisualizer(track: track)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(player.currentTrack?.title ?? "")
                            .font(.subheadline.weight(.semibold))
                            .lineLimit(1)
                        Text(player.currentTrack?.artist ?? "")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                }
            }
            .buttonStyle(.plain)

            Spacer()
            Button(action: player.toggle) {
                Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
            }
            Button(action: player.next) {
                Image(systemName: "forward.fill")
            }
        }
        .padding(8)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14))
        .shadow(radius: 5, y: 2)
    }
}
