import SwiftUI

@main
struct ResonanceApp: App {
    @StateObject private var library = LibraryStore()
    @StateObject private var player = PlayerController()
    @StateObject private var settings = AppSettings()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(library)
                .environmentObject(player)
                .environmentObject(settings)
                .tint(settings.accentColor)
                .preferredColorScheme(settings.colorScheme)
                .task { await library.bootstrap() }
        }
    }
}
