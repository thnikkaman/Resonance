# Resonance Alpha 3.2

A SwiftUI iPhone music-player prototype with Finder/Files transfer, recursive indexing, SQLite storage, FLAC/Vorbis metadata parsing, embedded artwork, playback queues, favorites, smart collections, playlists, metadata overrides, artist artwork, playback bookmarks, queue editing, and a lower-level gapless audio engine.

## Install without erasing the library

Install Alpha 3.2 directly over Alpha 3.1 using the same bundle identifier and signing configuration. Do not delete the installed app first. Deleting it removes the Documents folder, SQLite database, playlists, favorites, metadata overrides, bookmarks, and imported music.

## New phase: rolling partial preload for large files

Alpha 3.1 treated the local preload budget as an all-or-nothing file-size limit. A next track larger than the selected budget was rejected and reported as having no eligible next track.

Alpha 3.2 removes that rejection:

- Every readable local next track is eligible for the gapless engine, regardless of total file size.
- A file at or below the selected budget is scheduled in full.
- A file above the budget has a proportional opening segment scheduled before the current track ends.
- When the boundary is crossed, the remainder is appended immediately while the opening segment is already playing.
- A minimum lead segment is maintained so the app has time to append the remainder even with a small budget.
- Settings identifies whether the next track is fully scheduled or using partial preload.
- The selected 10–250 MB budget now controls the size of the opening portion rather than acting as a maximum supported file size.

This is a rolling file-segment design; it does not allocate the entire budget as one large decoded PCM object in memory.

## New phase: automatic surround-to-stereo downmix

- Added a dedicated `AVAudioMixerNode` between the player node and the engine's main mixer.
- The mixer's output is explicitly stereo.
- Mono and stereo files continue to play normally.
- Files with more than two channels, including common 5.1 layouts, are mixed to stereo so center and surround content remain audible through the iPhone's stereo output or stereo headphones.
- Settings → Playback now reports the active channel path, such as `6-channel source → stereo downmix`.
- The existing visualizer tap now observes the stereo mixer output.

## Playback diagnostics

Settings → Playback now shows:

- Gapless preload toggle
- Local preload budget
- Active playback-engine status
- Source/output channel status
- Preloaded next-track title
- Whether the next track is fully scheduled, partially scheduled, unavailable, or at the end of the queue

## Swift 6/current-SDK compatibility fixes carried forward

Alpha 3.2 includes the local Alpha 3.1 fixes reported after installation:

- `PlayerViews.swift`: artwork `Data?` is unwrapped with `track.flatMap`.
- `PlayerController.swift`: playback and sleep timers use main-actor `Task` loops instead of timer callbacks that cross actor isolation.
- `LibraryDatabase.swift`: SQLite ownership is held by a small `@unchecked Sendable` connection object, so the actor no longer accesses the non-Sendable database pointer from its `deinit`.

All prior `MetadataReader.swift`, SwiftUI `Section`, AV metadata, Core Foundation, orientation, Finder sharing, and database migration fixes remain present.

## Suggested tests

1. Install Alpha 3.2 over Alpha 3.1 and confirm the existing library remains available.
2. Queue a next track larger than the selected local preload budget.
3. Confirm Settings reports `Gapless ready — partial preload` rather than `no eligible next track`.
4. Let the current song finish naturally and listen for the transition.
5. Continue playing well beyond the opening portion of the large track to confirm the remainder streams correctly.
6. Repeat with preload budgets of 10 MB, 64 MB, and 250 MB.
7. Play a known 5.1 file and confirm dialogue/center, front, and surround material are audible through stereo output.
8. Confirm Settings reports `6-channel source → stereo downmix` for a six-channel source.
9. Test transitions between stereo and 5.1 files in both directions.
10. Retest seeking, pause/resume, Repeat One, Repeat All, queue reordering, lock-screen controls, bookmarks, and background playback.

## Mac preflight build

Run `Tools/PreflightBuild.sh` from Terminal on the Mac before signing. It performs a clean unsigned simulator build with complete Swift concurrency checking.
