@preconcurrency import AVFoundation
import MediaPlayer
import UIKit

enum RepeatMode: String, CaseIterable, Identifiable {
  case off = "Off"
  case all = "Repeat All"
  case one = "Repeat One"

  var id: String { rawValue }
  var systemImage: String {
    switch self {
    case .off, .all: return "repeat"
    case .one: return "repeat.1"
    }
  }
}

enum SleepTimerOption: String, CaseIterable, Identifiable {
  case off = "Off"
  case fifteenMinutes = "15 Minutes"
  case thirtyMinutes = "30 Minutes"
  case fortyFiveMinutes = "45 Minutes"
  case sixtyMinutes = "60 Minutes"
  case endOfTrack = "End of Track"

  var id: String { rawValue }
  var interval: TimeInterval? {
    switch self {
    case .off, .endOfTrack: return nil
    case .fifteenMinutes: return 15 * 60
    case .thirtyMinutes: return 30 * 60
    case .fortyFiveMinutes: return 45 * 60
    case .sixtyMinutes: return 60 * 60
    }
  }
}

struct PlaybackBookmark: Identifiable, Codable, Hashable, Sendable {
  let id: UUID
  let trackID: UUID
  let time: TimeInterval
  let createdAt: Date

  init(id: UUID = UUID(), trackID: UUID, time: TimeInterval, createdAt: Date = Date()) {
    self.id = id
    self.trackID = trackID
    self.time = time
    self.createdAt = createdAt
  }
}

@MainActor
final class PlayerController: NSObject, ObservableObject {
  @Published private(set) var currentTrack: Track?
  @Published private(set) var isPlaying = false
  @Published private(set) var elapsed = 0.0
  @Published private(set) var duration = 0.0
  @Published private(set) var meterLevel = 0.0
  @Published private(set) var queue: [Track] = []
  @Published private(set) var currentQueueIndex = 0
  @Published var shuffleEnabled = false
  @Published var repeatMode: RepeatMode = .off
  @Published var volume = 1.0 {
    didSet {
      let clamped = Float(min(max(volume, 0), 1))
      audioPlayer?.volume = clamped
      gaplessEngine.volume = clamped
    }
  }
  @Published private(set) var sleepTimerOption: SleepTimerOption = .off
  @Published private(set) var sleepTimerRemaining: TimeInterval = 0
  @Published private(set) var bookmarks: [PlaybackBookmark] = []
  @Published private(set) var playbackEngineStatus = "Ready"
  @Published private(set) var preloadedTrackTitle: String?
  @Published private(set) var preloadDetail = "No track preloaded"
  @Published private(set) var audioFormatStatus = "Stereo output ready"

  var onTrackStarted: (@MainActor (Track) -> Void)?

  private enum ActiveBackend { case none, gapless, legacy }

  private var sourceQueue: [Track] = []
  private var activeBackend: ActiveBackend = .none
  private var audioPlayer: AVAudioPlayer?
  private var playbackTimerTask: Task<Void, Never>?
  private var sleepTimerTask: Task<Void, Never>?
  private var lastNowPlayingProgressUpdate = 0.0
  private var playbackAnchorDate: Date?
  private var playbackAnchorElapsed = 0.0
  private var playbackGeneration = 0
  private var preloadedTrackID: UUID?
  private var engineDurations: [UUID: TimeInterval] = [:]
  private var engineChannelCounts: [UUID: AVAudioChannelCount] = [:]
  private var partialPreloadFrames: [UUID: AVAudioFramePosition] = [:]
  private lazy var audioDelegate = AudioPlayerDelegateProxy(owner: self)
  private lazy var gaplessEngine: GaplessAudioEngine = {
    let engine = GaplessAudioEngine()
    engine.setCompletionHandler { [weak self] trackID, generation in
      Task { @MainActor [weak self] in
        self?.handleGaplessTrackFinished(trackID: trackID, generation: generation)
      }
    }
    engine.volume = Float(min(max(volume, 0), 1))
    return engine
  }()

  override init() {
    bookmarks = Self.loadBookmarks()
    super.init()
    configureSession()
    configureRemoteCommands()
  }

  var upcomingTracks: [Track] {
    guard !queue.isEmpty, currentQueueIndex + 1 < queue.count else { return [] }
    return Array(queue[(currentQueueIndex + 1)...])
  }

  var currentTrackBookmarks: [PlaybackBookmark] {
    guard let currentTrack else { return [] }
    return
      bookmarks
      .filter { $0.trackID == currentTrack.id }
      .sorted { $0.time < $1.time }
  }

  var sleepTimerLabel: String {
    switch sleepTimerOption {
    case .off: return "Off"
    case .endOfTrack: return "End of Track"
    default:
      let remaining = max(0, Int(sleepTimerRemaining.rounded(.up)))
      return String(format: "%d:%02d", remaining / 60, remaining % 60)
    }
  }

  func artworkData(for track: Track) -> Data? {
    if let artwork = track.artworkData { return artwork }
    return artworkSource(for: track)?.artworkData
  }

  func artworkIsEmbedded(for track: Track) -> Bool {
    if track.artworkData != nil { return track.artworkIsEmbedded }
    return artworkSource(for: track)?.artworkIsEmbedded ?? true
  }

  func play(_ track: Track, in tracks: [Track]) {
    guard tracks.contains(track) else { return }
    sourceQueue = tracks

    if shuffleEnabled {
      let remaining = tracks.filter { $0.id != track.id }.shuffled()
      queue = [track] + remaining
      currentQueueIndex = 0
    } else {
      queue = tracks
      currentQueueIndex = tracks.firstIndex(of: track) ?? 0
    }

    _ = loadAndPlay(track)
  }

  func shuffleAndPlay(_ tracks: [Track]) {
    let candidates = uniqueTracks(tracks)
    guard let first = candidates.randomElement() else { return }
    shuffleEnabled = true
    play(first, in: candidates)
  }

  func playQueueItem(_ track: Track) {
    guard let targetIndex = queue.firstIndex(of: track) else { return }
    _ = loadAndPlay(track, at: targetIndex)
  }

  /// Inserts tracks immediately after the currently playing item. Existing
  /// occurrences are removed from the upcoming queue first so a quick action
  /// never creates accidental duplicates.
  func playNext(_ tracks: [Track]) {
    let requested = uniqueTracks(tracks).filter { $0.id != currentTrack?.id }
    guard !requested.isEmpty else { return }

    guard currentTrack != nil, !queue.isEmpty else {
      if let first = requested.first { play(first, in: requested) }
      return
    }

    let requestedIDs = Set(requested.map(\.id))
    let played = Array(queue.prefix(currentQueueIndex + 1))
    let remaining = queue.dropFirst(currentQueueIndex + 1).filter { !requestedIDs.contains($0.id) }
    queue = played + requested + remaining

    sourceQueue.removeAll { requestedIDs.contains($0.id) }
    if let currentTrack,
      let sourceIndex = sourceQueue.firstIndex(where: { $0.id == currentTrack.id })
    {
      let insertionIndex = min(sourceIndex + 1, sourceQueue.count)
      sourceQueue.insert(contentsOf: requested, at: insertionIndex)
    } else {
      let existingSourceIDs = Set(sourceQueue.map(\.id))
      sourceQueue.append(contentsOf: requested.filter { !existingSourceIDs.contains($0.id) })
    }
    updateNowPlaying()
    refreshPreloadedTrackAfterQueueChange()
  }

  /// Appends tracks to the end of the playback queue while preserving their
  /// requested order and omitting anything already queued.
  func addToQueue(_ tracks: [Track]) {
    let requested = uniqueTracks(tracks)
    guard !requested.isEmpty else { return }

    guard currentTrack != nil, !queue.isEmpty else {
      if let first = requested.first { play(first, in: requested) }
      return
    }

    let queuedIDs = Set(queue.map(\.id))
    let additions = requested.filter { !queuedIDs.contains($0.id) }
    guard !additions.isEmpty else { return }
    queue.append(contentsOf: additions)

    let sourceIDs = Set(sourceQueue.map(\.id))
    sourceQueue.append(contentsOf: additions.filter { !sourceIDs.contains($0.id) })
    updateNowPlaying()
    refreshPreloadedTrackAfterQueueChange()
  }

  func play() {
    guard currentTrack != nil, !isPlaying else { return }
    switch activeBackend {
    case .gapless:
      do {
        try gaplessEngine.play()
      } catch {
        playbackEngineStatus = "Audio engine could not resume"
        return
      }
    case .legacy:
      guard audioPlayer?.play() == true else { return }
    case .none:
      return
    }
    playbackAnchorDate = Date()
    playbackAnchorElapsed = elapsed
    isPlaying = true
    startPlaybackTimer()
    updateNowPlaying()
  }

  func pause() {
    guard isPlaying else { return }
    updateElapsedFromClock()
    switch activeBackend {
    case .gapless: gaplessEngine.pause()
    case .legacy: audioPlayer?.pause()
    case .none: break
    }
    playbackAnchorDate = nil
    playbackAnchorElapsed = elapsed
    isPlaying = false
    updateNowPlaying()
  }

  func toggle() {
    isPlaying ? pause() : play()
  }

  func next() {
    guard !queue.isEmpty else { return }
    if let targetIndex = nextQueueIndex(after: currentQueueIndex) {
      _ = loadAndPlay(queue[targetIndex], at: targetIndex)
    } else {
      stop()
    }
  }

  func previous() {
    if elapsed > 3 {
      seek(to: 0)
      return
    }
    previousTrack()
  }

  /// Moves directly to the preceding queue item. This is used by the Now
  /// Playing swipe gesture, where a right swipe always means previous track.
  func previousTrack() {
    guard !queue.isEmpty else { return }
    let targetIndex = currentQueueIndex - 1
    if queue.indices.contains(targetIndex) {
      _ = loadAndPlay(queue[targetIndex], at: targetIndex)
    } else if repeatMode == .all, let last = queue.last {
      _ = loadAndPlay(last, at: queue.count - 1)
    } else {
      seek(to: 0)
    }
  }

  func skip(by interval: TimeInterval) {
    guard currentTrack != nil else { return }
    seek(to: elapsed + interval)
  }

  func toggleShuffle() {
    shuffleEnabled.toggle()
    guard let currentTrack else { return }

    if shuffleEnabled {
      let alreadyPlayed = Array(queue.prefix(currentQueueIndex + 1))
      let upcoming = Array(queue.dropFirst(currentQueueIndex + 1)).shuffled()
      queue = alreadyPlayed + upcoming
    } else {
      let retainedIDs = Set(queue.map(\.id))
      let restoredQueue = sourceQueue.filter { retainedIDs.contains($0.id) }
      if let restoredIndex = restoredQueue.firstIndex(of: currentTrack) {
        queue = restoredQueue
        currentQueueIndex = restoredIndex
      }
    }
    updateNowPlaying()
    refreshPreloadedTrackAfterQueueChange()
  }

  func cycleRepeatMode() {
    switch repeatMode {
    case .off: repeatMode = .all
    case .all: repeatMode = .one
    case .one: repeatMode = .off
    }
    refreshPreloadedTrackAfterQueueChange()
  }

  func removeUpcoming(atOffsets offsets: IndexSet) {
    let start = currentQueueIndex + 1
    let absoluteIndices = offsets.map { start + $0 }.sorted(by: >)
    let removedIDs = Set(
      absoluteIndices.compactMap { queue.indices.contains($0) ? queue[$0].id : nil })
    for index in absoluteIndices where queue.indices.contains(index) {
      queue.remove(at: index)
    }
    sourceQueue.removeAll { removedIDs.contains($0.id) }
    updateNowPlaying()
    refreshPreloadedTrackAfterQueueChange()
  }

  func moveUpcoming(fromOffsets offsets: IndexSet, toOffset destination: Int) {
    var upcoming = upcomingTracks
    let validOffsets = offsets.filter { upcoming.indices.contains($0) }.sorted()
    guard !validOffsets.isEmpty else { return }

    let movingTracks = validOffsets.map { upcoming[$0] }
    for index in validOffsets.reversed() {
      upcoming.remove(at: index)
    }

    let removedBeforeDestination = validOffsets.filter { $0 < destination }.count
    let adjustedDestination = min(max(0, destination - removedBeforeDestination), upcoming.count)
    upcoming.insert(contentsOf: movingTracks, at: adjustedDestination)

    queue = Array(queue.prefix(currentQueueIndex + 1)) + upcoming
    sourceQueue = queue
    updateNowPlaying()
    refreshPreloadedTrackAfterQueueChange()
  }

  func clearUpcoming() {
    guard !queue.isEmpty else { return }
    queue = Array(queue.prefix(currentQueueIndex + 1))
    let retainedIDs = Set(queue.map(\.id))
    sourceQueue.removeAll { !retainedIDs.contains($0.id) }
    updateNowPlaying()
    refreshPreloadedTrackAfterQueueChange()
  }

  func addBookmarkAtCurrentPosition() {
    guard let currentTrack, duration > 0 else { return }
    let roundedTime = min(max(0, elapsed.rounded()), max(0, duration - 0.5))
    let alreadyExists = bookmarks.contains {
      $0.trackID == currentTrack.id && abs($0.time - roundedTime) < 2
    }
    guard !alreadyExists else { return }
    bookmarks.append(PlaybackBookmark(trackID: currentTrack.id, time: roundedTime))
    persistBookmarks()
  }

  func seek(to bookmark: PlaybackBookmark) {
    guard bookmark.trackID == currentTrack?.id else { return }
    seek(to: bookmark.time)
  }

  func removeBookmarks(atOffsets offsets: IndexSet) {
    let visible = currentTrackBookmarks
    let ids = Set(offsets.compactMap { visible.indices.contains($0) ? visible[$0].id : nil })
    guard !ids.isEmpty else { return }
    bookmarks.removeAll { ids.contains($0.id) }
    persistBookmarks()
  }

  func removeBookmark(_ bookmark: PlaybackBookmark) {
    bookmarks.removeAll { $0.id == bookmark.id }
    persistBookmarks()
  }

  func setSleepTimer(_ option: SleepTimerOption) {
    sleepTimerTask?.cancel()
    sleepTimerTask = nil
    sleepTimerOption = option
    sleepTimerRemaining = option.interval ?? 0

    guard let interval = option.interval else { return }
    let deadline = Date().addingTimeInterval(interval)
    sleepTimerTask = Task { @MainActor [weak self] in
      while !Task.isCancelled {
        try? await Task.sleep(for: .seconds(1))
        guard !Task.isCancelled, let self else { return }
        self.sleepTimerRemaining = max(0, deadline.timeIntervalSinceNow)
        if self.sleepTimerRemaining <= 0 {
          self.sleepTimerTask = nil
          self.sleepTimerOption = .off
          self.stop()
          return
        }
      }
    }
  }

  func stop() {
    playbackGeneration += 1
    playbackTimerTask?.cancel()
    playbackTimerTask = nil
    sleepTimerTask?.cancel()
    sleepTimerTask = nil
    audioPlayer?.delegate = nil
    audioPlayer?.stop()
    audioPlayer = nil
    gaplessEngine.stop(resetEngine: true)
    activeBackend = .none
    isPlaying = false
    elapsed = 0
    duration = 0
    meterLevel = 0
    currentTrack = nil
    queue = []
    sourceQueue = []
    currentQueueIndex = 0
    sleepTimerOption = .off
    sleepTimerRemaining = 0
    lastNowPlayingProgressUpdate = 0
    playbackAnchorDate = nil
    playbackAnchorElapsed = 0
    preloadedTrackID = nil
    preloadedTrackTitle = nil
    preloadDetail = "No track preloaded"
    audioFormatStatus = "Stereo output ready"
    engineDurations.removeAll()
    engineChannelCounts.removeAll()
    partialPreloadFrames.removeAll()
    playbackEngineStatus = "Ready"
    MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
  }

  func seek(to value: Double) {
    guard let currentTrack else { return }
    let clamped = safeSeekPosition(value, duration: duration)

    switch activeBackend {
    case .gapless:
      let wasPlaying = isPlaying
      if loadAndPlay(currentTrack, at: currentQueueIndex, startTime: clamped, autoPlay: wasPlaying, notifyTrackStarted: false) {
        elapsed = clamped
        playbackAnchorElapsed = clamped
        if !wasPlaying { pause() }
      }
    case .legacy:
      guard let audioPlayer else { return }
      audioPlayer.currentTime = safeSeekPosition(clamped, duration: audioPlayer.duration)
      elapsed = audioPlayer.currentTime
      playbackAnchorElapsed = elapsed
      playbackAnchorDate = isPlaying ? Date() : nil
      updateNowPlayingProgress()
    case .none:
      break
    }
  }

  /// Re-reads the persisted preload settings and rebuilds the future schedule
  /// without changing the selected track or its visible play position.
  func refreshPlaybackConfiguration() {
    guard activeBackend == .gapless, let currentTrack else { return }
    updateElapsedFromClock()
    let wasPlaying = isPlaying
    _ = loadAndPlay(
      currentTrack,
      at: currentQueueIndex,
      startTime: elapsed,
      autoPlay: wasPlaying,
      notifyTrackStarted: false
    )
  }

  @discardableResult
  private func loadAndPlay(
    _ track: Track,
    at targetIndex: Int? = nil,
    startTime: TimeInterval = 0,
    autoPlay: Bool = true,
    notifyTrackStarted: Bool = true
  ) -> Bool {
    guard let url = track.fileURL, FileManager.default.fileExists(atPath: url.path) else {
      clearUnplayableTrack()
      return false
    }

    let resolvedIndex = targetIndex ?? queue.firstIndex(of: track) ?? currentQueueIndex
    playbackGeneration += 1
    let generation = playbackGeneration
    playbackTimerTask?.cancel()
    playbackTimerTask = nil
    audioPlayer?.delegate = nil
    audioPlayer?.stop()
    audioPlayer = nil
    gaplessEngine.stop(resetEngine: true)
    activeBackend = .none
    isPlaying = false
    elapsed = max(0, startTime)
    playbackAnchorElapsed = elapsed
    playbackAnchorDate = nil
    meterLevel = 0
    preloadedTrackID = nil
    preloadedTrackTitle = nil
    engineDurations.removeAll()
    engineChannelCounts.removeAll()
    partialPreloadFrames.removeAll()
    preloadDetail = "No track preloaded"
    audioFormatStatus = "Stereo output ready"

    let following = preloadCandidate(after: resolvedIndex)
    do {
      let prepared = try gaplessEngine.prepare(
        currentTrackID: track.id,
        currentURL: url,
        startTime: startTime,
        followingTrackID: following?.id,
        followingURL: following?.fileURL,
        preloadBudgetBytes: localPreloadBudgetBytes,
        generation: generation
      )
      gaplessEngine.volume = Float(min(max(volume, 0), 1))
      activeBackend = .gapless
      currentQueueIndex = resolvedIndex
      currentTrack = track
      duration = prepared.current.duration
      engineDurations[track.id] = prepared.current.duration
      engineChannelCounts[track.id] = prepared.current.channelCount
      audioFormatStatus = Self.audioFormatDescription(
        sourceChannels: prepared.current.channelCount,
        outputChannels: gaplessEngine.outputChannelCount
      )
      if let following, let followingSchedule = prepared.following {
        preloadedTrackID = following.id
        preloadedTrackTitle = following.title
        engineDurations[following.id] = followingSchedule.duration
        engineChannelCounts[following.id] = followingSchedule.channelCount
        if let remainingFrame = followingSchedule.remainingStartFrame {
          partialPreloadFrames[following.id] = remainingFrame
          preloadDetail = "Opening segment scheduled; remainder streams from disk"
          playbackEngineStatus = "Gapless ready — partial preload"
        } else {
          preloadDetail = "Complete next track scheduled"
          playbackEngineStatus = "Gapless ready"
        }
      } else if following != nil {
        preloadDetail = "The next file could not be opened by the gapless engine"
        playbackEngineStatus = "Next track will load normally"
      } else {
        preloadDetail = shouldPreloadNextTrack ? "End of queue" : "Preloading disabled"
        playbackEngineStatus = shouldPreloadNextTrack ? "Playing — end of queue" : "Gapless preload off"
      }
      elapsed = min(max(0, startTime), max(0, duration - 0.05))
      playbackAnchorElapsed = elapsed
      playbackAnchorDate = autoPlay ? Date() : nil
      isPlaying = autoPlay
      if !autoPlay { gaplessEngine.pause() }
      if notifyTrackStarted { onTrackStarted?(track) }
      lastNowPlayingProgressUpdate = 0
      startPlaybackTimer()
      updateNowPlaying()
      return true
    } catch {
      playbackEngineStatus = "Compatibility fallback"
      return loadWithLegacyPlayer(
        track,
        url: url,
        at: resolvedIndex,
        startTime: startTime,
        autoPlay: autoPlay,
        notifyTrackStarted: notifyTrackStarted
      )
    }
  }

  private func loadWithLegacyPlayer(
    _ track: Track,
    url: URL,
    at targetIndex: Int,
    startTime: TimeInterval,
    autoPlay: Bool,
    notifyTrackStarted: Bool
  ) -> Bool {
    do {
      let newPlayer = try AVAudioPlayer(contentsOf: url)
      newPlayer.delegate = audioDelegate
      newPlayer.isMeteringEnabled = true
      newPlayer.volume = Float(min(max(volume, 0), 1))
      newPlayer.prepareToPlay()
      newPlayer.currentTime = safeSeekPosition(startTime, duration: newPlayer.duration)
      if autoPlay, !newPlayer.play() {
        clearUnplayableTrack()
        return false
      }
      audioPlayer = newPlayer
      activeBackend = .legacy
      preloadDetail = "Compatibility player does not use rolling preload"
      audioFormatStatus = "System-managed audio output"
      currentQueueIndex = targetIndex
      currentTrack = track
      duration = newPlayer.duration
      elapsed = newPlayer.currentTime
      playbackAnchorElapsed = elapsed
      playbackAnchorDate = autoPlay ? Date() : nil
      isPlaying = autoPlay
      if notifyTrackStarted { onTrackStarted?(track) }
      lastNowPlayingProgressUpdate = 0
      startPlaybackTimer()
      updateNowPlaying()
      return true
    } catch {
      clearUnplayableTrack()
      return false
    }
  }

  private static func loadBookmarks() -> [PlaybackBookmark] {
    guard let data = UserDefaults.standard.data(forKey: "resonance.playbackBookmarks"),
      let decoded = try? JSONDecoder().decode([PlaybackBookmark].self, from: data)
    else {
      return []
    }
    return decoded
  }

  private func persistBookmarks() {
    if let data = try? JSONEncoder().encode(bookmarks) {
      UserDefaults.standard.set(data, forKey: "resonance.playbackBookmarks")
    }
  }

  private func uniqueTracks(_ tracks: [Track]) -> [Track] {
    var seen = Set<UUID>()
    return tracks.filter { seen.insert($0.id).inserted }
  }

  private func artworkSource(for track: Track) -> Track? {
    let candidates = queue + sourceQueue
    return candidates.first {
      $0.artworkData != nil && $0.album.caseInsensitiveCompare(track.album) == .orderedSame
        && $0.albumArtist.caseInsensitiveCompare(track.albumArtist) == .orderedSame
    }
  }

  private var shouldPreloadNextTrack: Bool {
    let defaults = UserDefaults.standard
    if defaults.object(forKey: "preloadNextTrack") == nil { return true }
    return defaults.bool(forKey: "preloadNextTrack")
  }

  private var localPreloadBudgetBytes: Int64 {
    let configured = UserDefaults.standard.double(forKey: "localBufferMB")
    let megabytes = configured > 0 ? configured : 64
    return Int64(megabytes * 1_048_576)
  }

  private func nextQueueIndex(after index: Int) -> Int? {
    let next = index + 1
    if queue.indices.contains(next) { return next }
    if repeatMode == .all, !queue.isEmpty { return 0 }
    return nil
  }

  private func preloadQueueIndex(after index: Int) -> Int? {
    if repeatMode == .one, queue.indices.contains(index) { return index }
    return nextQueueIndex(after: index)
  }

  private func preloadCandidate(after index: Int) -> Track? {
    guard shouldPreloadNextTrack,
      let candidateIndex = preloadQueueIndex(after: index),
      queue.indices.contains(candidateIndex)
    else { return nil }
    let candidate = queue[candidateIndex]
    guard let url = candidate.fileURL, FileManager.default.fileExists(atPath: url.path) else {
      return nil
    }
    return candidate
  }

  private static func audioFormatDescription(
    sourceChannels: AVAudioChannelCount,
    outputChannels: AVAudioChannelCount
  ) -> String {
    if sourceChannels > outputChannels {
      return "\(sourceChannels)-channel source → stereo downmix"
    }
    if sourceChannels == 1 { return "Mono source → stereo output" }
    return "Stereo output"
  }

  private func safeSeekPosition(_ requested: Double, duration: Double) -> Double {
    guard duration.isFinite, duration > 0 else { return 0 }
    // Keep a small guard from the exact endpoint so dragging to the end does
    // not get interpreted as a natural completion while the user is seeking.
    let endGuard = duration > 1.25 ? duration - 0.75 : duration
    return min(max(0, requested), max(0, endGuard))
  }

  private func updateElapsedFromClock() {
    switch activeBackend {
    case .gapless:
      guard isPlaying, let playbackAnchorDate else { return }
      elapsed = min(duration, playbackAnchorElapsed + Date().timeIntervalSince(playbackAnchorDate))
    case .legacy:
      if let audioPlayer { elapsed = audioPlayer.currentTime }
    case .none:
      break
    }
  }

  private func refreshPreloadedTrackAfterQueueChange() {
    guard activeBackend == .gapless, let currentTrack else { return }
    let expected = preloadCandidate(after: currentQueueIndex)?.id
    guard expected != preloadedTrackID else { return }
    updateElapsedFromClock()
    let wasPlaying = isPlaying
    _ = loadAndPlay(
      currentTrack,
      at: currentQueueIndex,
      startTime: elapsed,
      autoPlay: wasPlaying,
      notifyTrackStarted: false
    )
  }

  private func handleGaplessTrackFinished(trackID: UUID, generation: Int) {
    guard generation == playbackGeneration,
      activeBackend == .gapless,
      currentTrack?.id == trackID
    else { return }

    if sleepTimerOption == .endOfTrack {
      stop()
      return
    }

    let targetIndex: Int?
    if repeatMode == .one {
      targetIndex = currentQueueIndex
    } else {
      targetIndex = nextQueueIndex(after: currentQueueIndex)
    }

    guard let targetIndex, queue.indices.contains(targetIndex) else {
      stop()
      return
    }

    let target = queue[targetIndex]
    guard preloadedTrackID == target.id else {
      _ = loadAndPlay(target, at: targetIndex)
      return
    }

    currentQueueIndex = targetIndex
    currentTrack = target
    duration = engineDurations[target.id] ?? max(0, target.duration)
    if let channels = engineChannelCounts[target.id] {
      audioFormatStatus = Self.audioFormatDescription(
        sourceChannels: channels,
        outputChannels: gaplessEngine.outputChannelCount
      )
    }
    elapsed = 0
    playbackAnchorElapsed = 0
    playbackAnchorDate = isPlaying ? Date() : nil
    lastNowPlayingProgressUpdate = 0
    preloadedTrackID = nil
    preloadedTrackTitle = nil

    if let remainingStartFrame = partialPreloadFrames.removeValue(forKey: target.id),
      let targetURL = target.fileURL
    {
      do {
        _ = try gaplessEngine.appendRemainder(
          trackID: target.id,
          url: targetURL,
          startingFrame: remainingStartFrame,
          generation: playbackGeneration
        )
        preloadDetail = "Large track is streaming after its preloaded opening segment"
      } catch {
        playbackEngineStatus = "Partial preload continuation failed"
      }
    }

    onTrackStarted?(target)
    scheduleTrackAfterCurrentBoundary()
    updateNowPlaying()
  }

  private func scheduleTrackAfterCurrentBoundary() {
    guard activeBackend == .gapless,
      let candidate = preloadCandidate(after: currentQueueIndex),
      let url = candidate.fileURL
    else {
      preloadedTrackID = nil
      preloadedTrackTitle = nil
      preloadDetail = shouldPreloadNextTrack ? "End of queue" : "Preloading disabled"
      playbackEngineStatus = shouldPreloadNextTrack ? "Playing — end of queue" : "Gapless preload off"
      return
    }

    do {
      let scheduled = try gaplessEngine.appendPreloaded(
        trackID: candidate.id,
        url: url,
        preloadBudgetBytes: localPreloadBudgetBytes,
        generation: playbackGeneration
      )
      engineDurations[candidate.id] = scheduled.duration
      engineChannelCounts[candidate.id] = scheduled.channelCount
      preloadedTrackID = candidate.id
      preloadedTrackTitle = candidate.title
      if let remainingFrame = scheduled.remainingStartFrame {
        partialPreloadFrames[candidate.id] = remainingFrame
        preloadDetail = "Opening segment scheduled; remainder streams from disk"
        playbackEngineStatus = "Gapless ready — partial preload"
      } else {
        partialPreloadFrames[candidate.id] = nil
        preloadDetail = "Complete next track scheduled"
        playbackEngineStatus = "Gapless ready"
      }
    } catch {
      preloadedTrackID = nil
      preloadedTrackTitle = nil
      preloadDetail = "The next file could not be opened by the gapless engine"
      playbackEngineStatus = "Next track will load normally"
    }
  }

  private func clearUnplayableTrack() {
    playbackGeneration += 1
    playbackTimerTask?.cancel()
    playbackTimerTask = nil
    audioPlayer?.delegate = nil
    audioPlayer?.stop()
    audioPlayer = nil
    gaplessEngine.stop(resetEngine: true)
    activeBackend = .none
    currentTrack = nil
    isPlaying = false
    elapsed = 0
    duration = 0
    meterLevel = 0
    playbackAnchorDate = nil
    playbackAnchorElapsed = 0
    preloadedTrackID = nil
    preloadedTrackTitle = nil
    preloadDetail = "No track preloaded"
    audioFormatStatus = "Stereo output ready"
    engineDurations.removeAll()
    engineChannelCounts.removeAll()
    partialPreloadFrames.removeAll()
    playbackEngineStatus = "Unable to play this file"
    MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
  }

  private func startPlaybackTimer() {
    playbackTimerTask?.cancel()
    playbackTimerTask = Task { @MainActor [weak self] in
      while !Task.isCancelled {
        try? await Task.sleep(for: .milliseconds(120))
        guard !Task.isCancelled, let self else { return }
        self.updatePlaybackClockAndMeters()
      }
    }
  }

  private func updatePlaybackClockAndMeters() {
    updateElapsedFromClock()

    switch activeBackend {
    case .gapless:
      meterLevel = isPlaying ? gaplessEngine.meterLevel : 0.08
    case .legacy:
      if let audioPlayer {
        audioPlayer.updateMeters()
        let decibels = audioPlayer.averagePower(forChannel: 0)
        let linear = pow(10.0, Double(decibels) / 20.0)
        meterLevel = audioPlayer.isPlaying ? min(1, max(0.06, linear * 4.5)) : 0.08
      }
    case .none:
      meterLevel = 0
    }

    if abs(elapsed - lastNowPlayingProgressUpdate) >= 0.8 {
      lastNowPlayingProgressUpdate = elapsed
      updateNowPlayingProgress()
    }
  }

  fileprivate func handlePlaybackFinished(_ finishedPlayer: AVAudioPlayer, successfully: Bool) {
    guard activeBackend == .legacy, let audioPlayer, finishedPlayer === audioPlayer else { return }

    if sleepTimerOption == .endOfTrack {
      stop()
    } else if repeatMode == .one, let currentTrack {
      _ = loadAndPlay(currentTrack, at: currentQueueIndex)
    } else {
      next()
    }
  }

  fileprivate func handleDecodeError(_ failedPlayer: AVAudioPlayer, error: Error?) {
    guard activeBackend == .legacy, let audioPlayer, failedPlayer === audioPlayer else { return }
    clearUnplayableTrack()
  }

  private func configureSession() {
    try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
    try? AVAudioSession.sharedInstance().setActive(true)
  }

  private func configureRemoteCommands() {
    let commands = MPRemoteCommandCenter.shared()

    commands.playCommand.addTarget { [weak self] _ in
      Task { @MainActor in self?.play() }
      return .success
    }
    commands.pauseCommand.addTarget { [weak self] _ in
      Task { @MainActor in self?.pause() }
      return .success
    }
    commands.nextTrackCommand.addTarget { [weak self] _ in
      Task { @MainActor in self?.next() }
      return .success
    }
    commands.previousTrackCommand.addTarget { [weak self] _ in
      Task { @MainActor in self?.previous() }
      return .success
    }

    commands.skipForwardCommand.isEnabled = true
    commands.skipForwardCommand.preferredIntervals = [15]
    commands.skipForwardCommand.addTarget { [weak self] event in
      let interval = (event as? MPSkipIntervalCommandEvent)?.interval ?? 15
      Task { @MainActor in self?.skip(by: interval) }
      return .success
    }

    commands.skipBackwardCommand.isEnabled = true
    commands.skipBackwardCommand.preferredIntervals = [15]
    commands.skipBackwardCommand.addTarget { [weak self] event in
      let interval = (event as? MPSkipIntervalCommandEvent)?.interval ?? 15
      Task { @MainActor in self?.skip(by: -interval) }
      return .success
    }

    commands.changePlaybackPositionCommand.addTarget { [weak self] event in
      guard let event = event as? MPChangePlaybackPositionCommandEvent else {
        return .commandFailed
      }
      Task { @MainActor in self?.seek(to: event.positionTime) }
      return .success
    }
  }

  private func updateNowPlaying() {
    guard let track = currentTrack else { return }
    var info: [String: Any] = [
      MPMediaItemPropertyTitle: track.title,
      MPMediaItemPropertyArtist: track.artist,
      MPMediaItemPropertyAlbumTitle: track.album,
      MPMediaItemPropertyPlaybackDuration: duration,
      MPNowPlayingInfoPropertyElapsedPlaybackTime: elapsed,
      MPNowPlayingInfoPropertyPlaybackRate: isPlaying ? 1 : 0,
      MPNowPlayingInfoPropertyPlaybackQueueIndex: currentQueueIndex,
      MPNowPlayingInfoPropertyPlaybackQueueCount: queue.count,
    ]
    if let data = artworkData(for: track), let image = UIImage(data: data) {
      info[MPMediaItemPropertyArtwork] = MPMediaItemArtwork(boundsSize: image.size) {
        requestedSize in
        image.resonanceAspectFit(to: requestedSize) ?? image
      }
    }
    MPNowPlayingInfoCenter.default().nowPlayingInfo = info
  }

  private func updateNowPlayingProgress() {
    guard var info = MPNowPlayingInfoCenter.default().nowPlayingInfo else {
      updateNowPlaying()
      return
    }
    info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = elapsed
    info[MPNowPlayingInfoPropertyPlaybackRate] = isPlaying ? 1 : 0
    info[MPMediaItemPropertyPlaybackDuration] = duration
    info[MPNowPlayingInfoPropertyPlaybackQueueIndex] = currentQueueIndex
    info[MPNowPlayingInfoPropertyPlaybackQueueCount] = queue.count
    MPNowPlayingInfoCenter.default().nowPlayingInfo = info
  }
}

private final class AudioPlayerDelegateProxy: NSObject, AVAudioPlayerDelegate {
  weak var owner: PlayerController?

  init(owner: PlayerController) {
    self.owner = owner
  }

  func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
    Task { @MainActor [weak owner] in
      owner?.handlePlaybackFinished(player, successfully: flag)
    }
  }

  func audioPlayerDecodeErrorDidOccur(_ player: AVAudioPlayer, error: Error?) {
    Task { @MainActor [weak owner] in
      owner?.handleDecodeError(player, error: error)
    }
  }
}

extension UIImage {
  fileprivate func resonanceAspectFit(to requestedSize: CGSize) -> UIImage? {
    guard requestedSize.width > 0, requestedSize.height > 0 else { return self }
    let scale = min(requestedSize.width / size.width, requestedSize.height / size.height)
    let fitted = CGSize(width: max(1, size.width * scale), height: max(1, size.height * scale))
    return preparingThumbnail(of: fitted)
  }
}
