@preconcurrency import AVFoundation
import Foundation

/// Lower-level local-file playback backend. The current track and the opening
/// segment of the next track are scheduled on one player node. Large files use
/// a bounded partial schedule instead of being rejected by the preload budget.
/// A dedicated mixer converts multichannel sources to stereo before output.
final class GaplessAudioEngine: @unchecked Sendable {
  struct ScheduledTrack {
    let duration: TimeInterval
    let remainingStartFrame: AVAudioFramePosition?
    let channelCount: AVAudioChannelCount

    var isPartiallyPreloaded: Bool { remainingStartFrame != nil }
  }

  struct PreparedDurations {
    let current: ScheduledTrack
    let following: ScheduledTrack?
  }

  enum EngineError: LocalizedError {
    case missingFile(URL)
    case emptyAudioFile(URL)

    var errorDescription: String? {
      switch self {
      case .missingFile(let url): return "Audio file is missing: \(url.lastPathComponent)"
      case .emptyAudioFile(let url): return "Audio file contains no playable frames: \(url.lastPathComponent)"
      }
    }
  }

  typealias CompletionHandler = @Sendable (_ trackID: UUID, _ generation: Int) -> Void

  private let engine = AVAudioEngine()
  private let playerNode = AVAudioPlayerNode()
  private let stereoMixer = AVAudioMixerNode()
  private let meterState = AudioMeterState()
  private let retainedFiles = RetainedAudioFiles()
  private var completionHandler: CompletionHandler?
  private(set) var isPrepared = false

  var volume: Float {
    get { playerNode.volume }
    set { playerNode.volume = min(max(newValue, 0), 1) }
  }

  var isPlaying: Bool { playerNode.isPlaying }
  var meterLevel: Double { meterState.value }
  var outputChannelCount: AVAudioChannelCount { 2 }

  init(completionHandler: CompletionHandler? = nil) {
    self.completionHandler = completionHandler
    engine.attach(playerNode)
    engine.attach(stereoMixer)

    // Leave the source-side format unspecified so AVAudioPlayerNode and the
    // mixer can accept the file's native channel layout. Force the mixer's
    // output to stereo; AVAudioMixerNode performs the channel conversion.
    engine.connect(playerNode, to: stereoMixer, format: nil)
    let deviceFormat = engine.outputNode.inputFormat(forBus: 0)
    let sampleRate = deviceFormat.sampleRate > 0 ? deviceFormat.sampleRate : 48_000
    let stereoFormat = AVAudioFormat(
      standardFormatWithSampleRate: sampleRate,
      channels: outputChannelCount
    )
    engine.connect(stereoMixer, to: engine.mainMixerNode, format: stereoFormat)
    installMeterTap()
  }

  func setCompletionHandler(_ handler: CompletionHandler?) {
    completionHandler = handler
  }

  @discardableResult
  func prepare(
    currentTrackID: UUID,
    currentURL: URL,
    startTime: TimeInterval,
    followingTrackID: UUID?,
    followingURL: URL?,
    preloadBudgetBytes: Int64,
    generation: Int
  ) throws -> PreparedDurations {
    stop(resetEngine: true)
    try startEngineIfNeeded()

    let currentFile = try openFile(at: currentURL)
    let currentDuration = Self.duration(of: currentFile)
    let safeStart = min(max(0, startTime), max(0, currentDuration - 0.05))
    let startFrame = AVAudioFramePosition(safeStart * currentFile.processingFormat.sampleRate)
    scheduleCompleteTrack(
      file: currentFile,
      trackID: currentTrackID,
      startingFrame: startFrame,
      generation: generation
    )

    let current = ScheduledTrack(
      duration: currentDuration,
      remainingStartFrame: nil,
      channelCount: currentFile.processingFormat.channelCount
    )

    var following: ScheduledTrack?
    if let followingTrackID, let followingURL {
      following = try? appendPreloaded(
        trackID: followingTrackID,
        url: followingURL,
        preloadBudgetBytes: preloadBudgetBytes,
        generation: generation
      )
    }

    playerNode.play()
    isPrepared = true
    return PreparedDurations(current: current, following: following)
  }

  /// Schedules either the complete next track or a bounded opening segment.
  /// When the file is larger than the selected budget, the controller appends
  /// the remainder as soon as the track boundary is crossed.
  @discardableResult
  func appendPreloaded(
    trackID: UUID,
    url: URL,
    preloadBudgetBytes: Int64,
    generation: Int
  ) throws -> ScheduledTrack {
    let file = try openFile(at: url)
    let duration = Self.duration(of: file)
    let headFrameCount = preloadFrameCount(
      for: file,
      url: url,
      preloadBudgetBytes: preloadBudgetBytes
    )

    if headFrameCount >= file.length {
      scheduleCompleteTrack(
        file: file,
        trackID: trackID,
        startingFrame: 0,
        generation: generation
      )
      return ScheduledTrack(
        duration: duration,
        remainingStartFrame: nil,
        channelCount: file.processingFormat.channelCount
      )
    }

    let scheduledHeadFrames = min(headFrameCount, AVAudioFramePosition(UInt32.max))
    let token = retainedFiles.retain(file)
    playerNode.scheduleSegment(
      file,
      startingFrame: 0,
      frameCount: AVAudioFrameCount(scheduledHeadFrames),
      at: nil,
      completionCallbackType: .dataPlayedBack
    ) { [weak self] _ in
      self?.retainedFiles.release(token)
    }

    return ScheduledTrack(
      duration: duration,
      remainingStartFrame: scheduledHeadFrames,
      channelCount: file.processingFormat.channelCount
    )
  }

  /// Appends the unscheduled remainder of a partially preloaded track. This is
  /// called immediately after the preceding track reaches its audio boundary,
  /// while the already-scheduled opening segment is playing.
  @discardableResult
  func appendRemainder(
    trackID: UUID,
    url: URL,
    startingFrame: AVAudioFramePosition,
    generation: Int
  ) throws -> TimeInterval {
    let file = try openFile(at: url)
    scheduleCompleteTrack(
      file: file,
      trackID: trackID,
      startingFrame: startingFrame,
      generation: generation
    )
    return Self.duration(of: file)
  }

  func play() throws {
    guard isPrepared else { return }
    try startEngineIfNeeded()
    playerNode.play()
  }

  func pause() {
    playerNode.pause()
  }

  func stop(resetEngine: Bool = false) {
    playerNode.stop()
    retainedFiles.removeAll()
    isPrepared = false
    meterState.value = 0
    if resetEngine {
      engine.reset()
    }
  }

  private func startEngineIfNeeded() throws {
    if !engine.isRunning {
      engine.prepare()
      try engine.start()
    }
  }

  private func openFile(at url: URL) throws -> AVAudioFile {
    guard FileManager.default.fileExists(atPath: url.path) else {
      throw EngineError.missingFile(url)
    }
    let file = try AVAudioFile(forReading: url)
    guard file.length > 0 else { throw EngineError.emptyAudioFile(url) }
    return file
  }

  private func scheduleCompleteTrack(
    file: AVAudioFile,
    trackID: UUID,
    startingFrame: AVAudioFramePosition,
    generation: Int
  ) {
    let safeStart = min(max(0, startingFrame), max(0, file.length - 1))
    let token = retainedFiles.retain(file)
    var cursor = safeStart

    while cursor < file.length {
      let remaining = file.length - cursor
      let segmentFrames = AVAudioFrameCount(min(remaining, AVAudioFramePosition(UInt32.max)))
      let isFinalSegment = cursor + AVAudioFramePosition(segmentFrames) >= file.length

      if isFinalSegment {
        playerNode.scheduleSegment(
          file,
          startingFrame: cursor,
          frameCount: segmentFrames,
          at: nil,
          completionCallbackType: .dataPlayedBack
        ) { [weak self] _ in
          self?.retainedFiles.release(token)
          self?.completionHandler?(trackID, generation)
        }
      } else {
        playerNode.scheduleSegment(
          file,
          startingFrame: cursor,
          frameCount: segmentFrames,
          at: nil,
          completionCallbackType: .dataConsumed
        ) { _ in }
      }
      cursor += AVAudioFramePosition(segmentFrames)
    }
  }

  private func preloadFrameCount(
    for file: AVAudioFile,
    url: URL,
    preloadBudgetBytes: Int64
  ) -> AVAudioFramePosition {
    let safeBudget = max(Int64(1_048_576), preloadBudgetBytes)
    let fileSize = (try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize).map(Int64.init)
    let minimumLeadFrames = AVAudioFramePosition(file.processingFormat.sampleRate * 12)

    guard let fileSize, fileSize > safeBudget else {
      return file.length
    }

    let ratio = min(1, Double(safeBudget) / Double(fileSize))
    let proportionalFrames = AVAudioFramePosition(Double(file.length) * ratio)
    return min(file.length, max(minimumLeadFrames, proportionalFrames))
  }

  private static func duration(of file: AVAudioFile) -> TimeInterval {
    let rate = file.processingFormat.sampleRate
    guard rate > 0 else { return 0 }
    return Double(file.length) / rate
  }

  private func installMeterTap() {
    stereoMixer.installTap(onBus: 0, bufferSize: 1024, format: nil) { [meterState] buffer, _ in
      guard let channels = buffer.floatChannelData, buffer.frameLength > 0 else {
        meterState.value = 0
        return
      }

      let frameCount = Int(buffer.frameLength)
      let channelCount = max(1, Int(buffer.format.channelCount))
      let bufferCount = buffer.format.isInterleaved ? 1 : channelCount
      let samplesPerBuffer = buffer.format.isInterleaved ? frameCount * channelCount : frameCount
      var sumSquares: Float = 0
      for channel in 0..<bufferCount {
        let samples = channels[channel]
        for frame in 0..<samplesPerBuffer {
          let sample = samples[frame]
          sumSquares += sample * sample
        }
      }
      let divisor = Float(max(1, samplesPerBuffer * bufferCount))
      let rms = sqrt(max(0, sumSquares / divisor))
      meterState.value = min(1, max(0.04, Double(rms) * 4.5))
    }
  }
}

private final class AudioMeterState: @unchecked Sendable {
  private let lock = NSLock()
  private var storedValue = 0.0

  var value: Double {
    get {
      lock.lock()
      defer { lock.unlock() }
      return storedValue
    }
    set {
      lock.lock()
      storedValue = newValue
      lock.unlock()
    }
  }
}

private final class RetainedAudioFiles: @unchecked Sendable {
  private let lock = NSLock()
  private var files: [UUID: AVAudioFile] = [:]

  func retain(_ file: AVAudioFile) -> UUID {
    let token = UUID()
    lock.lock()
    files[token] = file
    lock.unlock()
    return token
  }

  func release(_ token: UUID) {
    lock.lock()
    files[token] = nil
    lock.unlock()
  }

  func removeAll() {
    lock.lock()
    files.removeAll(keepingCapacity: true)
    lock.unlock()
  }
}
