# Alpha 3.7.1 Playback Hotfix Validation

## Observed Problem
- User-visible symptom: starting either a local or remote track terminates the app immediately.
- Reproduction: Alpha 3.7 on an iPhone 17 Pro running the latest iOS; tap a local or streaming track.
- Affected layer: shared playback startup/teardown, with a separate high-risk remote prequeue experiment.

## Baseline
A device crash trace was not available in this environment. The code delta was compared against the last reported working local playback baseline and the earlier stable remote single-item player.

## Evidence
- Alpha 3.7 stopped and reset all playback backends for every play request.
- Remote playback could therefore initialize/reset the local AVAudioEngine even though it did not use it.
- Local playback performed a redundant engine reset before `GaplessAudioEngine.prepare`, which performs its own reset.
- The remote AVQueuePlayer prequeue path was the most recent high-risk playback change and had already produced a crash report in Alpha 3.6.

## Opportunity Matrix
| Change | Impact | Confidence | Effort | Score |
|---|---:|---:|---:|---:|
| Isolate teardown by active backend | 5 | 4 | 2 | 10.0 |
| Roll remote playback back to stable AVPlayer | 5 | 4 | 2 | 10.0 |
| Broad audio/UI refactor | 3 | 1 | 5 | 0.6 |

## Behavior Proof
- Local gapless ordering and explicit 5.1 matrix remain unchanged.
- Local and remote queue semantics, seeking, remote commands, metadata, artwork, playlists, favorites, history, and authentication remain intact.
- Remote prequeued transitions are intentionally disabled as the rollback boundary.
- No credentials or authenticated URLs are added to diagnostics.

## Implementation
- One boundary: playback startup and backend ownership.
- Files changed: `PlayerController.swift`, `SettingsView.swift`, project version, README, regression checks.
- Rollback: restore Alpha 3.7 PlayerController if device evidence disproves this boundary.

## Verification
- All Swift files parsed with Swift 6 frontend.
- Info.plist and project.pbxproj validated.
- Existing metadata, SwiftUI Section, actor-isolation, database, Subsonic, 5.1, and cache regression assertions passed.
- ZIP integrity verified after packaging.
- Remaining requirement: current-Xcode device build and physical-device playback test.
