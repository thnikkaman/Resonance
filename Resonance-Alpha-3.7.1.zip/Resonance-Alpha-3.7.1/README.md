# Resonance Alpha 3.7.1 — Playback Crash Hotfix

This build is a focused correctness hotfix for the immediate crash reported when starting either local or remote playback on an iPhone 17 Pro running the latest iOS software.

## Observed problem

- Starting a local or streaming track terminated the app immediately.
- The failure crossed both playback sources, pointing to the shared playback-startup and teardown path.

## Focused change

- Playback teardown is now backend-specific. Starting a remote track no longer initializes or resets the local AVAudioEngine, and starting a local track no longer touches the network player.
- The redundant local engine reset before `GaplessAudioEngine.prepare` was removed; `prepare` owns its own clean reset.
- Remote playback is temporarily returned to the previously stable single-item `AVPlayer` path. The Alpha 3.6/3.7 `AVQueuePlayer` prequeue experiment is disabled in this hotfix.
- Local gapless scheduling, partial large-file preload, and the verified explicit 5.1-to-stereo matrix remain enabled.
- Settings now shows the last persisted playback-startup stage. If a crash remains, reopen Resonance and report that exact stage.

## Behavior preserved

- Local queue order, gapless scheduling, seeking, 15-second skips, bookmarks, shuffle, repeat, and lock-screen controls.
- Explicit 5.1 routing: front/rear left to left, front/rear right to right, center and LFE to both.
- Navidrome authentication, cached remote catalog, playlists, artwork, favorites, and scrobbling.
- Existing local music, metadata overrides, favorites, playlists, and Finder-shared files when installed over the existing app.

## Temporary limitation

Remote playback uses a stable single-item player in this hotfix, so remote prequeued/gapless transitions are temporarily disabled. The next remote-preload implementation should be reintroduced only after device crash traces and validation fixtures pass.

## Install

Open `Resonance.xcodeproj`, use the same bundle identifier and signing configuration, and install directly over Alpha 3.7. Do not delete the existing app first.

- Marketing version: `0.3.7`
- Build: `38`
- Displayed build: `Alpha 3.7.1`
