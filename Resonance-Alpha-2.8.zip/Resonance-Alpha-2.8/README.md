# Resonance Alpha 2.8

A SwiftUI iPhone music-player prototype with Finder/Files transfer, recursive indexing, SQLite storage, FLAC/Vorbis metadata parsing, embedded artwork, playback queues, favorites, smart collections, playlists, and persistent Resonance metadata edits.

## Install without erasing the library

Install Alpha 2.8 directly over Alpha 2.7 using the same bundle identifier and signing configuration. Do not delete the installed app first. Deleting it removes the app's Documents folder, SQLite database, favorites, recent-play history, playlists, metadata overrides, artist artwork overrides, and imported music.

## Requested changes

### Swipe between tracks on Now Playing

- Swipe left on the Now Playing screen to start the next queued track.
- Swipe right to start the previous queued track immediately.
- The gesture requires a clearly horizontal swipe and does not replace the visible Library button.
- The precision scrubber retains its high-priority drag gesture, so seeking should not trigger a track change.

### Artwork beside album tracks

- Every track in an album detail screen now displays its album artwork.
- The artist **All Albums** track list also displays the appropriate artwork for each album.
- Artwork still falls back to another track on the same album when an individual file has no embedded image.

### Choose artist artwork from existing albums

- Long-press an artist and choose **Edit Artist Metadata**.
- A new **Choose from Album Covers** section displays the available covers from that artist's collection.
- Tap one cover once to select it; a checkmark and accent outline show the pending choice.
- The selected cover affects only the artist display and does not replace the album's artwork.
- Choosing from Photos, removing artist artwork, and returning to automatic album-art inheritance remain available.

## New phase: quick queue and artist playback

### Track queue actions

- Swipe a track from the leading edge to reveal **Play Next** and **Add to Queue**.
- The same actions appear in a track's press-and-hold menu.
- **Play Next** inserts the track directly after the current track.
- **Add to End of Queue** appends the track without duplicating an item already queued.

### Album queue actions

- Open an album and use the new ellipsis menu.
- Choose **Play Album Next** to insert the complete album after the current track.
- Choose **Add Album to End of Queue** to append the album in disc/track order.
- Existing occurrences are removed from the upcoming queue before a Play Next insertion, preventing accidental duplicates.

### Artist quick playback

- Artist pages now include **Play Artist** and **Shuffle** controls.
- Play Artist begins with the first track in the artist's sorted All Albums collection.
- Shuffle selects a random starting track and creates a shuffled artist queue.

## Suggested Alpha 2.8 tests

1. Install over Alpha 2.7 and confirm the existing library, playlists, favorites, and metadata edits remain.
2. Start an album, open Now Playing, swipe left and right several times, and verify the displayed title always matches the audio.
3. Drag the progress scrubber horizontally and confirm it seeks rather than changing tracks.
4. Open an album and confirm artwork appears beside every track.
5. Open an artist's All Albums view and confirm each track uses its album's cover.
6. Edit artist metadata and select several different covers from **Choose from Album Covers**; save and verify the artist tile/header updates without changing album covers.
7. Long-press or leading-swipe a track, use Play Next, and inspect the Playback Queue.
8. Add a track already present in the queue and confirm it is not duplicated.
9. Use an album's ellipsis menu to Play Album Next and Add Album to End of Queue.
10. Test Play Artist and Shuffle, then verify Next/Previous and queue artwork continue working.

## Compatibility baseline

Alpha 2.8 preserves the successful Alpha 2.1–2.7 compatibility fixes, including the two current-SDK `MetadataReader.swift` corrections, asynchronous AV metadata loading, Swift 6-safe `AVAudioPlayerDelegate` proxying, actor-safe database schema creation, safe Core Foundation ownership, Finder File Sharing, document-relative paths, and the resolved orientation and `withUnsafeBytes` warnings.

The locally applied Alpha 2.7 `SmartLibraryViews.swift` fix is also included: the two problematic `Section` declarations use explicit `content`, `header`, and `footer` closures, preventing the prior missing-label and String-to-Content compile errors.
