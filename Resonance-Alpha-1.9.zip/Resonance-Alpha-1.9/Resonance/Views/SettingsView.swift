import SwiftUI
import UIKit

struct SettingsView: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var library: LibraryStore
    let openLibrary: () -> Void
    @FocusState private var isTextFieldFocused: Bool
    private let palette = ["A855F7", "3B82F6", "14B8A6", "22C55E", "EAB308", "F97316", "EF4444"]

    var body: some View {
        Form {
            Section("Appearance") {
                Picker("Theme", selection: $settings.appearance) {
                    Text("System").tag("system")
                    Text("Light").tag("light")
                    Text("Dark").tag("dark")
                }
                .pickerStyle(.segmented)

                HStack {
                    ForEach(palette, id: \.self) { hex in
                        Button { settings.accentHex = hex } label: {
                            Circle()
                                .fill(Color(hex: hex) ?? .purple)
                                .frame(width: 30, height: 30)
                                .overlay {
                                    if settings.normalizedAccentHex == hex {
                                        Image(systemName: "checkmark").foregroundStyle(.white)
                                    }
                                }
                        }
                        .buttonStyle(.plain)
                    }
                }

                VStack(alignment: .leading, spacing: 8) {
                    Text("Hex Color Code")
                        .font(.subheadline.weight(.semibold))
                    RGBHexField(hex: $settings.accentHex)
                }

                Toggle("Apply theme color to text", isOn: $settings.applyThemeColorToText)
                Toggle("Red outline for cached artwork", isOn: $settings.showArtworkWarning)

                ThemePreview()
            }

            Section("Playback") {
                Toggle("Preload next track", isOn: $settings.preloadNextTrack)
                LabeledContent("Local buffer", value: "\(Int(settings.localBufferMB)) MB")
                Slider(value: $settings.localBufferMB, in: 10...250, step: 10)
                Text("This prototype stores the buffer preference. The lower-level gapless engine remains a later-stage component.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Streaming Library") {
                TextField("Domain or IP address", text: $settings.streamHost)
                    .focused($isTextFieldFocused)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                TextField("Port (server default if blank)", text: $settings.streamPort)
                    .focused($isTextFieldFocused)
                    .keyboardType(.numberPad)
                LabeledContent("Streaming buffer", value: "\(Int(settings.networkBufferMB)) MB")
                Slider(value: $settings.networkBufferMB, in: 10...250, step: 10)
                Text("Tailscale provides private network access but does not define a universal audio port. Use the port configured by your chosen home music server.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Library") {
                Button("Restore demo library") { Task { await library.resetDemoLibrary() } }
            }

            Section("Prototype Status") {
                LabeledContent("Build", value: "Alpha 1.9")
                StatusRow(title: "Local import and indexing", detail: "Available", icon: "checkmark.circle.fill")
                StatusRow(title: "Artist → albums → numbered tracks", detail: "Available", icon: "checkmark.circle.fill")
                StatusRow(title: "Playback and lock-screen controls", detail: "Artwork enabled", icon: "checkmark.circle.fill")
                StatusRow(title: "Persistent navigation and mini-player", detail: "Available", icon: "checkmark.circle.fill")
                StatusRow(title: "Streaming library interface", detail: "UI scaffold", icon: "checkmark.circle")
                StatusRow(title: "Advanced gapless playback", detail: "Planned", icon: "clock")
                StatusRow(title: "Metadata writing and artwork search", detail: "Planned", icon: "clock")

                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text("Stage completion")
                        Spacer()
                        Text("62%").font(.caption.monospacedDigit())
                    }
                    ProgressView(value: 0.62)
                    Text("This percentage represents prototype feature coverage, not App Store readiness.")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                .padding(.vertical, 4)
            }
        }
        .navigationTitle("Settings")
        .scrollDismissesKeyboard(.interactively)
        .contentShape(Rectangle())
        .onTapGesture {
            isTextFieldFocused = false
            UIApplication.shared.endEditing()
        }
        .simultaneousGesture(
            DragGesture(minimumDistance: 45)
                .onEnded { value in
                    if value.startLocation.x < 36 && value.translation.width > 70 {
                        isTextFieldFocused = false
                        UIApplication.shared.endEditing()
                        openLibrary()
                    }
                }
        )
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button(action: openLibrary) { Label("Library", systemImage: "chevron.left") }
            }
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button("Done") {
                    isTextFieldFocused = false
                    UIApplication.shared.endEditing()
                }
            }
        }
    }
}

private struct RGBHexField: View {
    @Binding var hex: String
    @State private var red = "A8"
    @State private var green = "55"
    @State private var blue = "F7"
    @State private var selected: Channel = .red

    private enum Channel { case red, green, blue }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 4) {
                Text("#")
                    .foregroundStyle(.secondary)
                    .font(.title3.monospaced())
                channelField("Red", text: $red, color: .red, channel: .red)
                channelField("Green", text: $green, color: .green, channel: .green)
                channelField("Blue", text: $blue, color: .blue, channel: .blue)
                Spacer()
                RoundedRectangle(cornerRadius: 7)
                    .fill(Color(hex: combined) ?? .clear)
                    .frame(width: 34, height: 28)
                    .overlay(RoundedRectangle(cornerRadius: 7).stroke(.quaternary))
            }

            HStack {
                Text(selectedLabel + " channel")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(selectedColor)
                Spacer()
                Text(selectedValue)
                    .font(.caption.monospaced().weight(.semibold))
            }

            GeometryReader { proxy in
                Slider(
                    value: Binding(
                        get: { Double(selectedInteger) },
                        set: { setSelectedInteger(Int($0.rounded())) }
                    ),
                    in: 0...255,
                    step: 1
                )
                .tint(selectedColor)
                .frame(width: proxy.size.width * 0.8)
                .frame(maxWidth: .infinity, alignment: .center)
            }
            .frame(height: 32)

            Text("Tap a two-character value to edit it. The insertion point opens at the right edge.")
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .onAppear { loadFromHex() }
        .onChange(of: hex) { _, _ in loadFromHex() }
        .onChange(of: red) { _, value in red = sanitize(value); saveToHex() }
        .onChange(of: green) { _, value in green = sanitize(value); saveToHex() }
        .onChange(of: blue) { _, value in blue = sanitize(value); saveToHex() }
    }

    private func channelField(
        _ label: String,
        text: Binding<String>,
        color: Color,
        channel: Channel
    ) -> some View {
        HexChannelTextField(
            text: text,
            textColor: channel == .red ? .systemRed : (channel == .green ? .systemGreen : .systemBlue),
            onBeginEditing: { selected = channel }
        )
        .frame(width: 43, height: 32)
        .background(
            selected == channel ? color.opacity(0.16) : Color.secondary.opacity(0.12),
            in: RoundedRectangle(cornerRadius: 7)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 7)
                .stroke(selected == channel ? color : .clear, lineWidth: 1.5)
        )
        .accessibilityLabel(label + " hex value")
    }

    private var combined: String { red + green + blue }
    private var selectedValue: String { selected == .red ? red : selected == .green ? green : blue }
    private var selectedInteger: Int { Int(selectedValue, radix: 16) ?? 0 }
    private var selectedColor: Color { selected == .red ? .red : selected == .green ? .green : .blue }
    private var selectedLabel: String { selected == .red ? "Red" : selected == .green ? "Green" : "Blue" }

    private func setSelectedInteger(_ value: Int) {
        let formatted = String(format: "%02X", max(0, min(255, value)))
        switch selected {
        case .red: red = formatted
        case .green: green = formatted
        case .blue: blue = formatted
        }
    }

    private func sanitize(_ value: String) -> String {
        String(value.uppercased().filter { $0.isHexDigit }.prefix(2))
    }

    private func loadFromHex() {
        let cleaned = hex.uppercased().filter { $0.isHexDigit }
        let padded = String(cleaned.prefix(6)).padding(toLength: 6, withPad: "0", startingAt: 0)
        let values = [
            String(padded.prefix(2)),
            String(padded.dropFirst(2).prefix(2)),
            String(padded.dropFirst(4).prefix(2))
        ]
        if [red, green, blue] != values {
            red = values[0]
            green = values[1]
            blue = values[2]
        }
    }

    private func saveToHex() {
        guard red.count == 2, green.count == 2, blue.count == 2 else { return }
        if hex != combined { hex = combined }
    }
}

private struct HexChannelTextField: UIViewRepresentable {
    @Binding var text: String
    let textColor: UIColor
    let onBeginEditing: () -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    func makeUIView(context: Context) -> UITextField {
        let field = UITextField(frame: .zero)
        field.delegate = context.coordinator
        field.textAlignment = .center
        field.font = .monospacedSystemFont(ofSize: 19, weight: .semibold)
        field.textColor = textColor
        field.keyboardType = .asciiCapable
        field.autocapitalizationType = .allCharacters
        field.autocorrectionType = .no
        field.spellCheckingType = .no
        field.text = text
        field.addTarget(context.coordinator, action: #selector(Coordinator.textChanged(_:)), for: .editingChanged)

        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        toolbar.items = [
            UIBarButtonItem(systemItem: .flexibleSpace),
            UIBarButtonItem(title: "Done", style: .done, target: context.coordinator, action: #selector(Coordinator.done))
        ]
        field.inputAccessoryView = toolbar
        context.coordinator.textField = field
        return field
    }

    func updateUIView(_ uiView: UITextField, context: Context) {
        context.coordinator.parent = self
        uiView.textColor = textColor
        if uiView.text != text {
            uiView.text = text
            if uiView.isFirstResponder {
                moveCursorToEnd(uiView)
            }
        }
    }

    private func moveCursorToEnd(_ textField: UITextField) {
        let end = textField.endOfDocument
        textField.selectedTextRange = textField.textRange(from: end, to: end)
    }

    final class Coordinator: NSObject, UITextFieldDelegate {
        var parent: HexChannelTextField
        weak var textField: UITextField?

        init(parent: HexChannelTextField) {
            self.parent = parent
        }

        func textFieldDidBeginEditing(_ textField: UITextField) {
            parent.onBeginEditing()
            DispatchQueue.main.async {
                let end = textField.endOfDocument
                textField.selectedTextRange = textField.textRange(from: end, to: end)
            }
        }

        func textField(
            _ textField: UITextField,
            shouldChangeCharactersIn range: NSRange,
            replacementString string: String
        ) -> Bool {
            guard let current = textField.text,
                  let swiftRange = Range(range, in: current) else { return false }
            let proposed = current.replacingCharacters(in: swiftRange, with: string).uppercased()
            return proposed.count <= 2 && proposed.allSatisfy(\.isHexDigit)
        }

        @objc func textChanged(_ sender: UITextField) {
            let cleaned = String((sender.text ?? "").uppercased().filter { $0.isHexDigit }.prefix(2))
            if sender.text != cleaned { sender.text = cleaned }
            parent.text = cleaned
        }

        @objc func done() {
            textField?.resignFirstResponder()
        }
    }
}

private extension UIApplication {
    func endEditing() {
        sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

private struct ThemePreview: View {
    @EnvironmentObject private var settings: AppSettings

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Live Theme Preview").font(.subheadline.weight(.semibold))
            HStack(spacing: 12) {
                PlaceholderArtwork(symbol: "music.note", size: 62)
                VStack(alignment: .leading, spacing: 3) {
                    Text("Sample Album").font(.headline)
                    Text("Sample Artist").font(.caption).foregroundStyle(.secondary)
                    Text("01  First Track").font(.caption)
                }
                Spacer()
                Image(systemName: "pause.fill")
                Image(systemName: "forward.fill")
            }
            .padding(10)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
        }
        .foregroundStyle(settings.applyThemeColorToText ? settings.accentColor : Color.primary)
        .padding(.vertical, 4)
    }
}

private struct StatusRow: View {
    let title: String
    let detail: String
    let icon: String

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                Text(detail).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
        }
    }
}
