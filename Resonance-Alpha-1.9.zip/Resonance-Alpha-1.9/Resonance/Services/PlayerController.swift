import AVFoundation
import MediaPlayer
import UIKit

@MainActor
final class PlayerController: NSObject, ObservableObject, AVAudioPlayerDelegate {
    @Published private(set) var currentTrack: Track?
    @Published private(set) var isPlaying = false
    @Published private(set) var elapsed = 0.0
    @Published private(set) var duration = 0.0
    @Published private(set) var meterLevel = 0.0
    @Published var queue: [Track] = []

    private var audioPlayer: AVAudioPlayer?
    private var timer: Timer?
    private var index = 0
    private var lastNowPlayingProgressUpdate = 0.0

    override init() {
        super.init()
        configureSession()
        configureRemoteCommands()
    }

    func play(_ track: Track, in tracks: [Track]) {
        guard let newIndex = tracks.firstIndex(of: track) else { return }
        queue = tracks
        if loadAndPlay(track) {
            index = newIndex
        }
    }

    func toggle() {
        guard let audioPlayer else { return }
        if audioPlayer.isPlaying {
            audioPlayer.pause()
        } else {
            audioPlayer.play()
        }
        isPlaying = audioPlayer.isPlaying
        updateNowPlaying()
    }

    func next() {
        guard !queue.isEmpty else { return }
        let targetIndex = index + 1
        guard queue.indices.contains(targetIndex) else {
            stop()
            return
        }
        if loadAndPlay(queue[targetIndex]) {
            index = targetIndex
        }
    }

    func previous() {
        if elapsed > 3 {
            seek(to: 0)
            return
        }
        guard !queue.isEmpty else { return }
        let targetIndex = index - 1
        guard queue.indices.contains(targetIndex) else {
            seek(to: 0)
            return
        }
        if loadAndPlay(queue[targetIndex]) {
            index = targetIndex
        }
    }

    func stop() {
        timer?.invalidate()
        timer = nil
        audioPlayer?.delegate = nil
        audioPlayer?.stop()
        audioPlayer = nil
        isPlaying = false
        elapsed = 0
        duration = 0
        meterLevel = 0
        currentTrack = nil
        queue = []
        index = 0
        lastNowPlayingProgressUpdate = 0
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
    }

    func seek(to value: Double) {
        guard let audioPlayer else { return }
        let clamped = min(max(0, value), audioPlayer.duration)
        audioPlayer.currentTime = clamped
        elapsed = clamped
        updateNowPlayingProgress()
    }

    @discardableResult
    private func loadAndPlay(_ track: Track) -> Bool {
        guard let url = track.fileURL, FileManager.default.fileExists(atPath: url.path) else {
            clearUnplayableTrack()
            return false
        }

        timer?.invalidate()
        timer = nil
        audioPlayer?.delegate = nil
        audioPlayer?.stop()
        audioPlayer = nil
        isPlaying = false
        elapsed = 0
        meterLevel = 0

        do {
            let newPlayer = try AVAudioPlayer(contentsOf: url)
            newPlayer.delegate = self
            newPlayer.isMeteringEnabled = true
            newPlayer.prepareToPlay()
            audioPlayer = newPlayer

            guard newPlayer.play() else {
                clearUnplayableTrack()
                return false
            }

            currentTrack = track
            duration = newPlayer.duration
            elapsed = 0
            isPlaying = true
            lastNowPlayingProgressUpdate = 0
            startTimer()
            updateNowPlaying()
            return true
        } catch {
            clearUnplayableTrack()
            return false
        }
    }

    private func clearUnplayableTrack() {
        timer?.invalidate()
        timer = nil
        audioPlayer?.delegate = nil
        audioPlayer?.stop()
        audioPlayer = nil
        currentTrack = nil
        isPlaying = false
        elapsed = 0
        duration = 0
        meterLevel = 0
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
    }

    private func startTimer() {
        timer?.invalidate()
        let timer = Timer(timeInterval: 0.12, repeats: true) { [weak self] _ in
            Task { @MainActor in
                guard let self, let audioPlayer = self.audioPlayer else { return }
                self.elapsed = audioPlayer.currentTime
                audioPlayer.updateMeters()
                let decibels = audioPlayer.averagePower(forChannel: 0)
                let linear = pow(10.0, Double(decibels) / 20.0)
                self.meterLevel = audioPlayer.isPlaying ? min(1, max(0.06, linear * 4.5)) : 0.08

                if abs(self.elapsed - self.lastNowPlayingProgressUpdate) >= 0.8 {
                    self.lastNowPlayingProgressUpdate = self.elapsed
                    self.updateNowPlayingProgress()
                }
            }
        }
        self.timer = timer
        RunLoop.main.add(timer, forMode: .common)
    }

    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        guard let audioPlayer, player === audioPlayer else { return }
        if index + 1 < queue.count {
            next()
        } else {
            stop()
        }
    }

    func audioPlayerDecodeErrorDidOccur(_ player: AVAudioPlayer, error: Error?) {
        guard let audioPlayer, player === audioPlayer else { return }
        clearUnplayableTrack()
    }

    private func configureSession() {
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try? AVAudioSession.sharedInstance().setActive(true)
    }

    private func configureRemoteCommands() {
        let commands = MPRemoteCommandCenter.shared()
        commands.playCommand.addTarget { [weak self] _ in
            self?.toggle()
            return .success
        }
        commands.pauseCommand.addTarget { [weak self] _ in
            self?.toggle()
            return .success
        }
        commands.nextTrackCommand.addTarget { [weak self] _ in
            self?.next()
            return .success
        }
        commands.previousTrackCommand.addTarget { [weak self] _ in
            self?.previous()
            return .success
        }
        commands.changePlaybackPositionCommand.addTarget { [weak self] event in
            guard let event = event as? MPChangePlaybackPositionCommandEvent else { return .commandFailed }
            self?.seek(to: event.positionTime)
            return .success
        }
    }

    private func updateNowPlaying() {
        guard let track = currentTrack else { return }
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: track.title,
            MPMediaItemPropertyArtist: track.artist,
            MPMediaItemPropertyAlbumTitle: track.album,
            MPMediaItemPropertyPlaybackDuration: duration,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: elapsed,
            MPNowPlayingInfoPropertyPlaybackRate: isPlaying ? 1 : 0
        ]
        if let data = track.artworkData, let image = UIImage(data: data) {
            info[MPMediaItemPropertyArtwork] = MPMediaItemArtwork(boundsSize: image.size) { _ in image }
        }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }

    private func updateNowPlayingProgress() {
        guard var info = MPNowPlayingInfoCenter.default().nowPlayingInfo else {
            updateNowPlaying()
            return
        }
        info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = elapsed
        info[MPNowPlayingInfoPropertyPlaybackRate] = isPlaying ? 1 : 0
        info[MPMediaItemPropertyPlaybackDuration] = duration
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }
}
