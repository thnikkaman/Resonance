# Resonance Alpha 1.9

Open `Resonance.xcodeproj` in Xcode, choose your Apple development team, connect your iPhone, and run the app.

## Changes in Alpha 1.9

- Replaced the flashing Library Options menu with a stable options sheet.
- Applied Grid, Compact List, Large List, artwork-size, and text-size choices to the main Artists, Albums, and Songs screens.
- Added album artwork to the main Artists library view.
- Added artist album sorting by title, newest release date, or oldest release date.
- Added Grid/List switching inside each artist's album collection.
- Added an All Albums entry for every artist. Its queue is sorted by album title, track number, then track title.
- Reworked next, previous, and automatic queue advancement so the displayed title always matches the retained audio player.
- Added automatic playback of the next album track when a track finishes.
- Added a line-based, metered playing indicator beside the active track in library lists and grids.
- Shortened the Now Playing progress slider to 80% width.
- Added release-year extraction for FLAC Vorbis comments and common metadata formats, including database migration for existing libraries.
- Updated the hex channel fields so the cursor opens at the right edge of each two-character value.
- Kept document-relative imported-file paths so the existing library survives installation over the prior Alpha build.

## Testing notes

- Install this build over the previous Resonance development build using the same bundle identifier and signing configuration. Do not delete the app first if you want to preserve the on-device database and imported copies.
- Existing imported files are rescanned at launch, allowing release-year metadata to populate without re-importing.
- Automatic track advancement uses `AVAudioPlayerDelegate`. The advanced preloaded gapless engine remains planned for a later Alpha phase.
