import Foundation

struct RemoteLibraryManifest: Decodable, Sendable {
    let version: Int?
    let name: String?
    let tracks: [RemoteTrackRecord]
}

struct RemoteTrackRecord: Decodable, Sendable {
    let id: String?
    let title: String
    let artist: String
    let albumArtist: String?
    let album: String
    let trackNumber: Int?
    let discNumber: Int?
    let releaseYear: Int?
    let duration: Double?
    let fileSize: Int64?
    let path: String
    let artwork: String?
    let artworkBase64: String?
}

struct RemoteTrackItem: Identifiable, Hashable, Codable, Sendable {
    let id: UUID
    let title: String
    let artist: String
    let albumArtist: String
    let album: String
    let trackNumber: Int
    let discNumber: Int
    let releaseYear: Int
    let duration: Double
    let fileSizeBytes: Int64
    let streamURL: URL
    let artworkURL: URL?
    let artworkBase64: String?

    var albumKey: String { "\(albumArtist.lowercased())|\(album.lowercased())" }

    func asTrack(artworkData: Data?) -> Track {
        Track(
            id: id,
            title: title,
            artist: artist,
            albumArtist: albumArtist,
            album: album,
            trackNumber: trackNumber,
            discNumber: discNumber,
            releaseYear: releaseYear,
            duration: duration,
            fileURL: streamURL,
            artworkData: artworkData,
            artworkIsEmbedded: artworkData != nil,
            dateAdded: .distantPast,
            sourceByteSize: fileSizeBytes
        )
    }
}

struct RemoteAlbum: Identifiable, Hashable, Sendable {
    let id: String
    let title: String
    let artist: String
    let tracks: [RemoteTrackItem]

    var artworkURL: URL? { tracks.compactMap(\.artworkURL).first }
    var artworkBase64: String? { tracks.compactMap(\.artworkBase64).first }
    var releaseYear: Int { tracks.map(\.releaseYear).filter { $0 > 0 }.min() ?? 0 }
}

struct RemoteArtist: Identifiable, Hashable, Sendable {
    let id: String
    let name: String
    let albums: [RemoteAlbum]

    var artworkURL: URL? { albums.compactMap(\.artworkURL).first }
    var artworkBase64: String? { albums.compactMap(\.artworkBase64).first }
    var tracks: [RemoteTrackItem] { albums.flatMap(\.tracks) }
}

enum RemoteBrowseGrouping: String, CaseIterable, Identifiable {
    case artists = "Artists"
    case albums = "Albums"
    case songs = "Songs"
    var id: String { rawValue }
}

@MainActor
final class RemoteLibraryStore: ObservableObject {
    @Published private(set) var tracks: [RemoteTrackItem] = []
    @Published private(set) var serverName = "Remote Library"
    @Published private(set) var connectionStatus = "Not connected"
    @Published private(set) var lastRefresh: Date?
    @Published private(set) var isLoading = false
    @Published var searchText = ""
    @Published var grouping: RemoteBrowseGrouping = .artists

    private let artworkCache = NSCache<NSURL, NSData>()
    private static let cachedTracksURL: URL = {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        return base.appendingPathComponent("remote-library-cache.json")
    }()

    init() {
        if let data = try? Data(contentsOf: Self.cachedTracksURL),
           let cached = try? JSONDecoder().decode([RemoteTrackItem].self, from: data) {
            tracks = cached
            connectionStatus = cached.isEmpty ? "Not connected" : "Cached library available"
        }
    }

    var filteredTracks: [RemoteTrackItem] {
        let input = searchText.isEmpty ? tracks : tracks.filter {
            [$0.title, $0.artist, $0.albumArtist, $0.album]
                .contains { $0.localizedCaseInsensitiveContains(searchText) }
        }
        return input.sorted {
            ($0.artist, $0.album, $0.discNumber, $0.trackNumber, $0.title) <
            ($1.artist, $1.album, $1.discNumber, $1.trackNumber, $1.title)
        }
    }

    var albums: [RemoteAlbum] {
        Dictionary(grouping: filteredTracks, by: \.albumKey).map { key, values in
            let sorted = values.sorted {
                ($0.discNumber, $0.trackNumber, $0.title) < ($1.discNumber, $1.trackNumber, $1.title)
            }
            return RemoteAlbum(
                id: key,
                title: sorted.first?.album ?? "Unknown Album",
                artist: sorted.first?.albumArtist ?? "Unknown Artist",
                tracks: sorted
            )
        }
        .sorted { $0.title.localizedStandardCompare($1.title) == .orderedAscending }
    }

    var artists: [RemoteArtist] {
        Dictionary(grouping: albums, by: { $0.artist }).map { name, albums in
            RemoteArtist(
                id: name.lowercased(),
                name: name,
                albums: albums.sorted { $0.title.localizedStandardCompare($1.title) == .orderedAscending }
            )
        }
        .sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }

    func manifestURL(using settings: AppSettings) -> URL? {
        let rawHost = settings.streamHost.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !rawHost.isEmpty else { return nil }

        var components: URLComponents
        if rawHost.contains("://"), let supplied = URLComponents(string: rawHost) {
            components = supplied
        } else {
            components = URLComponents()
            components.scheme = settings.streamUseHTTPS ? "https" : "http"
            components.host = rawHost
        }

        if let port = Int(settings.streamPort), port > 0 { components.port = port }
        let configuredPath = settings.streamManifestPath.trimmingCharacters(in: .whitespacesAndNewlines)
        components.path = configuredPath.hasPrefix("/") ? configuredPath : "/" + configuredPath
        return components.url
    }

    func testConnection(using settings: AppSettings) async {
        guard let url = manifestURL(using: settings) else {
            connectionStatus = "Enter a server address first"
            return
        }
        isLoading = true
        connectionStatus = "Testing \(url.host ?? "server")…"
        defer { isLoading = false }

        do {
            let (data, response) = try await URLSession.shared.data(for: request(for: url))
            try validate(response: response, data: data)
            let manifest = try decodeManifest(data)
            connectionStatus = "Connected — \(manifest.tracks.count) tracks available"
        } catch {
            connectionStatus = "Connection failed: \(error.localizedDescription)"
        }
    }

    func refresh(using settings: AppSettings) async {
        guard let manifestURL = manifestURL(using: settings) else {
            connectionStatus = "Enter a server address in Settings"
            return
        }
        isLoading = true
        connectionStatus = "Loading remote library…"
        defer { isLoading = false }

        do {
            let (data, response) = try await URLSession.shared.data(for: request(for: manifestURL))
            try validate(response: response, data: data)
            let manifest = try decodeManifest(data)
            let resolved = manifest.tracks.compactMap { resolve($0, relativeTo: manifestURL) }
            tracks = resolved
            serverName = manifest.name?.trimmingCharacters(in: .whitespacesAndNewlines).nonEmpty ?? "Remote Library"
            lastRefresh = Date()
            connectionStatus = "Connected — \(resolved.count) tracks indexed"
            if let stored = try? JSONEncoder().encode(resolved) {
                try? stored.write(to: Self.cachedTracksURL, options: .atomic)
            }
        } catch {
            connectionStatus = "Refresh failed: \(error.localizedDescription)"
        }
    }

    func play(_ selected: RemoteTrackItem, in context: [RemoteTrackItem], using player: PlayerController) async {
        let ordered = context.isEmpty ? [selected] : context
        let prepared = await preparePlaybackTracks(ordered, priority: selected)
        guard let target = prepared.first(where: { $0.id == selected.id }) else { return }
        player.play(target, in: prepared)
    }

    func playAlbum(_ album: RemoteAlbum, using player: PlayerController, shuffle: Bool = false) async {
        let prepared = await preparePlaybackTracks(album.tracks, priority: album.tracks.first)
        guard !prepared.isEmpty else { return }
        if shuffle {
            player.shuffleAndPlay(prepared)
        } else if let first = prepared.first {
            player.play(first, in: prepared)
        }
    }

    func playArtist(_ artist: RemoteArtist, using player: PlayerController, shuffle: Bool = false) async {
        let ordered = artist.albums.flatMap(\.tracks)
        let prepared = await preparePlaybackTracks(ordered, priority: ordered.first)
        guard !prepared.isEmpty else { return }
        if shuffle {
            player.shuffleAndPlay(prepared)
        } else if let first = prepared.first {
            player.play(first, in: prepared)
        }
    }

    func artworkData(for item: RemoteTrackItem) async -> Data? {
        if let encoded = item.artworkBase64, let data = Data(base64Encoded: encoded) { return data }
        guard let url = item.artworkURL else { return nil }
        if let cached = artworkCache.object(forKey: url as NSURL) { return cached as Data }

        do {
            let (data, response) = try await URLSession.shared.data(for: request(for: url))
            guard let http = response as? HTTPURLResponse,
                  (200..<300).contains(http.statusCode),
                  data.count <= 12 * 1_048_576 else { return nil }
            artworkCache.setObject(data as NSData, forKey: url as NSURL)
            return data
        } catch {
            return nil
        }
    }

    private func preparePlaybackTracks(
        _ items: [RemoteTrackItem],
        priority: RemoteTrackItem?
    ) async -> [Track] {
        var artworkByKey: [String: Data] = [:]
        let prioritized = priority.map { [$0] } ?? []
        let uniqueArtworkItems = (prioritized + items).reduce(into: [RemoteTrackItem]()) { result, item in
            guard artworkByKey[item.albumKey] == nil,
                  !result.contains(where: { $0.albumKey == item.albumKey }) else { return }
            if result.count < 24 || item.id == priority?.id { result.append(item) }
        }

        for item in uniqueArtworkItems {
            if let data = await artworkData(for: item) { artworkByKey[item.albumKey] = data }
        }

        return items.map { item in
            item.asTrack(artworkData: artworkByKey[item.albumKey])
        }
    }

    private func request(for url: URL) -> URLRequest {
        var request = URLRequest(url: url)
        request.timeoutInterval = 15
        request.cachePolicy = .reloadRevalidatingCacheData
        request.setValue("application/json, audio/*, image/*;q=0.9, */*;q=0.1", forHTTPHeaderField: "Accept")
        return request
    }

    private func decodeManifest(_ data: Data) throws -> RemoteLibraryManifest {
        try JSONDecoder().decode(RemoteLibraryManifest.self, from: data)
    }

    private func validate(response: URLResponse, data: Data) throws {
        guard let http = response as? HTTPURLResponse else { throw RemoteLibraryError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else {
            throw RemoteLibraryError.httpStatus(http.statusCode, String(data: data.prefix(200), encoding: .utf8))
        }
    }

    private func resolve(_ record: RemoteTrackRecord, relativeTo manifestURL: URL) -> RemoteTrackItem? {
        guard let streamURL = URL(string: record.path, relativeTo: manifestURL)?.absoluteURL else { return nil }
        let artworkURL = record.artwork.flatMap { URL(string: $0, relativeTo: manifestURL)?.absoluteURL }
        let stableSource = record.id?.nonEmpty ?? streamURL.absoluteString
        return RemoteTrackItem(
            id: UUID(uuidString: stableSource) ?? Self.stableUUID(for: stableSource),
            title: record.title.nonEmpty ?? streamURL.deletingPathExtension().lastPathComponent,
            artist: record.artist.nonEmpty ?? "Unknown Artist",
            albumArtist: record.albumArtist?.nonEmpty ?? record.artist.nonEmpty ?? "Unknown Artist",
            album: record.album.nonEmpty ?? "Unknown Album",
            trackNumber: max(0, record.trackNumber ?? 0),
            discNumber: max(1, record.discNumber ?? 1),
            releaseYear: max(0, record.releaseYear ?? 0),
            duration: max(0, record.duration ?? 0),
            fileSizeBytes: max(0, record.fileSize ?? 0),
            streamURL: streamURL,
            artworkURL: artworkURL,
            artworkBase64: record.artworkBase64
        )
    }

    private static func stableUUID(for string: String) -> UUID {
        func hash(seed: UInt64) -> UInt64 {
            var value = seed
            for byte in string.utf8 {
                value ^= UInt64(byte)
                value &*= 1_099_511_628_211
            }
            return value
        }
        let high = hash(seed: 14_695_981_039_346_656_037)
        let low = hash(seed: 7_801_984_618_907_684_001)
        let raw = String(format: "%016llX%016llX", high, low)
        let uuidString = "\(raw.prefix(8))-\(raw.dropFirst(8).prefix(4))-\(raw.dropFirst(12).prefix(4))-\(raw.dropFirst(16).prefix(4))-\(raw.dropFirst(20).prefix(12))"
        return UUID(uuidString: uuidString) ?? UUID()
    }
}

enum RemoteLibraryError: LocalizedError {
    case invalidResponse
    case httpStatus(Int, String?)

    var errorDescription: String? {
        switch self {
        case .invalidResponse: return "The server returned an invalid response."
        case let .httpStatus(code, message):
            if let message = message?.trimmingCharacters(in: .whitespacesAndNewlines), !message.isEmpty {
                return "Server returned HTTP \(code): \(message)"
            }
            return "Server returned HTTP \(code)."
        }
    }
}

private extension String {
    var nonEmpty: String? { isEmpty ? nil : self }
}
