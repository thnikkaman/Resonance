# Resonance Alpha 3.4

Version 0.3.4, build 34.

## New phase: private remote-library beta

Alpha 3.4 turns the Streaming tab into a working HTTP/HTTPS remote-library browser designed for a server reached through Tailscale or a trusted LAN.

### iPhone features

- Connect with a Tailscale DNS name or IP address and an optional port.
- Choose HTTP or HTTPS.
- Configure the manifest path; the default is `/resonance/library.json`.
- Test the server connection from Settings.
- Index a JSON manifest without copying the remote library into the local SQLite database.
- Browse the remote library by Artists, Albums, or Songs.
- Search remote titles, artists, album artists, and albums.
- Pull to refresh or use the toolbar refresh button.
- Display remote album art from an artwork URL or Base64 manifest field.
- Play an individual remote track, album, artist, or shuffled artist collection.
- Stream through AVPlayer with HTTP byte-range support.
- Apply the 10–250 MB network buffer setting as a forward-buffer target based on the manifest file size and duration.
- Show live buffer status in Settings while a remote track is active.
- Cache the latest manifest for browsing after an app restart.

Remote playback is a beta and does not yet use the local gapless `AVAudioEngine` or the explicit 5.1 matrix. The local playback path verified in Alpha 3.3 remains unchanged.

## Included companion server

`Tools/ResonanceServer.py` provides the exact manifest and range-request protocol used by this build.

On the Mac or home server:

```bash
python3 -m pip install mutagen
python3 Tools/ResonanceServer.py "/path/to/Music" --port 8080
```

The script recursively scans the folder, reads common MP3/FLAC/M4A metadata and embedded artwork with Mutagen, publishes `/resonance/library.json`, and serves audio using HTTP byte ranges.

For Tailscale testing, enter the computer's Tailscale DNS name or Tailscale IP in Resonance, use port `8080`, leave HTTPS off, and retain the default manifest path. The test server has no application-level login; expose it only on a trusted LAN or Tailscale network.

## Manifest format

```json
{
  "version": 1,
  "name": "Home Music Library",
  "tracks": [
    {
      "id": "a-stable-uuid",
      "title": "Track title",
      "artist": "Artist",
      "albumArtist": "Album Artist",
      "album": "Album",
      "trackNumber": 1,
      "discNumber": 1,
      "releaseYear": 2026,
      "duration": 245.2,
      "fileSize": 73400320,
      "path": "/media/Artist/Album/01 Track.flac",
      "artwork": "/resonance/artwork/cover-id"
    }
  ]
}
```

`path` and `artwork` may be absolute URLs or URLs relative to the manifest. `artworkBase64` is also accepted.

## Test plan

1. Install directly over Alpha 3.3 without deleting the app.
2. Run the included server against a small test folder.
3. In Settings > Streaming Library, enter the server address, port 8080, HTTP, and the default manifest path.
4. Press Test Connection and then Refresh Remote Library.
5. Browse Artists, Albums, and Songs and verify artwork and metadata.
6. Play a remote track and verify lock-screen metadata, pause/resume, seeking, 15-second skips, next/previous, queue behavior, and background playback.
7. Change the network buffer budget during playback and verify the live buffer status updates.
8. Stop the server during playback and confirm Resonance reports a remote-stream failure rather than affecting the local library.
9. Play a local 5.1 FLAC afterward and confirm the Alpha 3.3 explicit routing remains unchanged.

## Compile preflight

Run `Tools/PreflightBuild.sh` on the Mac before device installation. It performs a clean unsigned simulator build with strict concurrency checking.
