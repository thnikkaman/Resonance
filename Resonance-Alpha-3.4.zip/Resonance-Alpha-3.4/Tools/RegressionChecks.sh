#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

find Resonance -name '*.swift' -print0 | xargs -0 -n1 swiftc -frontend -swift-version 6 -parse
plutil -lint Resonance/Info.plist
plutil -lint Resonance.xcodeproj/project.pbxproj
python3 -m py_compile Tools/ResonanceServer.py

python3 - <<'PY'
from pathlib import Path
root = Path('.')
pbx = (root / 'Resonance.xcodeproj/project.pbxproj').read_text()
metadata = (root / 'Resonance/Services/MetadataReader.swift').read_text()
smart = (root / 'Resonance/Views/SmartLibraryViews.swift').read_text()
player = (root / 'Resonance/Services/PlayerController.swift').read_text()
gapless = (root / 'Resonance/Services/GaplessAudioEngine.swift').read_text()
database = (root / 'Resonance/Services/LibraryDatabase.swift').read_text()
views = (root / 'Resonance/Views/PlayerViews.swift').read_text()
remote = (root / 'Resonance/Services/RemoteLibraryStore.swift').read_text()
settings = (root / 'Resonance/Services/AppSettings.swift').read_text()
streaming = (root / 'Resonance/Views/StreamingLibraryView.swift').read_text()
plist = (root / 'Resonance/Info.plist').read_text()

assert 'RemoteLibraryStore.swift in Sources' in pbx
assert 'StreamingLibraryView.swift in Sources' in pbx
assert pbx.count('CURRENT_PROJECT_VERSION = 34;') == 2
assert pbx.count('MARKETING_VERSION = 0.3.4;') == 2
assert '?? await' not in metadata
assert '?? try await' not in metadata
assert 'content:' in smart and 'header:' in smart
assert 'track.flatMap { player.artworkData(for: $0) }' in views
assert 'Timer(timeInterval:' not in player
assert 'deinit { sqlite3_close(db) }' not in database
assert 'appendPreloaded' in gapless and 'appendRemainder' in gapless
assert 'kAudioUnitSubType_MatrixMixer' in gapless
assert 'rear left → left only' in gapless
assert 'rear right → right only' in gapless
assert 'center → both' in gapless
assert 'LFE → both' in gapless
assert 'AVPlayerItem(url:' in player
assert 'preferredForwardBufferDuration' in player
assert 'networkBufferStatus' in player
assert '/resonance/library.json' in settings
assert 'RemoteBrowseGrouping' in remote
assert 'RemoteAlbumDetailView' in streaming
assert 'NSAllowsArbitraryLoads' in plist
print('Resonance Alpha 3.4 regression checks passed.')
PY
