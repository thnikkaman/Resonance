# Resonance Alpha 2.9

A SwiftUI iPhone music-player prototype with Finder/Files transfer, recursive indexing, SQLite storage, FLAC/Vorbis metadata parsing, embedded artwork, playback queues, favorites, smart collections, playlists, and persistent Resonance metadata edits.

## Install without erasing the library

Install Alpha 2.9 directly over Alpha 2.8 using the same bundle identifier and signing configuration. Do not delete the installed app first. Deleting it removes the app's Documents folder, SQLite database, favorites, recent-play history, playlists, metadata overrides, artist artwork overrides, and imported music.

## Requested fixes

### Swipe across the Now Playing artwork

- The left/right track swipe gesture now covers the complete artwork-and-metadata region.
- Swipe left over either the album cover or the text to play the next track.
- Swipe right over either region to play the previous track.
- The progress scrubber is outside this gesture region, so seeking does not change tracks.
- A normal tap on the artwork still opens the full-screen artwork viewer.

### Artist artwork warning border

- Custom artist display artwork no longer receives the red non-embedded artwork border.
- The red warning border remains available for album/track artwork that is cached in Resonance but not embedded in the audio file.
- Album covers selected as artist artwork are still kept separate from the underlying album artwork.

### Mini-player control spacing

- The mini-player transport controls are now placed in a dedicated control group with wider fixed spacing.
- Play/Pause and Next no longer sit directly beside one another.

## New phase feature: complete mini-player transport

- The mini-player now includes a dedicated Previous Track button.
- The mini-player provides evenly spaced Previous, Play/Pause, and Next controls.
- Previous follows the standard player behavior: restart the current track when more than three seconds have elapsed, otherwise move to the preceding queue item.
- All mini-player buttons include explicit accessibility labels and larger touch targets.

## Suggested Alpha 2.9 tests

1. Install over Alpha 2.8 and verify the existing library, playlists, favorites, metadata edits, and artist artwork remain.
2. Start playback and swipe left/right directly across the large Now Playing artwork.
3. Repeat the swipe over the title/artist/album text and confirm the same behavior.
4. Tap the artwork without dragging and confirm the full-screen artwork viewer still opens.
5. Drag the progress scrubber and confirm it seeks without changing tracks.
6. Assign custom artwork to an artist and confirm no red outline appears on the artist tile, artist header, All Albums tile, or artist editor preview.
7. Confirm cached non-embedded album artwork can still show the red outline when the setting is enabled.
8. Verify the mini-player shows clearly separated Previous, Play/Pause, and Next buttons and that each works.

## Compatibility baseline

Alpha 2.9 preserves the successful Alpha 2.1–2.8 compatibility fixes, including the two current-SDK `MetadataReader.swift` corrections, asynchronous AV metadata loading, Swift 6-safe `AVAudioPlayerDelegate` proxying, actor-safe database schema creation, safe Core Foundation ownership, Finder File Sharing, document-relative paths, and the resolved orientation and `withUnsafeBytes` warnings.

The locally applied Alpha 2.7 `SmartLibraryViews.swift` correction remains included: the previously problematic `Section` declarations use explicit `content`, `header`, and `footer` closures.
