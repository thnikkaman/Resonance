# Resonance Alpha 2.1

Open `Resonance.xcodeproj` in Xcode, choose your Apple development team, connect your iPhone, and run the app.

Install Alpha 2.1 over Alpha 2.0 using the same bundle identifier and signing configuration. Do not delete the existing app first if you want to preserve its database and imported music files.

## Corrected in Alpha 2.1

- Playback Queue rows now resolve artwork from every track and fall back to another track from the same album when an individual file has no embedded copy.
- The active track and every visible upcoming track now request their own artwork instead of depending on one shared queue image.
- The Streaming Library **Test Connection** button now uses the selected theme color with complementary text and icon colors.
- Manual scrubbing no longer seeks the audio repeatedly while a finger is moving. Playback continues normally during preview and performs one seek when the drag ends.
- Scrubbing to the exact final sample is guarded so it does not immediately trigger automatic queue advancement.

## New playback phase

- Added a custom progress scrubber with a time bubble above the finger.
- A drag covering 80% of the visible progress bar reaches the full track duration.
- Added **rewind 15 seconds** and **jump ahead 15 seconds** buttons to Now Playing.
- Added matching 15-second commands to Lock Screen and Control Center media controls when iOS presents those controls.
- Tap the large Now Playing artwork to open an in-app full-screen artwork view.
- Lock-screen artwork now uses the best available track or album fallback and returns a size-appropriate image to the system artwork request.

## iOS Lock Screen limitation

Resonance supplies artwork and playback commands through `MPNowPlayingInfoCenter` and `MPRemoteCommandCenter`. iOS decides whether the user sees compact or expanded/full-screen artwork and controls the appearance and colors of the system playback buttons. The app cannot force a full-screen Lock Screen layout or recolor Apple’s controls.

## Current-SDK warning cleanup

- Replaced deprecated direct reads of `AVMetadataItem.stringValue`, `numberValue`, and `dateValue` with asynchronous property loading.
- Moved `AVAudioPlayerDelegate` conformance to a non-actor delegate proxy that forwards events to the main actor.
- Made database schema creation static so actor initialization does not call an actor-isolated instance method.
- Reworked the AudioToolbox information-dictionary pointer using an explicitly managed `Unmanaged<CFDictionary>` value.
- Preserved the Alpha 1.9 fixes for the async-autoclosure and non-optional `Data` conditional-binding compiler diagnostics.

## What to test

1. Open Playback Queue and verify artwork appears beside the current track and every visible upcoming track.
2. Drag the progress bar while music is playing. Confirm the audio keeps playing at its current position until you release.
3. Confirm the time bubble stays above your finger and the thumb visibly follows the preview position.
4. Drag to the far end and confirm the release does not instantly jump to the next queue item.
5. Test both 15-second buttons near the central Play/Pause button.
6. Test 15-second skip commands from the Lock Screen or Control Center if iOS displays them.
7. Tap the large album artwork and test the full-screen in-app artwork view.
8. Test the Streaming Library **Test Connection** button with bright and dark theme colors.
9. Install over Alpha 2.0 without deleting it and confirm the existing imported library still plays.

## Still planned

- Preloaded lower-level gapless playback engine and configurable memory buffering
- Metadata/tag writing and batch editing
- Online artwork lookup and artwork embedding
- Functional private-server browsing and streaming
