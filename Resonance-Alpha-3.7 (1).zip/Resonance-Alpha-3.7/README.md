# Resonance Alpha 3.7

Version 0.3.7, build 37.

## Install

Open `Resonance.xcodeproj` in the current stable Xcode, select the same signing team and bundle identifier used for Alpha 3.6, and install over the existing app. Do not delete the installed app first.

## Streaming fixes

- Remote artist artwork is retained when changing grid size or layout.
- Artist entries are merged using stable server song IDs and normalized artist names.
- Artist browsing ignores album-artist capitalization differences when grouping the Artists view.
- Artist and Album Artist remain separate browse modes.
- Alphabet jumps use stable section anchors and do not animate through unrelated sections.
- A large letter bubble appears to the left of the finger while tapping or dragging the alphabet index.
- Remote prequeue insertion is checked with `AVQueuePlayer.canInsert` before insertion to prevent incompatible remote items from crashing playback.

## Cached remote catalog phase

- Navidrome catalog metadata is cached without storing authenticated stream URLs.
- The cached catalog is restored quickly after relaunch.
- Fresh authenticated stream and artwork URLs are rebuilt from Keychain credentials.
- On launch and foreground activation, Resonance checks the server album index for additions or removals.
- A full catalog rebuild happens only when the fingerprint changes, or when manually requested.
- Settings displays cache state, the last background check, and added/removed counts after a change.
- Background checks are rate-limited to once every five minutes rather than continuously polling.

## Suggested tests

1. Switch streaming artist artwork among Small, Medium, and Large and between grid/list layouts.
2. Confirm each performing artist appears once even when `ALBUMARTIST` differs only by case.
3. Tap and drag the alphabet index in local and streaming Artists views; verify the bubble and exact section jump.
4. Play remote FLAC, MP3, and M4A tracks and confirm no immediate crash.
5. Close and reopen Resonance; confirm the cached remote catalog appears before the server check finishes.
6. Add or remove music in Navidrome, reopen Resonance, and confirm the catalog change summary.
7. Use **Check for Remote Changes** and **Rebuild Remote Catalog** in Settings.
