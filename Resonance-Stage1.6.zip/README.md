# Resonance Prototype — Stage 1.6 Navigation, Keyboard & Library Controls

This revision builds on Stage 1.5 and addresses device-testing feedback.

## Changes in this build

- Mini-player is explicitly positioned above the bottom tab bar with additional clearance.
- Settings has a visible Library navigation button.
- A leftward swipe from Settings returns to Library.
- Settings text fields support keyboard dismissal by:
  - tapping outside a text field,
  - dragging the form/keyboard downward,
  - tapping the keyboard toolbar’s Done button.
- Main Library now has a clearly labeled **Library Options** menu containing:
  - Browse Library By,
  - Sort Order,
  - View Style,
  - View Options for artwork and text size.
- Compact list spacing remains reduced and now respects the selected artwork/text size.
- Streaming also has a visible Library button and swipe navigation.

## About the Files picker menu

The Icons/List and Name/Kind/Date/Size/Tags menu shown after tapping the add button is owned by Apple’s system Files picker. Third-party apps cannot relabel or reorganize that menu. Resonance now provides its own persistent library view and sorting controls directly on the main Library screen.

## Install

1. Unzip the project on your Mac.
2. Open `Resonance.xcodeproj` in Xcode.
3. Select the Resonance target, open **Signing & Capabilities**, and choose your Apple development team.
4. Connect and trust your iPhone.
5. Select the iPhone as the run destination and press Run.

## Current scope

This remains a prototype. Robust FLAC-specific decoding validation, true configurable gapless buffering, metadata writing, artwork repository lookup, server authentication, and remote audio streaming are not implemented yet.
