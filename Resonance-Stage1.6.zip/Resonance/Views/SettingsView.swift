import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var library: LibraryStore
    let openLibrary: () -> Void
    @FocusState private var isTextFieldFocused: Bool
    private let palette = ["A855F7", "3B82F6", "14B8A6", "22C55E", "EAB308", "F97316", "EF4444"]

    var body: some View {
        Form {
            Section("Appearance") {
                Picker("Theme", selection: $settings.appearance) {
                    Text("System").tag("system")
                    Text("Light").tag("light")
                    Text("Dark").tag("dark")
                }
                .pickerStyle(.segmented)

                HStack {
                    ForEach(palette, id: \.self) { hex in
                        Button { settings.accentHex = hex } label: {
                            Circle()
                                .fill(Color(hex: hex) ?? .purple)
                                .frame(width: 30, height: 30)
                                .overlay {
                                    if settings.normalizedAccentHex == hex {
                                        Image(systemName: "checkmark").foregroundStyle(.white)
                                    }
                                }
                        }
                        .buttonStyle(.plain)
                    }
                }

                VStack(alignment: .leading, spacing: 8) {
                    Text("Hex Color Code")
                        .font(.subheadline.weight(.semibold))
                    RGBHexField(hex: $settings.accentHex, isFocused: $isTextFieldFocused)
                }

                Toggle("Apply theme color to text", isOn: $settings.applyThemeColorToText)
                Toggle("Red outline for cached artwork", isOn: $settings.showArtworkWarning)

                ThemePreview()
            }

            Section("Playback") {
                Toggle("Preload next track", isOn: $settings.preloadNextTrack)
                LabeledContent("Local buffer", value: "\(Int(settings.localBufferMB)) MB")
                Slider(value: $settings.localBufferMB, in: 10...250, step: 10)
                Text("This prototype stores the buffer preference. The lower-level gapless engine remains a later-stage component.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Streaming Library") {
                TextField("Domain or IP address", text: $settings.streamHost)
                    .focused($isTextFieldFocused)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                TextField("Port (server default if blank)", text: $settings.streamPort)
                    .focused($isTextFieldFocused)
                    .keyboardType(.numberPad)
                LabeledContent("Streaming buffer", value: "\(Int(settings.networkBufferMB)) MB")
                Slider(value: $settings.networkBufferMB, in: 10...250, step: 10)
                Text("Tailscale provides private network access but does not define a universal audio port. Use the port configured by your chosen home music server.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Library") {
                Button("Restore demo library") { Task { await library.resetDemoLibrary() } }
            }

            Section("Prototype Status") {
                StatusRow(title: "Local import and indexing", detail: "Available", icon: "checkmark.circle.fill")
                StatusRow(title: "Artist → albums → numbered tracks", detail: "Available", icon: "checkmark.circle.fill")
                StatusRow(title: "Playback and lock-screen controls", detail: "Available", icon: "checkmark.circle.fill")
                StatusRow(title: "Persistent navigation and mini-player", detail: "Available", icon: "checkmark.circle.fill")
                StatusRow(title: "Streaming library interface", detail: "UI scaffold", icon: "checkmark.circle")
                StatusRow(title: "Advanced gapless playback", detail: "Planned", icon: "clock")
                StatusRow(title: "Metadata writing and artwork search", detail: "Planned", icon: "clock")

                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text("Stage completion")
                        Spacer()
                        Text("55%").font(.caption.monospacedDigit())
                    }
                    ProgressView(value: 0.55)
                    Text("This percentage represents prototype feature coverage, not App Store readiness.")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                .padding(.vertical, 4)
            }
        }
        .navigationTitle("Settings")
        .scrollDismissesKeyboard(.interactively)
        .contentShape(Rectangle())
        .onTapGesture { isTextFieldFocused = false }
        .simultaneousGesture(
            DragGesture(minimumDistance: 45)
                .onEnded { value in
                    if value.translation.width < -70 {
                        isTextFieldFocused = false
                        openLibrary()
                    }
                }
        )
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button(action: openLibrary) { Label("Library", systemImage: "chevron.left") }
            }
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button("Done") { isTextFieldFocused = false }
            }
        }
    }
}

private struct RGBHexField: View {
    @Binding var hex: String
    var isFocused: FocusState<Bool>.Binding
    @State private var red = "A8"
    @State private var green = "55"
    @State private var blue = "F7"

    var body: some View {
        HStack(spacing: 4) {
            Text("#").foregroundStyle(.secondary).font(.title3.monospaced())
            channelField($red, color: .red)
            channelField($green, color: .green)
            channelField($blue, color: .blue)
            Spacer()
            RoundedRectangle(cornerRadius: 7)
                .fill(Color(hex: combined) ?? .clear)
                .frame(width: 34, height: 28)
                .overlay(RoundedRectangle(cornerRadius: 7).stroke(.quaternary))
        }
        .onAppear { loadFromHex() }
        .onChange(of: hex) { _, _ in loadFromHex() }
        .onChange(of: red) { _, _ in saveToHex() }
        .onChange(of: green) { _, _ in saveToHex() }
        .onChange(of: blue) { _, _ in saveToHex() }
    }

    private var combined: String { red + green + blue }

    private func channelField(_ value: Binding<String>, color: Color) -> some View {
        TextField("00", text: value)
            .focused(isFocused)
            .textInputAutocapitalization(.characters)
            .autocorrectionDisabled()
            .multilineTextAlignment(.center)
            .font(.title3.monospaced().weight(.semibold))
            .foregroundStyle(color)
            .frame(width: 42)
            .padding(.vertical, 5)
            .background(.quaternary, in: RoundedRectangle(cornerRadius: 7))
            .onChange(of: value.wrappedValue) { _, newValue in
                let cleaned = newValue.uppercased().filter { $0.isHexDigit }
                value.wrappedValue = String(cleaned.prefix(2))
            }
    }

    private func loadFromHex() {
        let cleaned = hex.uppercased().filter { $0.isHexDigit }
        let padded = String(cleaned.prefix(6)).padding(toLength: 6, withPad: "0", startingAt: 0)
        red = String(padded.prefix(2))
        green = String(padded.dropFirst(2).prefix(2))
        blue = String(padded.dropFirst(4).prefix(2))
    }

    private func saveToHex() {
        guard red.count == 2, green.count == 2, blue.count == 2 else { return }
        let value = combined
        if hex != value { hex = value }
    }
}

private struct ThemePreview: View {
    @EnvironmentObject private var settings: AppSettings

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Live Theme Preview").font(.subheadline.weight(.semibold))
            HStack(spacing: 12) {
                PlaceholderArtwork(symbol: "music.note", size: 62)
                VStack(alignment: .leading, spacing: 3) {
                    Text("Sample Album").font(.headline)
                    Text("Sample Artist").font(.caption).foregroundStyle(.secondary)
                    Text("01  First Track").font(.caption)
                }
                Spacer()
                Image(systemName: "pause.fill")
                Image(systemName: "forward.fill")
            }
            .padding(10)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
        }
        .foregroundStyle(settings.applyThemeColorToText ? settings.accentColor : Color.primary)
        .padding(.vertical, 4)
    }
}

private struct StatusRow: View {
    let title: String
    let detail: String
    let icon: String

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                Text(detail).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
        }
    }
}
