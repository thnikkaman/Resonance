import SwiftUI
import UniformTypeIdentifiers

struct LibraryView: View {
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var settings: AppSettings
    @State private var importing = false

    var body: some View {
        Group {
            if library.isScanning { ProgressView("Indexing music…") }
            else {
                switch library.grouping {
                case .artists: ArtistListView(artists: library.artists)
                case .albumArtists: ArtistListView(artists: library.albumArtists)
                case .albums: AlbumCollectionView(albums: library.albums)
                case .songs: TrackListView(tracks: library.filteredTracks)
                }
            }
        }
        .navigationTitle("Library")
        .searchable(text: $library.searchText)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Menu {
                    Section("Browse Library By") {
                        Picker("Browse Library By", selection: $library.grouping) {
                            ForEach(LibraryGrouping.allCases) { Text($0.rawValue).tag($0) }
                        }
                    }

                    Section("Sort Order") {
                        Picker("Sort Order", selection: $library.sortDirection) {
                            ForEach(SortDirection.allCases) { direction in
                                Label(direction.rawValue, systemImage: direction == .ascending ? "arrow.up" : "arrow.down")
                                    .tag(direction)
                            }
                        }
                    }

                    Section("View Style") {
                        Picker("View Style", selection: $settings.albumLayout) {
                            Label("Album Artwork Grid", systemImage: "square.grid.3x3").tag(AlbumLayout.grid)
                            Label("Compact List", systemImage: "list.bullet").tag(AlbumLayout.compact)
                            Label("Large List", systemImage: "list.bullet.rectangle").tag(AlbumLayout.large)
                        }
                    }

                    Section("View Options") {
                        Picker("Artwork Size", selection: $settings.libraryThumbnailSize) {
                            ForEach(LibraryThumbnailSize.allCases) { Text($0.rawValue).tag($0) }
                        }
                        Picker("Text Size", selection: $settings.libraryTextSize) {
                            ForEach(LibraryTextSize.allCases) { Text($0.rawValue).tag($0) }
                        }
                    }
                } label: {
                    Label("Library Options", systemImage: "slider.horizontal.3")
                }
                .accessibilityLabel("Library view and sort options")
            }

            ToolbarItem(placement: .topBarTrailing) {
                Button { importing = true } label: { Image(systemName: "plus") }
                    .accessibilityLabel("Add music to library")
            }
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.audio, .folder], allowsMultipleSelection: true) { result in
            if case .success(let urls) = result { Task { await library.importURLs(urls) } }
        }
    }
}

struct ArtistListView: View {
    @EnvironmentObject private var settings: AppSettings
    let artists: [Artist]

    var body: some View {
        List(artists) { artist in
            NavigationLink(value: artist) {
                HStack(spacing: 10) {
                    PlaceholderArtwork(symbol: "person.fill", size: settings.libraryThumbnailSize.points)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(artist.name).font(settings.libraryTextSize.font.weight(.semibold)).lineLimit(1)
                        Text("\(artist.albums.count) album\(artist.albums.count == 1 ? "" : "s")")
                            .font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                    }
                }
                .padding(.vertical, settings.libraryTextSize == .compact ? 0 : 2)
            }
        }
        .navigationDestination(for: Artist.self) { artist in
            AlbumCollectionView(albums: artist.albums).navigationTitle(artist.name)
        }
    }
}

struct AlbumCollectionView: View {
    @EnvironmentObject private var settings: AppSettings
    let albums: [Album]
    private let columns = Array(repeating: GridItem(.flexible(), spacing: 12), count: 3)

    var body: some View {
        Group {
            if settings.albumLayout == .grid {
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 18) {
                        ForEach(albums) { album in
                            NavigationLink(value: album) { AlbumTile(album: album) }.buttonStyle(.plain)
                        }
                    }.padding()
                }
            } else {
                List(albums) { album in
                    NavigationLink(value: album) {
                        if settings.albumLayout == .compact {
                            HStack(spacing: 7) {
                                ArtworkView(data: album.artworkData, embedded: true, size: settings.libraryThumbnailSize.points)
                                Text(album.title)
                                    .font(settings.libraryTextSize.font.weight(.medium))
                                    .lineLimit(1)
                                Text("— \(album.artist)")
                                    .font(settings.libraryTextSize.font)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                            }
                            .padding(.vertical, 0)
                        } else {
                            HStack(spacing: 12) {
                                ArtworkView(data: album.artworkData, embedded: true, size: max(72, settings.libraryThumbnailSize.points * 2))
                                VStack(alignment: .leading) {
                                    Text(album.title).font(.headline)
                                    Text(album.artist).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                    .listRowInsets(EdgeInsets(top: settings.albumLayout == .compact ? 1 : 8, leading: 16, bottom: settings.albumLayout == .compact ? 1 : 8, trailing: 16))
                }
            }
        }
        .navigationDestination(for: Album.self) { AlbumDetailView(album: $0) }
    }
}

struct AlbumTile: View {
    @EnvironmentObject private var settings: AppSettings
    let album: Album

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ArtworkView(data: album.artworkData, embedded: true, size: 110)
                .frame(maxWidth: .infinity)
            Text(album.title).font(.caption.weight(.semibold)).lineLimit(1)
            Text(album.artist).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
        }
    }
}
