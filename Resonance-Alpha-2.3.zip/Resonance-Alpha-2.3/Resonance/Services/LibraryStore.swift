import Foundation
import UniformTypeIdentifiers

@MainActor
final class LibraryStore: ObservableObject {
    static let sharedMusicFolderName = "Resonance Music"

    @Published private(set) var tracks: [Track] = []
    @Published var isScanning = false
    @Published var searchText = ""
    @Published var grouping: LibraryGrouping = .artists
    @Published var sortDirection: SortDirection = .ascending
    @Published private(set) var lastSharedFolderScan: Date?
    @Published private(set) var sharedFolderTrackCount = 0
    @Published private(set) var sharedFolderIsReady = false
    @Published private(set) var scanStatus = "Waiting for first scan"
    @Published private(set) var favoriteTrackIDs: Set<UUID> = []
    @Published private(set) var recentPlayDates: [UUID: Date] = [:]
    @Published private(set) var playlists: [UserPlaylist] = []

    private let database = LibraryDatabase()
    private let reader = MetadataReader()
    private var knownModificationDates: [String: Date] = [:]
    private var didBootstrap = false

    private enum PersistenceKey {
        static let favorites = "resonance.favoriteTrackIDs"
        static let recentPlays = "resonance.recentPlayDates"
        static let playlists = "resonance.playlists"
    }

    init() {
        favoriteTrackIDs = Self.loadFavoriteIDs()
        recentPlayDates = Self.loadRecentPlayDates()
        playlists = Self.loadPlaylists()
    }

    var filteredTracks: [Track] {
        let base = searchText.isEmpty ? tracks : tracks.filter {
            [$0.title, $0.artist, $0.albumArtist, $0.album].contains { $0.localizedCaseInsensitiveContains(searchText) }
        }
        return base.sorted {
            let result = $0.title.localizedStandardCompare($1.title) == .orderedAscending
            return sortDirection == .ascending ? result : !result
        }
    }

    var artists: [Artist] { makeArtists(useAlbumArtist: false) }
    var albumArtists: [Artist] { makeArtists(useAlbumArtist: true) }
    var albums: [Album] { makeAlbums(from: filteredTracks) }

    var filteredPlaylists: [UserPlaylist] {
        guard !searchText.isEmpty else { return playlists }
        return playlists.filter { playlist in
            if playlist.name.localizedCaseInsensitiveContains(searchText) { return true }
            return tracks(in: playlist.id).contains { track in
                [track.title, track.artist, track.albumArtist, track.album]
                    .contains { $0.localizedCaseInsensitiveContains(searchText) }
            }
        }
    }

    var favoriteTracks: [Track] {
        filteredTracks.filter { favoriteTrackIDs.contains($0.id) }
    }

    var recentlyAddedTracks: [Track] {
        Array(filteredTracks.sorted { $0.dateAdded > $1.dateAdded }.prefix(100))
    }

    var recentlyPlayedTracks: [Track] {
        let byID = Dictionary(uniqueKeysWithValues: filteredTracks.map { ($0.id, $0) })
        return recentPlayDates
            .sorted { $0.value > $1.value }
            .compactMap { byID[$0.key] }
            .prefix(100)
            .map { $0 }
    }

    var sharedMusicFolderURL: URL {
        documentsURL.appendingPathComponent(Self.sharedMusicFolderName, isDirectory: true)
    }

    var sharedMusicFolderDisplayPath: String {
        "On My iPhone › Resonance Alpha › \(Self.sharedMusicFolderName)"
    }

    func bootstrap() async {
        guard !didBootstrap else { return }
        didBootstrap = true
        ensureSharedMusicFolder()

        let stored = await database.loadAll()
        tracks = stored
        await scanDocuments(forceMetadataRefresh: true)

        if tracks.isEmpty {
            tracks = Self.demoTracks
            scanStatus = "Shared folder ready — no transferred music found"
        }
    }

    func monitorSharedMusicFolder() async {
        while !Task.isCancelled {
            do {
                try await Task.sleep(for: .seconds(20))
            } catch {
                return
            }
            guard !Task.isCancelled else { return }
            await scanDocuments(forceMetadataRefresh: false)
        }
    }

    func scanSharedMusicFolder(forceMetadataRefresh: Bool = true) async {
        ensureSharedMusicFolder()
        await scanDocuments(forceMetadataRefresh: forceMetadataRefresh)
    }

    func importURLs(_ urls: [URL]) async {
        ensureSharedMusicFolder()
        isScanning = true
        scanStatus = "Copying selected music…"
        defer { isScanning = false }

        for selectedURL in urls {
            let accessed = selectedURL.startAccessingSecurityScopedResource()
            defer { if accessed { selectedURL.stopAccessingSecurityScopedResource() } }

            var isDirectory: ObjCBool = false
            FileManager.default.fileExists(atPath: selectedURL.path, isDirectory: &isDirectory)
            let sources = isDirectory.boolValue ? expandDirectory(selectedURL) : [selectedURL]
            let destinationRoot = isDirectory.boolValue
                ? sharedMusicFolderURL.appendingPathComponent(selectedURL.lastPathComponent, isDirectory: true)
                : sharedMusicFolderURL

            for source in sources {
                guard MetadataReader.supportedExtensions.contains(source.pathExtension.lowercased()) else { continue }
                let relativePath = isDirectory.boolValue
                    ? source.path.replacingOccurrences(of: selectedURL.path + "/", with: "")
                    : source.lastPathComponent
                let target = destinationRoot.appendingPathComponent(relativePath)

                do {
                    try FileManager.default.createDirectory(
                        at: target.deletingLastPathComponent(),
                        withIntermediateDirectories: true
                    )
                    if !FileManager.default.fileExists(atPath: target.path) {
                        try FileManager.default.copyItem(at: source, to: target)
                    }
                } catch {
                    continue
                }
            }
        }

        isScanning = false
        await scanDocuments(forceMetadataRefresh: false)
    }

    func isFavorite(_ track: Track) -> Bool {
        favoriteTrackIDs.contains(track.id)
    }

    func toggleFavorite(_ track: Track) {
        if favoriteTrackIDs.contains(track.id) {
            favoriteTrackIDs.remove(track.id)
        } else {
            favoriteTrackIDs.insert(track.id)
        }
        persistFavorites()
    }

    func isAlbumFavorite(_ album: Album) -> Bool {
        !album.tracks.isEmpty && album.tracks.allSatisfy { favoriteTrackIDs.contains($0.id) }
    }

    func toggleFavorite(_ album: Album) {
        let ids = Set(album.tracks.map(\.id))
        if ids.isSubset(of: favoriteTrackIDs) {
            favoriteTrackIDs.subtract(ids)
        } else {
            favoriteTrackIDs.formUnion(ids)
        }
        persistFavorites()
    }

    func markPlayed(_ track: Track) {
        recentPlayDates[track.id] = Date()
        if recentPlayDates.count > 250 {
            let retained = recentPlayDates.sorted { $0.value > $1.value }.prefix(200)
            recentPlayDates = Dictionary(uniqueKeysWithValues: retained.map { ($0.key, $0.value) })
        }
        persistRecentPlays()
    }

    @discardableResult
    func createPlaylist(named rawName: String) -> UUID? {
        let name = rawName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { return nil }
        let playlist = UserPlaylist(name: name)
        playlists.append(playlist)
        playlists.sort { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
        persistPlaylists()
        return playlist.id
    }

    func renamePlaylist(_ playlistID: UUID, to rawName: String) {
        let name = rawName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, let index = playlists.firstIndex(where: { $0.id == playlistID }) else { return }
        playlists[index].name = name
        playlists[index].modifiedAt = Date()
        playlists.sort { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
        persistPlaylists()
    }

    func deletePlaylist(_ playlistID: UUID) {
        playlists.removeAll { $0.id == playlistID }
        persistPlaylists()
    }

    func add(_ track: Track, to playlistID: UUID) {
        guard let index = playlists.firstIndex(where: { $0.id == playlistID }) else { return }
        guard !playlists[index].trackIDs.contains(track.id) else { return }
        playlists[index].trackIDs.append(track.id)
        playlists[index].modifiedAt = Date()
        persistPlaylists()
    }

    func remove(_ track: Track, from playlistID: UUID) {
        guard let index = playlists.firstIndex(where: { $0.id == playlistID }) else { return }
        playlists[index].trackIDs.removeAll { $0 == track.id }
        playlists[index].modifiedAt = Date()
        persistPlaylists()
    }

    func moveTracks(in playlistID: UUID, from offsets: IndexSet, to destination: Int) {
        guard let index = playlists.firstIndex(where: { $0.id == playlistID }) else { return }
        var ids = playlists[index].trackIDs
        let validOffsets = offsets.filter { ids.indices.contains($0) }.sorted()
        let moving = validOffsets.map { ids[$0] }
        for offset in validOffsets.reversed() { ids.remove(at: offset) }
        let removedBeforeDestination = validOffsets.filter { $0 < destination }.count
        let insertionIndex = max(0, min(ids.count, destination - removedBeforeDestination))
        ids.insert(contentsOf: moving, at: insertionIndex)
        playlists[index].trackIDs = ids
        playlists[index].modifiedAt = Date()
        persistPlaylists()
    }

    func playlist(id: UUID) -> UserPlaylist? {
        playlists.first { $0.id == id }
    }

    func tracks(in playlistID: UUID) -> [Track] {
        guard let playlist = playlist(id: playlistID) else { return [] }
        let byID = Dictionary(uniqueKeysWithValues: tracks.map { ($0.id, $0) })
        return playlist.trackIDs.compactMap { byID[$0] }
    }

    func removeArtist(_ artist: Artist) async {
        let ids = Set(artist.albums.flatMap(\.tracks).map(\.id))
        let removed = tracks.filter { ids.contains($0.id) }
        tracks.removeAll { ids.contains($0.id) }
        favoriteTrackIDs.subtract(ids)
        recentPlayDates = recentPlayDates.filter { !ids.contains($0.key) }
        for index in playlists.indices {
            playlists[index].trackIDs.removeAll { ids.contains($0) }
        }
        persistFavorites()
        persistRecentPlays()
        persistPlaylists()
        for track in removed {
            if let url = track.fileURL { try? FileManager.default.removeItem(at: url) }
        }
        await database.replaceAll(with: tracks.filter { $0.fileURL != nil })
        await scanDocuments(forceMetadataRefresh: false)
    }

    func resetDemoLibrary() async {
        tracks = Self.demoTracks
        await database.replaceAll(with: [])
    }

    private var documentsURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    private func ensureSharedMusicFolder() {
        do {
            try FileManager.default.createDirectory(
                at: sharedMusicFolderURL,
                withIntermediateDirectories: true
            )
            sharedFolderIsReady = true
        } catch {
            sharedFolderIsReady = false
            scanStatus = "Could not create the shared music folder"
        }
    }

    private func scanDocuments(forceMetadataRefresh: Bool) async {
        guard !isScanning else { return }
        isScanning = true
        scanStatus = "Scanning transferred music…"
        defer { isScanning = false }

        let urls = allDocumentAudioURLs()
        let sharedRootPath = sharedMusicFolderURL.standardizedFileURL.path + "/"
        sharedFolderTrackCount = urls.filter {
            $0.standardizedFileURL.path.hasPrefix(sharedRootPath)
        }.count

        let currentPaths = Set(urls.map(normalizedPath))
        let existingByPath = Dictionary(
            uniqueKeysWithValues: tracks.compactMap { track -> (String, Track)? in
                guard let url = track.fileURL else { return nil }
                return (normalizedPath(url), track)
            }
        )

        let knownPaths = Set(existingByPath.keys)
        let modificationsChanged = urls.contains { url in
            let path = normalizedPath(url)
            return knownModificationDates[path] != modificationDate(for: url)
        }
        let needsRefresh = forceMetadataRefresh || currentPaths != knownPaths || modificationsChanged

        guard needsRefresh else {
            lastSharedFolderScan = Date()
            scanStatus = "Up to date — \(sharedFolderTrackCount) file\(sharedFolderTrackCount == 1 ? "" : "s") in \(Self.sharedMusicFolderName)"
            return
        }

        var refreshed: [Track] = []
        var newModificationDates: [String: Date] = [:]

        for url in urls {
            let path = normalizedPath(url)
            let modified = modificationDate(for: url)
            newModificationDates[path] = modified
            let existing = existingByPath[path]
            let changed = knownModificationDates[path] != modified

            if !forceMetadataRefresh, !changed, let existing {
                refreshed.append(existing)
                continue
            }

            if let parsed = await reader.track(from: url) {
                refreshed.append(preservingIdentity(of: parsed, existing: existing))
            } else if let existing {
                refreshed.append(existing)
            }
        }

        knownModificationDates = newModificationDates
        tracks = deduplicate(refreshed)
        cleanPersistedCollections()
        await database.replaceAll(with: tracks)
        lastSharedFolderScan = Date()
        scanStatus = "Indexed \(tracks.count) track\(tracks.count == 1 ? "" : "s")"
    }

    private func preservingIdentity(of parsed: Track, existing: Track?) -> Track {
        guard let existing else { return parsed }
        return Track(
            id: existing.id,
            title: parsed.title,
            artist: parsed.artist,
            albumArtist: parsed.albumArtist,
            album: parsed.album,
            trackNumber: parsed.trackNumber,
            discNumber: parsed.discNumber,
            releaseYear: parsed.releaseYear,
            duration: parsed.duration,
            fileURL: parsed.fileURL,
            artworkData: parsed.artworkData ?? existing.artworkData,
            artworkIsEmbedded: parsed.artworkData != nil ? parsed.artworkIsEmbedded : existing.artworkIsEmbedded,
            dateAdded: existing.dateAdded
        )
    }

    private func allDocumentAudioURLs() -> [URL] {
        expandDirectory(documentsURL)
            .sorted { $0.path.localizedStandardCompare($1.path) == .orderedAscending }
    }

    private func expandDirectory(_ url: URL) -> [URL] {
        let keys: [URLResourceKey] = [.isRegularFileKey, .contentModificationDateKey]
        let enumerator = FileManager.default.enumerator(
            at: url,
            includingPropertiesForKeys: keys,
            options: [.skipsHiddenFiles, .skipsPackageDescendants]
        )
        return (enumerator?.allObjects as? [URL] ?? []).filter {
            MetadataReader.supportedExtensions.contains($0.pathExtension.lowercased())
        }
    }

    private func modificationDate(for url: URL) -> Date {
        (try? url.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
    }

    private func normalizedPath(_ url: URL) -> String {
        url.standardizedFileURL.resolvingSymlinksInPath().path
    }

    private func deduplicate(_ input: [Track]) -> [Track] {
        Array(
            Dictionary(
                grouping: input,
                by: { $0.fileURL.map(normalizedPath) ?? $0.id.uuidString }
            ).compactMap(\.value.last)
        )
    }

    private func makeArtists(useAlbumArtist: Bool) -> [Artist] {
        let groups = Dictionary(grouping: filteredTracks) { useAlbumArtist ? $0.albumArtist : $0.artist }
        let mapped = groups.map { Artist(id: $0.key, name: $0.key, albums: makeAlbums(from: $0.value)) }
        return mapped.sorted {
            sortDirection == .ascending
                ? $0.name.localizedStandardCompare($1.name) == .orderedAscending
                : $0.name.localizedStandardCompare($1.name) == .orderedDescending
        }
    }

    private func makeAlbums(from tracks: [Track]) -> [Album] {
        Dictionary(grouping: tracks, by: { "\($0.albumArtist)|\($0.album)" }).map { key, values in
            let sorted = values.sorted { ($0.discNumber, $0.trackNumber, $0.title) < ($1.discNumber, $1.trackNumber, $1.title) }
            return Album(
                id: key,
                title: sorted.first?.album ?? "Unknown Album",
                artist: sorted.first?.albumArtist ?? "Unknown Artist",
                tracks: sorted
            )
        }.sorted {
            sortDirection == .ascending
                ? $0.title.localizedStandardCompare($1.title) == .orderedAscending
                : $0.title.localizedStandardCompare($1.title) == .orderedDescending
        }
    }

    private func cleanPersistedCollections() {
        let validIDs = Set(tracks.map(\.id))
        favoriteTrackIDs.formIntersection(validIDs)
        recentPlayDates = recentPlayDates.filter { validIDs.contains($0.key) }
        persistFavorites()
        persistRecentPlays()
    }

    private func persistFavorites() {
        UserDefaults.standard.set(favoriteTrackIDs.map(\.uuidString), forKey: PersistenceKey.favorites)
    }

    private func persistRecentPlays() {
        let stored = Dictionary(uniqueKeysWithValues: recentPlayDates.map { ($0.key.uuidString, $0.value.timeIntervalSince1970) })
        if let data = try? JSONEncoder().encode(stored) {
            UserDefaults.standard.set(data, forKey: PersistenceKey.recentPlays)
        }
    }

    private func persistPlaylists() {
        if let data = try? JSONEncoder().encode(playlists) {
            UserDefaults.standard.set(data, forKey: PersistenceKey.playlists)
        }
    }

    private static func loadFavoriteIDs() -> Set<UUID> {
        let values = UserDefaults.standard.stringArray(forKey: PersistenceKey.favorites) ?? []
        return Set(values.compactMap(UUID.init(uuidString:)))
    }

    private static func loadRecentPlayDates() -> [UUID: Date] {
        guard let data = UserDefaults.standard.data(forKey: PersistenceKey.recentPlays),
              let stored = try? JSONDecoder().decode([String: Double].self, from: data) else { return [:] }
        var result: [UUID: Date] = [:]
        for (key, value) in stored {
            guard let id = UUID(uuidString: key) else { continue }
            result[id] = Date(timeIntervalSince1970: value)
        }
        return result
    }

    private static func loadPlaylists() -> [UserPlaylist] {
        guard let data = UserDefaults.standard.data(forKey: PersistenceKey.playlists),
              let decoded = try? JSONDecoder().decode([UserPlaylist].self, from: data) else { return [] }
        return decoded.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }

    static let demoTracks: [Track] = [
        Track(title: "Glass Horizon", artist: "Northstar", album: "Night Signals", trackNumber: 1, releaseYear: 2024, duration: 254),
        Track(title: "Between Stations", artist: "Northstar", album: "Night Signals", trackNumber: 2, releaseYear: 2024, duration: 221),
        Track(title: "Afterimage", artist: "Northstar", album: "Night Signals", trackNumber: 3, releaseYear: 2024, duration: 289),
        Track(title: "Slow Current", artist: "Northstar", album: "Tidal Memory", trackNumber: 1, releaseYear: 2021, duration: 312),
        Track(title: "Low Light", artist: "Violet Static", album: "Soft Machines", trackNumber: 1, releaseYear: 2023, duration: 198),
        Track(title: "Signal Bloom", artist: "Violet Static", album: "Soft Machines", trackNumber: 2, releaseYear: 2023, duration: 247),
        Track(title: "Open Circuit", artist: "Violet Static", album: "Soft Machines", trackNumber: 3, releaseYear: 2023, duration: 230)
    ]
}
