import SwiftUI

struct AlbumDetailView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var player: PlayerController
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var settings: AppSettings
    let album: Album

    var body: some View {
        List {
            Section {
                VStack(spacing: 12) {
                    ArtworkView(
                        data: album.artworkData,
                        embedded: album.artworkIsEmbedded,
                        size: 220
                    )
                    Text(album.title).font(.title2.bold())
                    Text(album.artist).foregroundStyle(.secondary)
                    if album.releaseYear > 0 {
                        Text(String(album.releaseYear))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Button {
                        if let first = album.tracks.first {
                            player.play(first, in: album.tracks)
                        }
                    } label: {
                        Label("Play Album", systemImage: "play.fill")
                            .foregroundStyle(settings.contrastingAccentTextColor)
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(settings.accentColor)
                }
                .frame(maxWidth: .infinity)
                .listRowBackground(Color.clear)
            }

            Section("Tracks") {
                ForEach(album.tracks) { track in
                    Button { player.play(track, in: album.tracks) } label: {
                        TrackListRow(
                            track: track,
                            leadingNumber: track.trackNumber > 0 ? "\(track.trackNumber)" : "–",
                            showsArtwork: false,
                            large: false,
                            showsAlbum: false
                        )
                    }
                    .buttonStyle(.plain)
                    .trackLibraryActions(track)
                }
            }
        }
        .navigationTitle(album.title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button { dismiss() } label: {
                    Label("Back", systemImage: "chevron.left")
                }
            }
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button { library.toggleFavorite(album) } label: {
                    Image(systemName: library.isAlbumFavorite(album) ? "heart.fill" : "heart")
                }
                .accessibilityLabel(library.isAlbumFavorite(album) ? "Remove album from favorites" : "Add album to favorites")

                Menu {
                    if library.playlists.isEmpty {
                        Button("Create a playlist first") { }
                            .disabled(true)
                    } else {
                        ForEach(library.playlists) { playlist in
                            Button(playlist.name) {
                                for track in album.tracks {
                                    library.add(track, to: playlist.id)
                                }
                            }
                        }
                    }
                } label: {
                    Image(systemName: "text.badge.plus")
                }
                .accessibilityLabel("Add album to playlist")
            }
        }
        .contentShape(Rectangle())
        .gesture(
            DragGesture(minimumDistance: 45)
                .onEnded { value in
                    if value.startLocation.x < 36 && value.translation.width > 70 {
                        dismiss()
                    }
                }
        )
    }
}

struct AllAlbumsTrackListView: View {
    @EnvironmentObject private var player: PlayerController
    @EnvironmentObject private var settings: AppSettings
    let artistName: String
    let tracks: [Track]

    var body: some View {
        List {
            if let first = tracks.first {
                Section {
                    Button { player.play(first, in: tracks) } label: {
                        Label("Play All Albums", systemImage: "play.fill")
                            .foregroundStyle(settings.contrastingAccentTextColor)
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(settings.accentColor)
                }
            }

            ForEach(Array(Dictionary(grouping: tracks, by: \.album).keys.sorted()), id: \.self) { albumName in
                Section(albumName) {
                    ForEach(tracks.filter { $0.album == albumName }) { track in
                        Button { player.play(track, in: tracks) } label: {
                            TrackListRow(
                                track: track,
                                leadingNumber: track.trackNumber > 0 ? "\(track.trackNumber)" : "–",
                                showsArtwork: false,
                                large: false,
                                showsAlbum: false
                            )
                        }
                        .buttonStyle(.plain)
                        .trackLibraryActions(track)
                    }
                }
            }
        }
        .navigationTitle("All Albums")
        .navigationBarTitleDisplayMode(.inline)
        .safeAreaInset(edge: .top, spacing: 0) {
            Text(artistName)
                .font(.caption)
                .foregroundStyle(.secondary)
                .padding(.vertical, 5)
                .frame(maxWidth: .infinity)
                .background(.bar)
        }
    }
}

struct TrackListRow: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var library: LibraryStore
    let track: Track
    var leadingNumber: String? = nil
    var showsArtwork: Bool
    var large: Bool
    var showsAlbum: Bool

    var body: some View {
        HStack(spacing: large ? 12 : 8) {
            if showsArtwork {
                ArtworkView(
                    data: track.artworkData,
                    embedded: track.artworkIsEmbedded,
                    size: large ? max(70, settings.libraryThumbnailSize.points * 1.8) : settings.libraryThumbnailSize.points
                )
            }

            if let leadingNumber {
                Text(leadingNumber)
                    .foregroundStyle(.secondary)
                    .frame(width: 28, alignment: .trailing)
            }

            PlayingTrackVisualizer(track: track)

            VStack(alignment: .leading, spacing: large ? 4 : 1) {
                Text(track.title)
                    .font(settings.libraryTextSize.font.weight(.medium))
                    .lineLimit(1)
                if showsAlbum {
                    Text("\(track.artist) — \(track.album)")
                        .font(large ? .subheadline : .caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                } else {
                    Text(track.artist)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
            }

            Spacer()
            if library.isFavorite(track) {
                Image(systemName: "heart.fill")
                    .font(.caption)
                    .foregroundStyle(.tint)
                    .accessibilityLabel("Favorite")
            }
            Text(format(track.duration))
                .font(.caption.monospacedDigit())
                .foregroundStyle(.secondary)
        }
        .contentShape(Rectangle())
    }
}

struct PlayingTrackVisualizer: View {
    @EnvironmentObject private var player: PlayerController
    let track: Track

    private var isCurrent: Bool { player.currentTrack?.id == track.id }
    private let multipliers: [CGFloat] = [0.72, 1.0, 0.58, 0.88]

    var body: some View {
        HStack(alignment: .center, spacing: 1.5) {
            ForEach(Array(multipliers.enumerated()), id: \.offset) { index, multiplier in
                Capsule()
                    .frame(
                        width: 2,
                        height: isCurrent
                            ? max(3, 4 + CGFloat(player.meterLevel) * 14 * multiplier + CGFloat(index % 2) * 1.5)
                            : 2
                    )
            }
        }
        .frame(width: 13, height: 22)
        .foregroundStyle(isCurrent ? Color.accentColor : Color.clear)
        .animation(.linear(duration: 0.12), value: player.meterLevel)
        .accessibilityHidden(true)
    }
}

func format(_ seconds: Double) -> String {
    guard seconds.isFinite, seconds > 0 else { return "—:—" }
    return String(format: "%d:%02d", Int(seconds) / 60, Int(seconds) % 60)
}
