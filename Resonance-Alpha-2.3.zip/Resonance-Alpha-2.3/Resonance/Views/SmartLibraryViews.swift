import SwiftUI

struct SmartTrackCollectionView: View {
    let title: String
    let tracks: [Track]
    let systemImage: String
    let emptyDescription: String

    var body: some View {
        if tracks.isEmpty {
            ContentUnavailableView(
                title,
                systemImage: systemImage,
                description: Text(emptyDescription)
            )
        } else {
            VStack(spacing: 0) {
                HStack {
                    Label(title, systemImage: systemImage)
                        .font(.headline)
                    Spacer()
                    Text("\(tracks.count) track\(tracks.count == 1 ? "" : "s")")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(.horizontal)
                .padding(.vertical, 10)
                .background(.bar)

                TrackCollectionView(tracks: tracks)
            }
        }
    }
}

struct PlaylistCollectionView: View {
    @EnvironmentObject private var library: LibraryStore
    @State private var showingNewPlaylist = false
    @State private var newPlaylistName = ""

    var body: some View {
        List {
            Section {
                Button {
                    newPlaylistName = ""
                    showingNewPlaylist = true
                } label: {
                    Label("New Playlist", systemImage: "plus.circle.fill")
                }
            }

            Section("Your Playlists") {
                if library.filteredPlaylists.isEmpty {
                    ContentUnavailableView(
                        "No Playlists",
                        systemImage: "music.note.list",
                        description: Text("Create a playlist, then add tracks from a track’s menu or the Now Playing screen.")
                    )
                    .listRowBackground(Color.clear)
                } else {
                    ForEach(library.filteredPlaylists) { playlist in
                        NavigationLink {
                            PlaylistDetailView(playlistID: playlist.id)
                        } label: {
                            PlaylistRow(playlist: playlist)
                        }
                        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                            Button(role: .destructive) {
                                library.deletePlaylist(playlist.id)
                            } label: {
                                Label("Delete", systemImage: "trash")
                            }
                        }
                    }
                }
            }
        }
        .alert("New Playlist", isPresented: $showingNewPlaylist) {
            TextField("Playlist name", text: $newPlaylistName)
            Button("Cancel", role: .cancel) { }
            Button("Create") {
                _ = library.createPlaylist(named: newPlaylistName)
            }
            .disabled(newPlaylistName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        } message: {
            Text("Enter a name for the new playlist.")
        }
    }
}

private struct PlaylistRow: View {
    @EnvironmentObject private var library: LibraryStore
    let playlist: UserPlaylist

    private var tracks: [Track] { library.tracks(in: playlist.id) }

    var body: some View {
        HStack(spacing: 12) {
            if let first = tracks.first {
                ArtworkView(
                    data: first.artworkData,
                    embedded: first.artworkIsEmbedded,
                    size: 54
                )
            } else {
                PlaceholderArtwork(symbol: "music.note.list", size: 54)
            }

            VStack(alignment: .leading, spacing: 3) {
                Text(playlist.name)
                    .font(.headline)
                    .lineLimit(1)
                Text("\(tracks.count) track\(tracks.count == 1 ? "" : "s")")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }
}

struct PlaylistDetailView: View {
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var player: PlayerController
    @EnvironmentObject private var settings: AppSettings
    @State private var showingRename = false
    @State private var renameText = ""
    let playlistID: UUID

    private var playlist: UserPlaylist? { library.playlist(id: playlistID) }
    private var tracks: [Track] { library.tracks(in: playlistID) }

    var body: some View {
        Group {
            if let playlist {
                List {
                    Section {
                        VStack(spacing: 10) {
                            PlaceholderArtwork(symbol: "music.note.list", size: 116)
                            Text(playlist.name)
                                .font(.title2.bold())
                            Text("\(tracks.count) track\(tracks.count == 1 ? "" : "s")")
                                .font(.caption)
                                .foregroundStyle(.secondary)

                            Button {
                                if let first = tracks.first {
                                    player.play(first, in: tracks)
                                }
                            } label: {
                                Label("Play Playlist", systemImage: "play.fill")
                                    .foregroundStyle(settings.contrastingAccentTextColor)
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(settings.accentColor)
                            .disabled(tracks.isEmpty)
                        }
                        .frame(maxWidth: .infinity)
                        .listRowBackground(Color.clear)
                    }

                    Section("Tracks") {
                        if tracks.isEmpty {
                            ContentUnavailableView(
                                "Playlist Is Empty",
                                systemImage: "music.note.list",
                                description: Text("Add tracks using the menu on a song or from Now Playing.")
                            )
                            .listRowBackground(Color.clear)
                        } else {
                            ForEach(tracks) { track in
                                Button {
                                    player.play(track, in: tracks)
                                } label: {
                                    TrackListRow(
                                        track: track,
                                        showsArtwork: true,
                                        large: false,
                                        showsAlbum: true
                                    )
                                }
                                .buttonStyle(.plain)
                                .trackLibraryActions(track)
                                .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                    Button(role: .destructive) {
                                        library.remove(track, from: playlistID)
                                    } label: {
                                        Label("Remove", systemImage: "minus.circle")
                                    }
                                }
                            }
                            .onMove { offsets, destination in
                                library.moveTracks(in: playlistID, from: offsets, to: destination)
                            }
                        }
                    }
                }
                .navigationTitle(playlist.name)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItemGroup(placement: .topBarTrailing) {
                        EditButton()
                        Button {
                            renameText = playlist.name
                            showingRename = true
                        } label: {
                            Label("Rename Playlist", systemImage: "pencil")
                        }
                    }
                }
            } else {
                ContentUnavailableView("Playlist Not Found", systemImage: "exclamationmark.triangle")
            }
        }
        .alert("Rename Playlist", isPresented: $showingRename) {
            TextField("Playlist name", text: $renameText)
            Button("Cancel", role: .cancel) { }
            Button("Save") {
                library.renamePlaylist(playlistID, to: renameText)
            }
            .disabled(renameText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
    }
}

struct AddToPlaylistMenu: View {
    @EnvironmentObject private var library: LibraryStore
    let track: Track

    var body: some View {
        if library.playlists.isEmpty {
            Button { } label: {
                Label("Create a playlist first", systemImage: "music.note.list")
            }
            .disabled(true)
        } else {
            Menu {
                ForEach(library.playlists) { playlist in
                    Button {
                        library.add(track, to: playlist.id)
                    } label: {
                        Label(playlist.name, systemImage: "plus")
                    }
                }
            } label: {
                Label("Add to Playlist", systemImage: "text.badge.plus")
            }
        }
    }
}

private struct TrackLibraryActionsModifier: ViewModifier {
    @EnvironmentObject private var library: LibraryStore
    let track: Track

    func body(content: Content) -> some View {
        content.contextMenu {
            Button {
                library.toggleFavorite(track)
            } label: {
                Label(
                    library.isFavorite(track) ? "Remove from Favorites" : "Add to Favorites",
                    systemImage: library.isFavorite(track) ? "heart.slash" : "heart"
                )
            }
            AddToPlaylistMenu(track: track)
        }
    }
}

extension View {
    func trackLibraryActions(_ track: Track) -> some View {
        modifier(TrackLibraryActionsModifier(track: track))
    }
}
