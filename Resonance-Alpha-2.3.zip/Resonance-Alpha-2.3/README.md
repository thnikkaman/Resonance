# Resonance Alpha 2.3

A SwiftUI iPhone music-player prototype with local Finder/Files transfer, recursive folder indexing, SQLite storage, FLAC/Vorbis metadata parsing, embedded artwork, playback queues, shuffle/repeat, sleep timer, precision scrubbing, lock-screen controls, favorites, smart collections, and persistent playlists.

## Install without erasing the library

Install Alpha 2.3 over Alpha 2.2 using the same bundle identifier and signing configuration. Do not delete the installed app first. Deleting it removes the app's Documents folder, SQLite database, favorites, recent-play history, playlists, and imported music.

## New in Alpha 2.3

### Favorites

- Favorite or unfavorite the current track from Now Playing.
- Press and hold a track in an album, song list, smart collection, or playlist for Favorite controls.
- Favorite or unfavorite an entire album from the Album screen toolbar.
- Favorite tracks display a small heart in list rows.
- Favorites persist across launches and installs over the existing app.

### Smart library collections

The **Browse Library By** section now includes:

- Favorites
- Recently Added
- Recently Played
- Playlists

Recently Added retains the 100 newest imported tracks. Recently Played retains the 100 most recently started tracks. Search continues to filter the selected collection.

### Playlists

- Create named playlists.
- Add tracks from a track's press-and-hold menu.
- Add the current track from the Now Playing toolbar.
- Add an entire album from the Album screen toolbar.
- Play a playlist as a queue.
- Reorder playlist tracks using Edit mode.
- Remove individual tracks with a swipe.
- Rename or delete playlists.
- Playlist membership uses stable track identifiers and survives normal folder rescans.

### Library database migration

- Added a persistent `date_added` value to the SQLite track table.
- Existing Alpha 2.2 rows are migrated automatically.
- Existing tracks use their file creation/modification date when the older database has no saved import date.

## Finder transfer workflow

1. Launch Resonance once so the `Resonance Music` folder exists.
2. Connect the iPhone to the Mac.
3. Select the iPhone in Finder and open **Files**.
4. Open **Resonance Alpha > Resonance Music**.
5. Drop in audio files, artist folders, or complete folder trees.
6. Bring Resonance to the foreground or press the scan button.

## Supported local extensions

FLAC, MP3, M4A, AAC, WAV, AIFF/AIF, CAF, and ALAC.

## Build

1. Open `Resonance.xcodeproj` in Xcode.
2. Select the Resonance target and the same Apple development team used for Alpha 2.2.
3. Keep the existing bundle identifier.
4. Connect the iPhone, select it as the run destination, and press Run.

The project targets iOS 17 and is configured for iPhone portrait use.

## Suggested Alpha 2.3 tests

1. Install over Alpha 2.2 and confirm the existing music library still plays.
2. Favorite a track from Now Playing and verify it appears under **Library Options > Favorites**.
3. Press and hold a different track and add it to Favorites.
4. Favorite an album and confirm all album tracks appear in Favorites.
5. Start several tracks in a different order and verify **Recently Played** uses that order.
6. Add a new album through Finder and verify it appears near the top of **Recently Added**.
7. Create a playlist, add tracks from multiple albums, and add the current track from Now Playing.
8. Reorder playlist tracks, remove one, rename the playlist, and confirm the changes survive an app restart.
9. Force a shared-folder rescan and confirm favorites and playlists remain intact.
10. Search while viewing Favorites, Recently Added, Recently Played, and Playlists.

## Compatibility baseline

Alpha 2.3 preserves the successful Alpha 2.2 compatibility baseline, including:

- the two `MetadataReader.swift` current-SDK fixes,
- asynchronous AV metadata loading,
- Swift 6-safe `AVAudioPlayerDelegate` proxying,
- actor-safe database schema creation,
- safe Core Foundation dictionary ownership,
- Finder File Sharing and document-relative paths,
- the resolved `withUnsafeBytes` and orientation warnings.
