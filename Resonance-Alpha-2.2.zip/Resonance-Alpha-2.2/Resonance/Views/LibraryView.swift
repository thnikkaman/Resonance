import SwiftUI
import UniformTypeIdentifiers

struct LibraryView: View {
    @EnvironmentObject private var library: LibraryStore
    @State private var importing = false
    @State private var showingLibraryOptions = false

    var body: some View {
        Group {
            if library.isScanning {
                ProgressView("Indexing music…")
            } else {
                switch library.grouping {
                case .artists:
                    ArtistCollectionView(artists: library.artists)
                case .albumArtists:
                    ArtistCollectionView(artists: library.albumArtists)
                case .albums:
                    AlbumCollectionView(albums: library.albums)
                case .songs:
                    TrackCollectionView(tracks: library.filteredTracks)
                }
            }
        }
        .navigationTitle("Library")
        .searchable(text: $library.searchText)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button { showingLibraryOptions = true } label: {
                    Label("Library Options", systemImage: "slider.horizontal.3")
                }
                .accessibilityLabel("Library view and sort options")
            }

            ToolbarItemGroup(placement: .topBarTrailing) {
                Button {
                    Task { await library.scanSharedMusicFolder(forceMetadataRefresh: true) }
                } label: {
                    if library.isScanning {
                        ProgressView()
                    } else {
                        Image(systemName: "arrow.clockwise")
                    }
                }
                .disabled(library.isScanning)
                .accessibilityLabel("Scan Resonance Music folder")

                Button { importing = true } label: { Image(systemName: "plus") }
                    .accessibilityLabel("Add music to library")
            }
        }
        .sheet(isPresented: $showingLibraryOptions) {
            LibraryOptionsSheet()
                .presentationDetents([.medium, .large])
        }
        .fileImporter(
            isPresented: $importing,
            allowedContentTypes: [.audio, .folder],
            allowsMultipleSelection: true
        ) { result in
            if case .success(let urls) = result {
                Task { await library.importURLs(urls) }
            }
        }
    }
}

private struct LibraryOptionsSheet: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var settings: AppSettings

    var body: some View {
        NavigationStack {
            Form {
                Section("Browse Library By") {
                    Picker("Library grouping", selection: $library.grouping) {
                        ForEach(LibraryGrouping.allCases) { grouping in
                            Text(grouping.rawValue).tag(grouping)
                        }
                    }
                    .pickerStyle(.inline)
                    .labelsHidden()
                }

                Section("Sort Order") {
                    Picker("Sort direction", selection: $library.sortDirection) {
                        ForEach(SortDirection.allCases) { direction in
                            Label(
                                direction.rawValue,
                                systemImage: direction == .ascending ? "arrow.up" : "arrow.down"
                            )
                            .tag(direction)
                        }
                    }
                    .pickerStyle(.segmented)
                }

                Section("View Style") {
                    Picker("Library view style", selection: $settings.albumLayout) {
                        ForEach(AlbumLayout.allCases) { layout in
                            Text(layout.displayName).tag(layout)
                        }
                    }
                    .pickerStyle(.inline)
                    .labelsHidden()
                }

                Section("View Options") {
                    Picker("Artwork size", selection: $settings.libraryThumbnailSize) {
                        ForEach(LibraryThumbnailSize.allCases) { size in
                            Text(size.rawValue).tag(size)
                        }
                    }
                    Picker("Text size", selection: $settings.libraryTextSize) {
                        ForEach(LibraryTextSize.allCases) { size in
                            Text(size.rawValue).tag(size)
                        }
                    }
                }
            }
            .navigationTitle("Library Options")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}

struct ArtistCollectionView: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var library: LibraryStore
    @State private var artistToRemove: Artist?
    let artists: [Artist]

    private var gridColumns: [GridItem] {
        Array(
            repeating: GridItem(.flexible(), spacing: 12),
            count: settings.libraryThumbnailSize.gridColumnCount
        )
    }

    var body: some View {
        Group {
            switch settings.albumLayout {
            case .grid:
                ScrollView {
                    LazyVGrid(columns: gridColumns, spacing: 18) {
                        ForEach(artists) { artist in
                            NavigationLink(value: artist) {
                                ArtistTile(artist: artist)
                            }
                            .buttonStyle(.plain)
                            .contextMenu {
                                Button(role: .destructive) { artistToRemove = artist } label: {
                                    Label("Remove Artist from Library", systemImage: "trash")
                                }
                            }
                        }
                    }
                    .padding()
                }

            case .compact, .large:
                List(artists) { artist in
                    NavigationLink(value: artist) {
                        ArtistListRow(artist: artist, large: settings.albumLayout == .large)
                    }
                    .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                        Button(role: .destructive) { artistToRemove = artist } label: {
                            Label("Remove Artist", systemImage: "trash")
                        }
                    }
                    .contextMenu {
                        Button(role: .destructive) { artistToRemove = artist } label: {
                            Label("Remove Artist from Library", systemImage: "trash")
                        }
                    }
                    .listRowInsets(
                        EdgeInsets(
                            top: settings.albumLayout == .compact ? 2 : 8,
                            leading: 16,
                            bottom: settings.albumLayout == .compact ? 2 : 8,
                            trailing: 16
                        )
                    )
                }
            }
        }
        .alert(
            "Remove artist?",
            isPresented: Binding(
                get: { artistToRemove != nil },
                set: { if !$0 { artistToRemove = nil } }
            )
        ) {
            Button("Cancel", role: .cancel) { artistToRemove = nil }
            Button("Remove", role: .destructive) {
                if let artist = artistToRemove {
                    Task { await library.removeArtist(artist) }
                }
                artistToRemove = nil
            }
        } message: {
            Text("This removes the artist’s imported audio files from Resonance’s local library.")
        }
        .navigationDestination(for: Artist.self) { artist in
            ArtistDetailView(artist: artist)
        }
    }
}

private struct ArtistTile: View {
    @EnvironmentObject private var settings: AppSettings
    let artist: Artist

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ArtworkView(
                data: artist.artworkData,
                embedded: artist.artworkIsEmbedded,
                size: settings.libraryThumbnailSize.gridArtworkPoints
            )
            .frame(maxWidth: .infinity)

            Text(artist.name)
                .font(settings.libraryTextSize.font.weight(.semibold))
                .lineLimit(1)
            Text("\(artist.albums.count) album\(artist.albums.count == 1 ? "" : "s")")
                .font(.caption2)
                .foregroundStyle(.secondary)
                .lineLimit(1)
        }
    }
}

private struct ArtistListRow: View {
    @EnvironmentObject private var settings: AppSettings
    let artist: Artist
    let large: Bool

    var body: some View {
        HStack(spacing: large ? 12 : 7) {
            ArtworkView(
                data: artist.artworkData,
                embedded: artist.artworkIsEmbedded,
                size: large ? max(76, settings.libraryThumbnailSize.points * 2) : settings.libraryThumbnailSize.points
            )
            VStack(alignment: .leading, spacing: large ? 4 : 1) {
                Text(artist.name)
                    .font(settings.libraryTextSize.font.weight(.semibold))
                    .lineLimit(1)
                Text("\(artist.albums.count) album\(artist.albums.count == 1 ? "" : "s")")
                    .font(large ? .subheadline : .caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
        }
    }
}

struct ArtistDetailView: View {
    @EnvironmentObject private var settings: AppSettings
    let artist: Artist

    private var sortedAlbums: [Album] {
        switch settings.artistAlbumSort {
        case .title:
            return artist.albums.sorted {
                $0.title.localizedStandardCompare($1.title) == .orderedAscending
            }
        case .newest:
            return artist.albums.sorted {
                if $0.releaseYear == $1.releaseYear {
                    return $0.title.localizedStandardCompare($1.title) == .orderedAscending
                }
                return $0.releaseYear > $1.releaseYear
            }
        case .oldest:
            return artist.albums.sorted {
                if $0.releaseYear == $1.releaseYear {
                    return $0.title.localizedStandardCompare($1.title) == .orderedAscending
                }
                if $0.releaseYear == 0 { return false }
                if $1.releaseYear == 0 { return true }
                return $0.releaseYear < $1.releaseYear
            }
        }
    }

    private var allTracks: [Track] {
        artist.albums.flatMap(\.tracks).sorted { lhs, rhs in
            let albumComparison = lhs.album.localizedStandardCompare(rhs.album)
            if albumComparison != .orderedSame { return albumComparison == .orderedAscending }
            if lhs.trackNumber != rhs.trackNumber { return lhs.trackNumber < rhs.trackNumber }
            return lhs.title.localizedStandardCompare(rhs.title) == .orderedAscending
        }
    }

    private var gridColumns: [GridItem] {
        Array(
            repeating: GridItem(.flexible(), spacing: 12),
            count: settings.libraryThumbnailSize.gridColumnCount
        )
    }

    var body: some View {
        VStack(spacing: 0) {
            VStack(spacing: 10) {
                Picker("Album sort", selection: $settings.artistAlbumSort) {
                    ForEach(ArtistAlbumSort.allCases) { sort in
                        Text(sort.rawValue).tag(sort)
                    }
                }
                .pickerStyle(.menu)
                .frame(maxWidth: .infinity, alignment: .leading)

                Picker("Album view", selection: $settings.artistAlbumLayout) {
                    Label("Grid", systemImage: "square.grid.2x2").tag(ArtistAlbumLayout.grid)
                    Label("List", systemImage: "list.bullet").tag(ArtistAlbumLayout.list)
                }
                .pickerStyle(.segmented)
            }
            .padding(.horizontal)
            .padding(.vertical, 10)
            .background(.bar)

            if settings.artistAlbumLayout == .grid {
                ScrollView {
                    LazyVGrid(columns: gridColumns, spacing: 18) {
                        NavigationLink {
                            AllAlbumsTrackListView(artistName: artist.name, tracks: allTracks)
                        } label: {
                            AllAlbumsTile(artist: artist)
                        }
                        .buttonStyle(.plain)

                        ForEach(sortedAlbums) { album in
                            NavigationLink(value: album) {
                                AlbumTile(album: album)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding()
                }
            } else {
                List {
                    NavigationLink {
                        AllAlbumsTrackListView(artistName: artist.name, tracks: allTracks)
                    } label: {
                        HStack(spacing: 12) {
                            PlaceholderArtwork(symbol: "square.stack.3d.up.fill", size: 58)
                            VStack(alignment: .leading, spacing: 3) {
                                Text("All Albums").font(.headline)
                                Text("\(allTracks.count) tracks, grouped by album")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }

                    ForEach(sortedAlbums) { album in
                        NavigationLink(value: album) {
                            HStack(spacing: 12) {
                                ArtworkView(
                                    data: album.artworkData,
                                    embedded: album.artworkIsEmbedded,
                                    size: 58
                                )
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(album.title).font(settings.libraryTextSize.font.weight(.semibold)).lineLimit(1)
                                    Text(album.yearLabel)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle(artist.name)
        .navigationDestination(for: Album.self) { album in
            AlbumDetailView(album: album)
        }
    }
}

private struct AllAlbumsTile: View {
    @EnvironmentObject private var settings: AppSettings
    let artist: Artist

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ZStack {
                ArtworkView(
                    data: artist.artworkData,
                    embedded: artist.artworkIsEmbedded,
                    size: settings.libraryThumbnailSize.gridArtworkPoints
                )
                Color.black.opacity(0.28)
                    .frame(
                        width: settings.libraryThumbnailSize.gridArtworkPoints,
                        height: settings.libraryThumbnailSize.gridArtworkPoints
                    )
                    .clipShape(RoundedRectangle(cornerRadius: max(8, settings.libraryThumbnailSize.gridArtworkPoints * 0.08)))
                Image(systemName: "square.stack.3d.up.fill")
                    .font(.title2)
                    .foregroundStyle(.white)
            }
            Text("All Albums")
                .font(settings.libraryTextSize.font.weight(.semibold))
                .lineLimit(1)
            Text("\(artist.albums.flatMap(\.tracks).count) tracks")
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
    }
}

struct AlbumCollectionView: View {
    @EnvironmentObject private var settings: AppSettings
    let albums: [Album]

    private var columns: [GridItem] {
        Array(
            repeating: GridItem(.flexible(), spacing: 12),
            count: settings.libraryThumbnailSize.gridColumnCount
        )
    }

    var body: some View {
        Group {
            if settings.albumLayout == .grid {
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 18) {
                        ForEach(albums) { album in
                            NavigationLink(value: album) {
                                AlbumTile(album: album)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding()
                }
            } else {
                List(albums) { album in
                    NavigationLink(value: album) {
                        if settings.albumLayout == .compact {
                            HStack(spacing: 7) {
                                ArtworkView(
                                    data: album.artworkData,
                                    embedded: album.artworkIsEmbedded,
                                    size: settings.libraryThumbnailSize.points
                                )
                                Text(album.title)
                                    .font(settings.libraryTextSize.font.weight(.medium))
                                    .lineLimit(1)
                                Text("— \(album.artist)")
                                    .font(settings.libraryTextSize.font)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                            }
                            .padding(.vertical, 0)
                        } else {
                            HStack(spacing: 12) {
                                ArtworkView(
                                    data: album.artworkData,
                                    embedded: album.artworkIsEmbedded,
                                    size: max(76, settings.libraryThumbnailSize.points * 2)
                                )
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(album.title).font(settings.libraryTextSize.font.weight(.semibold))
                                    Text(album.artist).foregroundStyle(.secondary)
                                    Text(album.yearLabel).font(.caption).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                    .listRowInsets(
                        EdgeInsets(
                            top: settings.albumLayout == .compact ? 2 : 8,
                            leading: 16,
                            bottom: settings.albumLayout == .compact ? 2 : 8,
                            trailing: 16
                        )
                    )
                }
            }
        }
        .navigationDestination(for: Album.self) { album in
            AlbumDetailView(album: album)
        }
    }
}

struct AlbumTile: View {
    @EnvironmentObject private var settings: AppSettings
    let album: Album

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ArtworkView(
                data: album.artworkData,
                embedded: album.artworkIsEmbedded,
                size: settings.libraryThumbnailSize.gridArtworkPoints
            )
            .frame(maxWidth: .infinity)
            Text(album.title)
                .font(settings.libraryTextSize.font.weight(.semibold))
                .lineLimit(1)
            Text(album.releaseYear > 0 ? "\(album.artist) • \(album.releaseYear)" : album.artist)
                .font(.caption2)
                .foregroundStyle(.secondary)
                .lineLimit(1)
        }
    }
}

struct TrackCollectionView: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var player: PlayerController
    let tracks: [Track]

    private var columns: [GridItem] {
        Array(
            repeating: GridItem(.flexible(), spacing: 12),
            count: max(2, settings.libraryThumbnailSize.gridColumnCount - 1)
        )
    }

    var body: some View {
        Group {
            if settings.albumLayout == .grid {
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 18) {
                        ForEach(tracks) { track in
                            Button { player.play(track, in: tracks) } label: {
                                VStack(alignment: .leading, spacing: 6) {
                                    ArtworkView(
                                        data: track.artworkData,
                                        embedded: track.artworkIsEmbedded,
                                        size: settings.libraryThumbnailSize.gridArtworkPoints
                                    )
                                    HStack(spacing: 5) {
                                        PlayingTrackVisualizer(track: track)
                                        Text(track.title)
                                            .font(settings.libraryTextSize.font.weight(.semibold))
                                            .lineLimit(1)
                                    }
                                    Text("\(track.artist) — \(track.album)")
                                        .font(.caption2)
                                        .foregroundStyle(.secondary)
                                        .lineLimit(1)
                                }
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding()
                }
            } else {
                List(tracks) { track in
                    Button { player.play(track, in: tracks) } label: {
                        TrackListRow(
                            track: track,
                            showsArtwork: true,
                            large: settings.albumLayout == .large,
                            showsAlbum: true
                        )
                    }
                    .buttonStyle(.plain)
                    .listRowInsets(
                        EdgeInsets(
                            top: settings.albumLayout == .compact ? 2 : 7,
                            leading: 16,
                            bottom: settings.albumLayout == .compact ? 2 : 7,
                            trailing: 16
                        )
                    )
                }
            }
        }
    }
}
