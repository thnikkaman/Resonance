# Resonance Alpha 2.2

A SwiftUI iPhone music-player prototype with Finder/Files transfer support, automatic local-folder indexing, SQLite library storage, FLAC/Vorbis metadata parsing, album artwork, playback queues, shuffle/repeat, sleep timer, precision scrubbing, and lock-screen controls.

## Install without erasing the library

Install Alpha 2.2 over Alpha 2.1 using the same bundle identifier and signing configuration. Do not delete the installed app first, because deleting it removes the app's Documents folder, database, and imported music.

## New in Alpha 2.2

- Enabled Apple File Sharing for the app.
- Creates a `Resonance Music` folder in the app's Documents directory on first launch.
- The app appears in Finder under your connected iPhone's **Files** section.
- Music and entire folder trees dropped into `Resonance Music` are indexed in place.
- The same folder is available in the iPhone Files app under **On My iPhone > Resonance Alpha > Resonance Music**.
- Scans for added, changed, and deleted audio files:
  - on first launch,
  - whenever the app becomes active,
  - every 20 seconds while the app remains active,
  - or when the manual scan button is pressed.
- Added a Finder File Sharing status section in Settings.
- Added a manual shared-folder scan button to the Library toolbar.
- Preserves existing track identities when rescanning so queues and library references remain stable.
- Fixed the unused `withUnsafeBytes` result warning in `LibraryDatabase.swift`.
- Configured the target as an iPhone-only portrait app to remove the previous interface-orientation warning.

## Transfer music with Finder

1. Install and launch Resonance Alpha 2.2 once so the shared folder is created.
2. Connect the iPhone to the Mac with USB or Wi-Fi syncing enabled.
3. Open Finder and select the iPhone in the sidebar.
4. Open the **Files** tab.
5. Select **Resonance Alpha**.
6. Open `Resonance Music` and drag in audio files or folders containing subfolders.
7. Bring Resonance to the foreground. It will scan automatically, or press the circular-arrow button in the Library toolbar.

## Supported local extensions

FLAC, MP3, M4A, AAC, WAV, AIFF/AIF, CAF, and ALAC.

## Build

1. Open `Resonance.xcodeproj` in Xcode.
2. Select the Resonance target and your Apple development team.
3. Keep the existing bundle identifier if installing over Alpha 2.1.
4. Connect your iPhone, select it as the run destination, and press Run.

The project targets iOS 17 and is configured for iPhone portrait use.

## Suggested Alpha 2.2 tests

- Confirm Resonance Alpha appears in Finder's Files tab after launching it once.
- Confirm the `Resonance Music` folder appears.
- Drop one album folder and then a larger artist folder containing album subfolders.
- Bring the app forward and confirm the files appear without using the plus importer.
- Add another file while Resonance stays open and wait up to 20 seconds for it to appear.
- Rename or replace a file and use the manual scan button.
- Delete a transferred audio file in Finder and confirm it disappears after the next scan.
- Confirm the existing Alpha 2.1 library and playback features still work.
