# Resonance Alpha 3.1

A SwiftUI iPhone music-player prototype with Finder/Files transfer, recursive indexing, SQLite storage, FLAC/Vorbis metadata parsing, embedded artwork, playback queues, favorites, smart collections, playlists, persistent metadata edits, artist artwork overrides, and an experimental preloaded gapless engine.

## Install without erasing the library

Install Alpha 3.1 directly over Alpha 3.0 using the same bundle identifier and signing configuration. Do not delete the installed app first. Deleting it removes the app's Documents folder, SQLite database, favorites, recent-play history, playlists, metadata overrides, artist artwork overrides, playback bookmarks, and imported music.

## Requested refinement: smoother artwork paging

- Replaced the system page-style `TabView` with a dedicated three-page artwork carousel.
- The previous, current, and next covers are decoded once and retained while the gesture is active.
- The artwork follows the finger continuously.
- A partial swipe uses an interactive spring to return to center.
- A completed swipe centers the destination artwork before the player changes tracks.
- The state handoff after centering is performed without animation, preventing a second visual jump.
- The progress scrubber remains outside the artwork gesture area.

Gapless audio and artwork animation are separate systems. The new pager directly addresses the visual choppiness; the audio engine below addresses transitions when tracks end naturally.

## New phase: preloaded gapless local playback beta

- Added `GaplessAudioEngine`, built with `AVAudioEngine` and one `AVAudioPlayerNode`.
- The current and next eligible local tracks are scheduled on the same player node.
- When a track finishes naturally, the preloaded track is already in the render schedule rather than starting a new `AVAudioPlayer` instance.
- The next eligible track is scheduled immediately after each successful boundary, maintaining a rolling one-track preload.
- FLAC, MP3, ALAC/M4A, WAV, AIFF, and other formats supported by `AVAudioFile` use the new path.
- Files the engine cannot open automatically use the proven Alpha 3.0 `AVAudioPlayer` compatibility fallback.
- Repeat One schedules the same track again; Repeat All can preload the first queue item at the end.
- Queue edits, shuffle changes, repeat changes, and preload-setting changes rebuild the future schedule while preserving the current position.
- Lock-screen metadata changes at the actual playback boundary.
- The line visualizer now receives its level from an audio-engine mixer tap when the gapless backend is active.

## Playback settings and diagnostics

Settings → Playback now includes:

- **Gapless preload next track** toggle.
- A **Local preload budget** from 10 MB to 250 MB.
- Current playback-engine status.
- The title of the currently preloaded next track.

The budget is checked against the local file's stored size. A next track larger than the budget is not pre-scheduled and uses the compatibility transition when reached. The Now Playing metadata area also displays the current gapless/preload status.

## Suggested tests

1. Install Alpha 3.1 over Alpha 3.0 and verify the existing library and collections remain intact.
2. Slowly drag artwork both directions and confirm all covers follow the finger smoothly.
3. Release before the threshold and confirm the cover springs back without changing playback.
4. Complete a swipe and confirm the artwork centers before the title and audio change.
5. Play a continuous/mixed album in track order with **Gapless preload next track** enabled.
6. In Settings, confirm the next track title appears under **Preloaded next track**.
7. Let a track finish without touching the controls and listen for the transition into the next track.
8. Disable gapless preload and confirm normal playback still advances.
9. Set the preload budget below the size of the next file and confirm the status indicates no eligible preloaded track.
10. Test Repeat One, Repeat All, queue reordering, Play Next, seeking, pause/resume, lock-screen controls, and background playback.
11. Test at least one FLAC album and one MP3 album. If a format cannot use the new engine, confirm it still plays through the compatibility fallback.

## Compatibility baseline

Alpha 3.1 preserves the successful Alpha 2.1–3.0 fixes, including the current-SDK `MetadataReader.swift` corrections, asynchronous AV metadata loading, Swift 6-safe legacy `AVAudioPlayerDelegate` proxying, actor-safe database schema creation, safe Core Foundation ownership, Finder File Sharing, document-relative paths, and the resolved orientation and `withUnsafeBytes` warnings.

The locally applied Alpha 2.7 `SmartLibraryViews.swift` correction remains included. `Section` declarations use explicit `content`, `header`, and `footer` closures where required by the current SDK.

## Mac preflight build

Run `Tools/PreflightBuild.sh` from Terminal on the Mac before signing. It performs a clean unsigned simulator build using complete Swift concurrency checking, helping catch current-SDK SwiftUI, type-checking, and isolation problems before device installation.
