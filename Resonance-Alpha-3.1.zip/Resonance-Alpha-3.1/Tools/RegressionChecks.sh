#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

find Resonance -name '*.swift' -print0 | xargs -0 -n1 swiftc -frontend -parse
plutil -lint Resonance/Info.plist
plutil -lint Resonance.xcodeproj/project.pbxproj

python3 - <<'PY'
from pathlib import Path
root = Path('.')
pbx = (root / 'Resonance.xcodeproj/project.pbxproj').read_text()
metadata = (root / 'Resonance/Services/MetadataReader.swift').read_text()
smart = (root / 'Resonance/Views/SmartLibraryViews.swift').read_text()

assert 'GaplessAudioEngine.swift in Sources' in pbx
assert pbx.count('CURRENT_PROJECT_VERSION = 31;') == 2
assert pbx.count('MARKETING_VERSION = 0.3.1;') == 2
assert '?? await' not in metadata
assert '?? try await' not in metadata
assert 'content:' in smart and 'header:' in smart
print('Resonance Alpha 3.1 regression checks passed.')
PY
