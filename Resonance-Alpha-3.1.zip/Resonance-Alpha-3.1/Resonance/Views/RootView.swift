import SwiftUI

enum AppTab: Hashable {
    case playing, library, streaming, settings
}

struct RootView: View {
    @EnvironmentObject private var player: PlayerController
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var settings: AppSettings
    @State private var selectedTab: AppTab = .library

    var body: some View {
        ZStack(alignment: .bottom) {
            TabView(selection: $selectedTab) {
                NavigationStack {
                    NowPlayingView(openLibrary: { selectedTab = .library })
                }
                .tabItem { Label("Playing", systemImage: "music.note") }
                .tag(AppTab.playing)

                NavigationStack { LibraryView() }
                    .tabItem { Label("Library", systemImage: "square.stack") }
                    .tag(AppTab.library)

                NavigationStack { StreamingLibraryView(openLibrary: { selectedTab = .library }) }
                    .tabItem { Label("Streaming", systemImage: "network") }
                    .tag(AppTab.streaming)

                NavigationStack { SettingsView(openLibrary: { selectedTab = .library }) }
                    .tabItem { Label("Settings", systemImage: "gearshape") }
                    .tag(AppTab.settings)
            }

            if player.currentTrack != nil && selectedTab != .playing {
                MiniPlayerView(openNowPlaying: { selectedTab = .playing })
                    .padding(.horizontal, 8)
                    .padding(.bottom, 58)
                    .zIndex(10)
            }
        }
        .foregroundStyle(settings.applyThemeColorToText ? settings.accentColor : Color.primary)
        .tint(settings.accentColor)
        .onAppear {
            player.onTrackStarted = { track in
                library.markPlayed(track)
            }
        }
        .onChange(of: settings.preloadNextTrack) { _, _ in
            player.refreshPlaybackConfiguration()
        }
        .onChange(of: settings.localBufferMB) { _, _ in
            player.refreshPlaybackConfiguration()
        }
    }
}

struct StreamingLibraryView: View {
    @EnvironmentObject private var settings: AppSettings
    let openLibrary: () -> Void

    var body: some View {
        List {
            Section("Private music server") {
                if settings.streamHost.isEmpty {
                    ContentUnavailableView(
                        "No Streaming Library",
                        systemImage: "externaldrive.badge.wifi",
                        description: Text("Enter your Tailscale-reachable server address in Settings, then connect to browse your remote music library.")
                    )
                } else {
                    LabeledContent("Server", value: settings.streamHost)
                    LabeledContent("Port", value: settings.streamPort.isEmpty ? "Server default" : settings.streamPort)
                    LabeledContent("Buffer", value: "\(Int(settings.networkBufferMB)) MB")
                    Button { } label: {
                        Label("Test Connection", systemImage: "network")
                            .foregroundStyle(settings.contrastingAccentTextColor)
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(settings.accentColor)
                }
            }

            Section("Stage status") {
                Label("Server browser UI ready", systemImage: "checkmark.circle.fill")
                Label("Authentication and streaming engine planned", systemImage: "hammer")
            }
        }
        .navigationTitle("Streaming Library")
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button(action: openLibrary) { Label("Library", systemImage: "chevron.left") }
            }
        }
        .contentShape(Rectangle())
        .gesture(
            DragGesture(minimumDistance: 45)
                .onEnded { value in
                    if value.startLocation.x < 36 && value.translation.width > 70 { openLibrary() }
                }
        )
    }
}
