@preconcurrency import AVFoundation
import Foundation

/// Lower-level local-file playback backend that can schedule the next track on
/// the same player node before the current track finishes. Scheduling both
/// files on one node avoids tearing down the audio output between album tracks.
final class GaplessAudioEngine: @unchecked Sendable {
  struct PreparedDurations {
    let current: TimeInterval
    let following: TimeInterval?
  }

  enum EngineError: LocalizedError {
    case missingFile(URL)
    case emptyAudioFile(URL)

    var errorDescription: String? {
      switch self {
      case .missingFile(let url): return "Audio file is missing: \(url.lastPathComponent)"
      case .emptyAudioFile(let url): return "Audio file contains no playable frames: \(url.lastPathComponent)"
      }
    }
  }

  typealias CompletionHandler = @Sendable (_ trackID: UUID, _ generation: Int) -> Void

  private let engine = AVAudioEngine()
  private let playerNode = AVAudioPlayerNode()
  private let meterState = AudioMeterState()
  private let retainedFiles = RetainedAudioFiles()
  private var completionHandler: CompletionHandler?
  private(set) var isPrepared = false

  var volume: Float {
    get { playerNode.volume }
    set { playerNode.volume = min(max(newValue, 0), 1) }
  }

  var isPlaying: Bool { playerNode.isPlaying }
  var meterLevel: Double { meterState.value }

  init(completionHandler: CompletionHandler? = nil) {
    self.completionHandler = completionHandler
    engine.attach(playerNode)
    engine.connect(playerNode, to: engine.mainMixerNode, format: nil)
    installMeterTap()
  }

  func setCompletionHandler(_ handler: CompletionHandler?) {
    completionHandler = handler
  }

  @discardableResult
  func prepare(
    currentTrackID: UUID,
    currentURL: URL,
    startTime: TimeInterval,
    followingTrackID: UUID?,
    followingURL: URL?,
    generation: Int
  ) throws -> PreparedDurations {
    stop(resetEngine: true)
    try startEngineIfNeeded()

    let currentFile = try openFile(at: currentURL)
    let currentDuration = Self.duration(of: currentFile)
    let safeStart = min(max(0, startTime), max(0, currentDuration - 0.05))
    let startFrame = AVAudioFramePosition(safeStart * currentFile.processingFormat.sampleRate)
    let remainingFrames = max(1, currentFile.length - startFrame)
    let currentToken = retainedFiles.retain(currentFile)

    playerNode.scheduleSegment(
      currentFile,
      startingFrame: startFrame,
      frameCount: AVAudioFrameCount(min(remainingFrames, AVAudioFramePosition(UInt32.max))),
      at: nil,
      completionCallbackType: .dataPlayedBack
    ) { [weak self] _ in
      self?.retainedFiles.release(currentToken)
      self?.completionHandler?(currentTrackID, generation)
    }

    var followingDuration: TimeInterval?
    if let followingTrackID, let followingURL {
      followingDuration = try? append(
        trackID: followingTrackID,
        url: followingURL,
        generation: generation
      )
    }

    playerNode.play()
    isPrepared = true
    return PreparedDurations(current: currentDuration, following: followingDuration)
  }

  /// Appends another complete file to the player-node schedule. This is called
  /// as soon as a preloaded boundary is crossed, keeping one future track ready.
  @discardableResult
  func append(trackID: UUID, url: URL, generation: Int) throws -> TimeInterval {
    let file = try openFile(at: url)
    let token = retainedFiles.retain(file)
    playerNode.scheduleFile(
      file,
      at: nil,
      completionCallbackType: .dataPlayedBack
    ) { [weak self] _ in
      self?.retainedFiles.release(token)
      self?.completionHandler?(trackID, generation)
    }
    return Self.duration(of: file)
  }

  func play() throws {
    guard isPrepared else { return }
    try startEngineIfNeeded()
    playerNode.play()
  }

  func pause() {
    playerNode.pause()
  }

  func stop(resetEngine: Bool = false) {
    playerNode.stop()
    retainedFiles.removeAll()
    isPrepared = false
    meterState.value = 0
    if resetEngine {
      engine.reset()
    }
  }

  private func startEngineIfNeeded() throws {
    if !engine.isRunning {
      engine.prepare()
      try engine.start()
    }
  }

  private func openFile(at url: URL) throws -> AVAudioFile {
    guard FileManager.default.fileExists(atPath: url.path) else {
      throw EngineError.missingFile(url)
    }
    let file = try AVAudioFile(forReading: url)
    guard file.length > 0 else { throw EngineError.emptyAudioFile(url) }
    return file
  }

  private static func duration(of file: AVAudioFile) -> TimeInterval {
    let rate = file.processingFormat.sampleRate
    guard rate > 0 else { return 0 }
    return Double(file.length) / rate
  }

  private func installMeterTap() {
    let mixer = engine.mainMixerNode
    mixer.installTap(onBus: 0, bufferSize: 1024, format: nil) { [meterState] buffer, _ in
      guard let channels = buffer.floatChannelData, buffer.frameLength > 0 else {
        meterState.value = 0
        return
      }

      let frameCount = Int(buffer.frameLength)
      let channelCount = max(1, Int(buffer.format.channelCount))
      let bufferCount = buffer.format.isInterleaved ? 1 : channelCount
      let samplesPerBuffer = buffer.format.isInterleaved ? frameCount * channelCount : frameCount
      var sumSquares: Float = 0
      for channel in 0..<bufferCount {
        let samples = channels[channel]
        for frame in 0..<samplesPerBuffer {
          let sample = samples[frame]
          sumSquares += sample * sample
        }
      }
      let divisor = Float(max(1, samplesPerBuffer * bufferCount))
      let rms = sqrt(max(0, sumSquares / max(1, divisor)))
      meterState.value = min(1, max(0.04, Double(rms) * 4.5))
    }
  }
}

private final class AudioMeterState: @unchecked Sendable {
  private let lock = NSLock()
  private var storedValue = 0.0

  var value: Double {
    get {
      lock.lock()
      defer { lock.unlock() }
      return storedValue
    }
    set {
      lock.lock()
      storedValue = newValue
      lock.unlock()
    }
  }
}

private final class RetainedAudioFiles: @unchecked Sendable {
  private let lock = NSLock()
  private var files: [UUID: AVAudioFile] = [:]

  func retain(_ file: AVAudioFile) -> UUID {
    let token = UUID()
    lock.lock()
    files[token] = file
    lock.unlock()
    return token
  }

  func release(_ token: UUID) {
    lock.lock()
    files[token] = nil
    lock.unlock()
  }

  func removeAll() {
    lock.lock()
    files.removeAll(keepingCapacity: true)
    lock.unlock()
  }
}
