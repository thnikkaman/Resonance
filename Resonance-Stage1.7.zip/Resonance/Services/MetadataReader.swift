import AVFoundation
import AudioToolbox
import Foundation

struct MetadataReader {
    static let supportedExtensions: Set<String> = ["flac", "mp3", "m4a", "aac", "wav", "aif", "aiff", "caf", "alac"]

    func track(from url: URL) async -> Track? {
        guard Self.supportedExtensions.contains(url.pathExtension.lowercased()) else { return nil }

        let asset = AVURLAsset(url: url)
        let duration = (try? await asset.load(.duration).seconds) ?? 0
        let metadata = await loadAllMetadata(from: asset)
        let audioInfo = audioFileInfo(for: url)

        var title = firstString(keys: ["title", "tit2"], metadata: metadata, dictionary: audioInfo)
            ?? url.deletingPathExtension().lastPathComponent
        var artist = firstString(keys: ["artist", "albumartist", "tpe1"], metadata: metadata, dictionary: audioInfo)
            ?? "Unknown Artist"
        let albumArtist = firstString(keys: ["albumartist", "album artist", "tpe2"], metadata: metadata, dictionary: audioInfo)
            ?? artist
        var album = firstString(keys: ["album", "albumname", "talb"], metadata: metadata, dictionary: audioInfo)
            ?? "Unknown Album"
        let trackNumber = firstInteger(keys: ["tracknumber", "track number", "trck"], metadata: metadata, dictionary: audioInfo)
            ?? inferredNumber(from: url)
        let discNumber = firstInteger(keys: ["discnumber", "disc number", "tpos"], metadata: metadata, dictionary: audioInfo)
            ?? 1
        let artwork = await embeddedArtwork(metadata: metadata, dictionary: audioInfo)

        if title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            title = url.deletingPathExtension().lastPathComponent
        }
        if artist.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { artist = "Unknown Artist" }
        if album.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { album = "Unknown Album" }

        return Track(
            title: title,
            artist: artist,
            albumArtist: albumArtist,
            album: album,
            trackNumber: trackNumber,
            discNumber: discNumber,
            duration: duration,
            fileURL: url,
            artworkData: artwork,
            artworkIsEmbedded: artwork != nil
        )
    }

    private func loadAllMetadata(from asset: AVURLAsset) async -> [AVMetadataItem] {
        var result = (try? await asset.load(.commonMetadata)) ?? []
        let formats = (try? await asset.load(.availableMetadataFormats)) ?? []
        for format in formats {
            let items = (try? await asset.loadMetadata(for: format)) ?? []
            result.append(contentsOf: items)
        }
        return result
    }

    private func firstString(keys: [String], metadata: [AVMetadataItem], dictionary: [String: Any]) -> String? {
        let normalizedKeys = Set(keys.map(normalize))

        for item in metadata {
            let candidates = [item.commonKey?.rawValue, item.identifier?.rawValue, String(describing: item.key)]
                .compactMap { $0 }
                .map(normalize)
            guard candidates.contains(where: { candidate in normalizedKeys.contains(where: candidate.contains) }) else { continue }
            if let value = item.stringValue?.trimmingCharacters(in: .whitespacesAndNewlines), !value.isEmpty { return value }
            if let value = item.numberValue?.stringValue { return value }
        }

        for (key, value) in dictionary where normalizedKeys.contains(where: normalize(key).contains) {
            if let string = value as? String, !string.isEmpty { return string }
            if let number = value as? NSNumber { return number.stringValue }
        }
        return nil
    }

    private func firstInteger(keys: [String], metadata: [AVMetadataItem], dictionary: [String: Any]) -> Int? {
        guard let value = firstString(keys: keys, metadata: metadata, dictionary: dictionary) else { return nil }
        return Int(value.split(separator: "/").first?.filter(\.isNumber) ?? "")
    }

    private func embeddedArtwork(metadata: [AVMetadataItem], dictionary: [String: Any]) async -> Data? {
        for item in metadata {
            let label = normalize([item.commonKey?.rawValue, item.identifier?.rawValue, String(describing: item.key)]
                .compactMap { $0 }.joined(separator: " "))
            guard label.contains("artwork") || label.contains("picture") || item.commonKey == .commonKeyArtwork else { continue }
            if let loaded = try? await item.load(.dataValue), let data = loaded, !data.isEmpty { return data }
        }

        for (key, value) in dictionary {
            let normalized = normalize(key)
            guard normalized.contains("artwork") || normalized.contains("picture") else { continue }
            if let data = value as? Data, !data.isEmpty { return data }
        }
        return nil
    }

    private func audioFileInfo(for url: URL) -> [String: Any] {
        var audioFile: AudioFileID?
        guard AudioFileOpenURL(url as CFURL, .readPermission, 0, &audioFile) == noErr, let audioFile else { return [:] }
        defer { AudioFileClose(audioFile) }

        var size: UInt32 = 0
        var writable: UInt32 = 0
        guard AudioFileGetPropertyInfo(audioFile, kAudioFilePropertyInfoDictionary, &size, &writable) == noErr else { return [:] }
        var dictionary: CFDictionary?
        guard AudioFileGetProperty(audioFile, kAudioFilePropertyInfoDictionary, &size, &dictionary) == noErr else { return [:] }
        return dictionary as? [String: Any] ?? [:]
    }

    private func inferredNumber(from url: URL) -> Int {
        Int(url.deletingPathExtension().lastPathComponent.prefix { $0.isNumber }) ?? 0
    }

    private func normalize(_ value: String) -> String {
        value.lowercased().filter { $0.isLetter || $0.isNumber }
    }
}
