# Resonance Stage 1.8

Open `Resonance.xcodeproj` in Xcode, choose your Apple development team, connect your iPhone, and run the app.

## Changes in this revision

- Reversed custom back-swipe navigation to a rightward swipe from the left screen edge.
- Edge-only navigation gestures no longer compete with sliders.
- Removed the on-screen hex bubbles and arrow controls.
- Restored editable RGB hex fields with normal iOS keyboard input and hexadecimal filtering.
- Shortened the RGB channel slider to 80% width.
- Added swipe/context-menu removal for artists.
- Added recursive folder import with subfolder preservation.
- Added direct native FLAC parsing for Vorbis comments and FLAC picture metadata blocks.
- Stored imported-file locations relative to the Documents directory so library records survive development app updates/container relocation.
- Added complementary foreground coloring for text placed on accent-colored prominent buttons.

## Testing note

iOS does not offer a built-in keyboard type containing only 0-9 and A-F. This build uses standard editable fields, automatically removes non-hex characters, and limits each channel to two characters.
