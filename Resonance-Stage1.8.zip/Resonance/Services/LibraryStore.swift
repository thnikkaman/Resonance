import Foundation
import UniformTypeIdentifiers

@MainActor
final class LibraryStore: ObservableObject {
    @Published private(set) var tracks: [Track] = []
    @Published var isScanning = false
    @Published var searchText = ""
    @Published var grouping: LibraryGrouping = .artists
    @Published var sortDirection: SortDirection = .ascending

    private let database = LibraryDatabase()
    private let reader = MetadataReader()

    var filteredTracks: [Track] {
        let base = searchText.isEmpty ? tracks : tracks.filter {
            [$0.title, $0.artist, $0.albumArtist, $0.album].contains { $0.localizedCaseInsensitiveContains(searchText) }
        }
        return base.sorted {
            let result = $0.title.localizedStandardCompare($1.title) == .orderedAscending
            return sortDirection == .ascending ? result : !result
        }
    }

    var artists: [Artist] { makeArtists(useAlbumArtist: false) }
    var albumArtists: [Artist] { makeArtists(useAlbumArtist: true) }
    var albums: [Album] { makeAlbums(from: filteredTracks) }

    func bootstrap() async {
        let stored = await database.loadAll()
        let localFiles = stored.compactMap(\.fileURL).filter { FileManager.default.fileExists(atPath: $0.path) }
        if !localFiles.isEmpty {
            isScanning = true
            var refreshed: [Track] = []
            for url in localFiles {
                if let track = await reader.track(from: url) { refreshed.append(track) }
            }
            isScanning = false
            tracks = refreshed
            await database.replaceAll(with: refreshed)
        } else {
            tracks = stored.isEmpty ? Self.demoTracks : stored
        }
    }

    func importURLs(_ urls: [URL]) async {
        isScanning = true
        defer { isScanning = false }
        let root = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Imported Music")
        try? FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        var imported: [Track] = []

        for selectedURL in urls {
            let accessed = selectedURL.startAccessingSecurityScopedResource()
            defer { if accessed { selectedURL.stopAccessingSecurityScopedResource() } }
            var isDirectory: ObjCBool = false
            FileManager.default.fileExists(atPath: selectedURL.path, isDirectory: &isDirectory)
            let sources = isDirectory.boolValue ? expandDirectory(selectedURL) : [selectedURL]
            let folderRoot = isDirectory.boolValue ? root.appendingPathComponent(selectedURL.lastPathComponent) : root

            for source in sources {
                guard MetadataReader.supportedExtensions.contains(source.pathExtension.lowercased()) else { continue }
                let relative = isDirectory.boolValue ? source.path.replacingOccurrences(of: selectedURL.path + "/", with: "") : source.lastPathComponent
                let target = folderRoot.appendingPathComponent(relative)
                do {
                    try FileManager.default.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
                    if !FileManager.default.fileExists(atPath: target.path) { try FileManager.default.copyItem(at: source, to: target) }
                    if let track = await reader.track(from: target) { imported.append(track) }
                } catch { continue }
            }
        }
        let existing = tracks.filter { $0.fileURL != nil && FileManager.default.fileExists(atPath: $0.fileURL!.path) }
        tracks = deduplicate(existing + imported)
        await database.replaceAll(with: tracks)
    }

    func removeArtist(_ artist: Artist) async {
        let ids = Set(artist.albums.flatMap(\.tracks).map(\.id))
        let removed = tracks.filter { ids.contains($0.id) }
        tracks.removeAll { ids.contains($0.id) }
        for track in removed { if let url = track.fileURL { try? FileManager.default.removeItem(at: url) } }
        await database.replaceAll(with: tracks)
    }

    func resetDemoLibrary() async {
        tracks = Self.demoTracks
        await database.replaceAll(with: [])
    }

    private func expandDirectory(_ url: URL) -> [URL] {
        let keys: [URLResourceKey] = [.isRegularFileKey]
        let enumerator = FileManager.default.enumerator(at: url, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles])
        return (enumerator?.allObjects as? [URL] ?? []).filter { MetadataReader.supportedExtensions.contains($0.pathExtension.lowercased()) }
    }

    private func deduplicate(_ input: [Track]) -> [Track] {
        Array(Dictionary(grouping: input, by: { $0.fileURL?.standardizedFileURL.absoluteString ?? $0.id.uuidString }).compactMap(\.value.last))
    }

    private func makeArtists(useAlbumArtist: Bool) -> [Artist] {
        let groups = Dictionary(grouping: filteredTracks) { useAlbumArtist ? $0.albumArtist : $0.artist }
        let mapped = groups.map { Artist(id: $0.key, name: $0.key, albums: makeAlbums(from: $0.value)) }
        return mapped.sorted { sortDirection == .ascending ? $0.name.localizedStandardCompare($1.name) == .orderedAscending : $0.name.localizedStandardCompare($1.name) == .orderedDescending }
    }

    private func makeAlbums(from tracks: [Track]) -> [Album] {
        Dictionary(grouping: tracks, by: { "\($0.albumArtist)|\($0.album)" }).map { key, values in
            let sorted = values.sorted { ($0.discNumber, $0.trackNumber, $0.title) < ($1.discNumber, $1.trackNumber, $1.title) }
            return Album(id: key, title: sorted.first?.album ?? "Unknown Album", artist: sorted.first?.albumArtist ?? "Unknown Artist", tracks: sorted)
        }.sorted { sortDirection == .ascending ? $0.title.localizedStandardCompare($1.title) == .orderedAscending : $0.title.localizedStandardCompare($1.title) == .orderedDescending }
    }

    static let demoTracks: [Track] = [
        Track(title: "Glass Horizon", artist: "Northstar", album: "Night Signals", trackNumber: 1, duration: 254),
        Track(title: "Between Stations", artist: "Northstar", album: "Night Signals", trackNumber: 2, duration: 221),
        Track(title: "Afterimage", artist: "Northstar", album: "Night Signals", trackNumber: 3, duration: 289),
        Track(title: "Slow Current", artist: "Northstar", album: "Tidal Memory", trackNumber: 1, duration: 312),
        Track(title: "Low Light", artist: "Violet Static", album: "Soft Machines", trackNumber: 1, duration: 198),
        Track(title: "Signal Bloom", artist: "Violet Static", album: "Soft Machines", trackNumber: 2, duration: 247),
        Track(title: "Open Circuit", artist: "Violet Static", album: "Soft Machines", trackNumber: 3, duration: 230)
    ]
}
