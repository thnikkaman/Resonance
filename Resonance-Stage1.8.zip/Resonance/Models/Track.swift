import Foundation
import SwiftUI

struct Track: Identifiable, Hashable, Codable, Sendable {
    let id: UUID
    var title: String
    var artist: String
    var albumArtist: String
    var album: String
    var trackNumber: Int
    var discNumber: Int
    var duration: Double
    var fileURL: URL?
    var artworkData: Data?
    var artworkIsEmbedded: Bool

    init(
        id: UUID = UUID(), title: String, artist: String, albumArtist: String = "",
        album: String, trackNumber: Int = 0, discNumber: Int = 1,
        duration: Double = 0, fileURL: URL? = nil, artworkData: Data? = nil,
        artworkIsEmbedded: Bool = false
    ) {
        self.id = id
        self.title = title
        self.artist = artist
        self.albumArtist = albumArtist.isEmpty ? artist : albumArtist
        self.album = album
        self.trackNumber = trackNumber
        self.discNumber = discNumber
        self.duration = duration
        self.fileURL = fileURL
        self.artworkData = artworkData
        self.artworkIsEmbedded = artworkIsEmbedded
    }
}

struct Album: Identifiable, Hashable {
    let id: String
    let title: String
    let artist: String
    let tracks: [Track]

    var artworkData: Data? { tracks.compactMap(\.artworkData).first }
    var yearLabel: String { "" }
}

struct Artist: Identifiable, Hashable {
    let id: String
    let name: String
    let albums: [Album]
}

enum LibraryGrouping: String, CaseIterable, Identifiable {
    case artists = "Artists"
    case albumArtists = "Album Artists"
    case albums = "Albums"
    case songs = "Songs"
    var id: String { rawValue }
}

enum SortDirection: String, CaseIterable, Identifiable {
    case ascending = "Ascending"
    case descending = "Descending"
    var id: String { rawValue }
}

enum AlbumLayout: String, CaseIterable, Identifiable {
    case grid = "Grid"
    case compact = "Compact"
    case large = "Large"
    var id: String { rawValue }
}


enum LibraryThumbnailSize: String, CaseIterable, Identifiable {
    case small = "Small"
    case medium = "Medium"
    case large = "Large"
    var id: String { rawValue }

    var points: CGFloat {
        switch self {
        case .small: 24
        case .medium: 32
        case .large: 42
        }
    }
}

enum LibraryTextSize: String, CaseIterable, Identifiable {
    case compact = "Compact"
    case standard = "Standard"
    case large = "Large"
    var id: String { rawValue }

    var font: Font {
        switch self {
        case .compact: .caption
        case .standard: .subheadline
        case .large: .body
        }
    }
}
