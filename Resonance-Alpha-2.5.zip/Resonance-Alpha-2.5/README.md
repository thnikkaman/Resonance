# Resonance Alpha 2.5

A SwiftUI iPhone music-player prototype with Finder/Files transfer, recursive folder indexing, SQLite storage, FLAC/Vorbis metadata parsing, embedded artwork, playback queues, favorites, smart collections, and persistent playlists.

## Install without erasing the library

Install Alpha 2.5 directly over Alpha 2.4 using the same bundle identifier and signing configuration. Do not delete the installed app first. Deleting it removes the app’s Documents folder, SQLite database, favorites, recent-play history, playlists, and imported music.

## New and fixed in Alpha 2.5

### Library toolbar

- The Playlists shortcut has moved out of the library content area.
- It now appears in the top Library toolbar directly to the right of Library Options.
- The Playlists control uses the selected theme color and complementary text so it is visually distinct.

### Now Playing information

- Elapsed track position and remaining time now sit clearly below the progress bar.
- Total track length now appears directly below the existing title, artist, and album text.
- The existing scrub-preview bubble and 80%-travel seeking behavior remain unchanged.

### Hex color scale

- The selected RGB channel slider now has hexadecimal tick labels from 0 through F.
- Sixteen evenly spaced marks show the high-nibble range across the 00–FF slider.
- The slider remains centered at 80% width.

## Suggested Alpha 2.5 tests

1. Install directly over Alpha 2.4 and confirm the music library and playlists remain intact.
2. Verify Playlists appears beside Library Options in the top Library toolbar and opens the playlist manager.
3. Test the Playlists button with both bright and dark theme colors.
4. Play a track and confirm total length appears below the title/artist/album block.
5. Confirm elapsed and remaining times are below—not on—the progress bar.
6. Scrub while playing and verify the preview bubble and seek behavior still work.
7. In Settings, select each RGB channel and verify the 0–F tick scale aligns above the 00–FF slider.

## Compatibility baseline

Alpha 2.5 preserves the successful Alpha 2.1–2.4 compatibility fixes, including the current-SDK MetadataReader changes, asynchronous AV metadata loading, Swift 6-safe AVAudioPlayerDelegate proxying, actor-safe database schema creation, safe Core Foundation ownership, Finder File Sharing, document-relative paths, and the resolved orientation and `withUnsafeBytes` warnings.
