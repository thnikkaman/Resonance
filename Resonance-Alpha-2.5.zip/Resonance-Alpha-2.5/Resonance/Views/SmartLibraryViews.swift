import SwiftUI

struct SmartTrackCollectionView: View {
    let title: String
    let tracks: [Track]
    let systemImage: String
    let emptyDescription: String

    var body: some View {
        if tracks.isEmpty {
            ContentUnavailableView(
                title,
                systemImage: systemImage,
                description: Text(emptyDescription)
            )
        } else {
            VStack(spacing: 0) {
                HStack {
                    Label(title, systemImage: systemImage)
                        .font(.headline)
                    Spacer()
                    Text("\(tracks.count) track\(tracks.count == 1 ? "" : "s")")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(.horizontal)
                .padding(.vertical, 10)
                .background(.bar)

                TrackCollectionView(tracks: tracks)
            }
        }
    }
}

struct PlaylistCollectionView: View {
    @EnvironmentObject private var library: LibraryStore
    @State private var showingNewPlaylist = false
    @State private var newPlaylistName = ""
    @State private var playlistToDelete: UserPlaylist?
    @State private var searchText = ""

    private var visiblePlaylists: [UserPlaylist] {
        guard !searchText.isEmpty else { return library.playlists }
        return library.playlists.filter { playlist in
            if playlist.name.localizedCaseInsensitiveContains(searchText) { return true }
            return library.tracks(in: playlist.id).contains { track in
                [track.title, track.artist, track.albumArtist, track.album]
                    .contains { $0.localizedCaseInsensitiveContains(searchText) }
            }
        }
    }

    var body: some View {
        List {
            Section {
                Button {
                    newPlaylistName = ""
                    showingNewPlaylist = true
                } label: {
                    Label("Add a Playlist", systemImage: "plus.circle.fill")
                        .font(.headline)
                }
            }

            Section("Your Playlists") {
                if visiblePlaylists.isEmpty {
                    ContentUnavailableView(
                        "No Playlists",
                        systemImage: "music.note.list",
                        description: Text("Tap Add a Playlist, then add tracks from a song, album, or Now Playing.")
                    )
                    .listRowBackground(Color.clear)
                } else {
                    ForEach(visiblePlaylists) { playlist in
                        NavigationLink {
                            PlaylistDetailView(playlistID: playlist.id)
                        } label: {
                            PlaylistRow(playlist: playlist)
                        }
                        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                            Button(role: .destructive) {
                                playlistToDelete = playlist
                            } label: {
                                Label("Delete", systemImage: "trash")
                            }
                        }
                        .contextMenu {
                            Button(role: .destructive) {
                                playlistToDelete = playlist
                            } label: {
                                Label("Delete Playlist", systemImage: "trash")
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle("Playlists")
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $searchText, prompt: "Search playlists")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    newPlaylistName = ""
                    showingNewPlaylist = true
                } label: {
                    Label("Add a Playlist", systemImage: "plus")
                }
            }
        }
        .alert("New Playlist", isPresented: $showingNewPlaylist) {
            TextField("Playlist name", text: $newPlaylistName)
            Button("Cancel", role: .cancel) { }
            Button("Create") {
                _ = library.createPlaylist(named: newPlaylistName)
            }
            .disabled(newPlaylistName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        } message: {
            Text("Enter a name for the new playlist.")
        }
        .confirmationDialog(
            "Delete Playlist?",
            isPresented: Binding(
                get: { playlistToDelete != nil },
                set: { if !$0 { playlistToDelete = nil } }
            ),
            titleVisibility: .visible
        ) {
            Button("Delete Playlist", role: .destructive) {
                if let playlistToDelete {
                    library.deletePlaylist(playlistToDelete.id)
                }
                playlistToDelete = nil
            }
            Button("Cancel", role: .cancel) { playlistToDelete = nil }
        } message: {
            Text("This removes the playlist but does not delete any music files.")
        }
    }
}

private struct PlaylistRow: View {
    @EnvironmentObject private var library: LibraryStore
    let playlist: UserPlaylist

    private var tracks: [Track] { library.tracks(in: playlist.id) }

    var body: some View {
        HStack(spacing: 12) {
            PlaylistArtworkView(tracks: tracks, size: 54)

            VStack(alignment: .leading, spacing: 3) {
                Text(playlist.name)
                    .font(.headline)
                    .lineLimit(1)
                Text("\(tracks.count) track\(tracks.count == 1 ? "" : "s")")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }
}

struct PlaylistArtworkView: View {
    @EnvironmentObject private var library: LibraryStore
    let tracks: [Track]
    let size: CGFloat

    private var artworkTrack: Track? {
        tracks.first { library.artworkData(for: $0) != nil }
    }

    var body: some View {
        if let artworkTrack {
            ArtworkView(
                data: library.artworkData(for: artworkTrack),
                embedded: library.artworkIsEmbedded(for: artworkTrack),
                size: size
            )
        } else {
            PlaceholderArtwork(symbol: "music.note.list", size: size)
        }
    }
}

struct PlaylistDetailView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var player: PlayerController
    @EnvironmentObject private var settings: AppSettings
    @State private var showingRename = false
    @State private var showingDeleteConfirmation = false
    @State private var renameText = ""
    let playlistID: UUID

    private var playlist: UserPlaylist? { library.playlist(id: playlistID) }
    private var tracks: [Track] { library.tracks(in: playlistID) }

    var body: some View {
        Group {
            if let playlist {
                List {
                    Section {
                        VStack(spacing: 10) {
                            PlaylistArtworkView(tracks: tracks, size: 116)
                            Text(playlist.name)
                                .font(.title2.bold())
                            Text("\(tracks.count) track\(tracks.count == 1 ? "" : "s")")
                                .font(.caption)
                                .foregroundStyle(.secondary)

                            Button {
                                if let first = tracks.first {
                                    player.play(first, in: tracks)
                                }
                            } label: {
                                Label("Play Playlist", systemImage: "play.fill")
                                    .foregroundStyle(settings.contrastingAccentTextColor)
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(settings.accentColor)
                            .disabled(tracks.isEmpty)
                        }
                        .frame(maxWidth: .infinity)
                        .listRowBackground(Color.clear)
                    }

                    Section("Tracks") {
                        if tracks.isEmpty {
                            ContentUnavailableView(
                                "Playlist Is Empty",
                                systemImage: "music.note.list",
                                description: Text("Add tracks using the menu on a song, album, or Now Playing.")
                            )
                            .listRowBackground(Color.clear)
                        } else {
                            ForEach(tracks) { track in
                                Button {
                                    player.play(track, in: tracks)
                                } label: {
                                    TrackListRow(
                                        track: track,
                                        showsArtwork: true,
                                        large: false,
                                        showsAlbum: true
                                    )
                                }
                                .buttonStyle(.plain)
                                .trackLibraryActions(track)
                                .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                    Button(role: .destructive) {
                                        library.remove(track, from: playlistID)
                                    } label: {
                                        Label("Remove", systemImage: "minus.circle")
                                    }
                                }
                            }
                            .onMove { offsets, destination in
                                library.moveTracks(in: playlistID, from: offsets, to: destination)
                            }
                        }
                    }
                }
                .navigationTitle(playlist.name)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        EditButton()
                    }
                    ToolbarItem(placement: .topBarTrailing) {
                        Menu {
                            Button {
                                renameText = playlist.name
                                showingRename = true
                            } label: {
                                Label("Rename Playlist", systemImage: "pencil")
                            }
                            Button(role: .destructive) {
                                showingDeleteConfirmation = true
                            } label: {
                                Label("Delete Playlist", systemImage: "trash")
                            }
                        } label: {
                            Label("Playlist Actions", systemImage: "ellipsis.circle")
                        }
                    }
                }
            } else {
                ContentUnavailableView("Playlist Not Found", systemImage: "exclamationmark.triangle")
            }
        }
        .alert("Rename Playlist", isPresented: $showingRename) {
            TextField("Playlist name", text: $renameText)
            Button("Cancel", role: .cancel) { }
            Button("Save") {
                library.renamePlaylist(playlistID, to: renameText)
            }
            .disabled(renameText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
        .confirmationDialog(
            "Delete Playlist?",
            isPresented: $showingDeleteConfirmation,
            titleVisibility: .visible
        ) {
            Button("Delete Playlist", role: .destructive) {
                library.deletePlaylist(playlistID)
                dismiss()
            }
            Button("Cancel", role: .cancel) { }
        } message: {
            Text("This removes the playlist but does not delete any music files.")
        }
    }
}

struct PlaylistPickerSheet: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var library: LibraryStore
    let tracks: [Track]

    private var itemDescription: String {
        tracks.count == 1 ? tracks[0].title : "\(tracks.count) tracks"
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    NavigationLink {
                        PlaylistCollectionView()
                    } label: {
                        Label("Add a Playlist", systemImage: "plus.circle.fill")
                    }
                }

                Section("Choose a Playlist") {
                    if library.playlists.isEmpty {
                        ContentUnavailableView(
                            "No Playlists Yet",
                            systemImage: "music.note.list",
                            description: Text("Tap Add a Playlist above, create one, then return here.")
                        )
                        .listRowBackground(Color.clear)
                    } else {
                        ForEach(library.playlists) { playlist in
                            Button {
                                _ = library.add(tracks, to: playlist.id)
                                dismiss()
                            } label: {
                                HStack(spacing: 12) {
                                    PlaylistArtworkView(tracks: library.tracks(in: playlist.id), size: 42)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(playlist.name)
                                        Text("Add \(itemDescription)")
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    Image(systemName: "plus.circle")
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            }
            .navigationTitle("Add to Playlist")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
        }
    }
}

private struct TrackLibraryActionsModifier: ViewModifier {
    @EnvironmentObject private var library: LibraryStore
    @State private var showingPlaylistPicker = false
    let track: Track

    func body(content: Content) -> some View {
        content
            .contextMenu {
                Button {
                    library.toggleFavorite(track)
                } label: {
                    Label(
                        library.isFavorite(track) ? "Remove from Favorites" : "Add to Favorites",
                        systemImage: library.isFavorite(track) ? "heart.slash" : "heart"
                    )
                }
                Button {
                    showingPlaylistPicker = true
                } label: {
                    Label(
                        library.playlists.isEmpty ? "Add a Playlist" : "Add to Playlist",
                        systemImage: "text.badge.plus"
                    )
                }
            }
            .sheet(isPresented: $showingPlaylistPicker) {
                PlaylistPickerSheet(tracks: [track])
                    .presentationDetents([.medium, .large])
            }
    }
}

extension View {
    func trackLibraryActions(_ track: Track) -> some View {
        modifier(TrackLibraryActionsModifier(track: track))
    }
}
