# Resonance Alpha 3.6

Version 0.3.6, build 36.

Install this build directly over Alpha 3.5 with the same bundle identifier and signing team. Do not delete the installed app first; uninstalling removes the local database, imported files, metadata overrides, favorites, and local playlists.

## Requested corrections

### Prominent streaming buttons

The following theme-colored buttons now use the complementary theme color for their text and icons:

- Play Artist
- Play Album
- Play All Albums
- Play Playlist

### Duplicate remote artists and tracks

The Navidrome index now removes duplicate files by stable Subsonic song ID before building the library. Artist and album groups use normalized, case-insensitive, diacritic-insensitive keys with collapsed whitespace. Display spelling is chosen from the most common server value.

The Streaming Library now has separate **Artists** and **Album Artists** groupings so performing-artist tags are not confused with album-artist tags.

### Adaptive alphabetical index

Artists and Album Artists in both the local Library and Streaming Library now have a vertical index on the right side.

- Tap a character to jump to it.
- Drag a finger vertically to move through the available characters.
- Letters with no matching artist are omitted.
- `0–9` appears only when a name begins with a number.
- `#` appears only when a name begins with another symbol.
- Ascending and descending library sort orders reverse both the list and the index.

## Streaming browse parity

The Streaming Library now mirrors the local Library options interface:

- Artists
- Album Artists
- Albums
- Songs
- Favorites
- Recently Added
- Recently Played
- Ascending or descending sorting
- Album artwork grid
- Compact list
- Large list
- Small, medium, or large artwork
- Compact, standard, or large text
- Artist album sorting by title or release year
- Artist album grid/list switching
- All Albums view sorted by album, disc, track number, and title

Navidrome Favorites use the server's `star` and `unstar` endpoints. Remote playback is submitted to Navidrome through `scrobble`, and the local Recently Played view updates immediately.

## Navidrome playlist management

A theme-colored **Playlists** control now appears beside **Library Options** at the top of the Streaming Library.

For Navidrome/Subsonic servers you can:

- Browse server playlists
- Create a playlist
- Rename a playlist
- Delete a playlist with confirmation
- Play a playlist
- Add one track to a playlist
- Add an entire album to a playlist
- Remove tracks
- Reorder tracks in Edit mode
- Search playlists
- Pull to refresh playlists

The Resonance Manifest backend remains browse/play only because it does not expose a playlist-write API.

## Remote transition phase

Remote playback now uses `AVQueuePlayer` with two authenticated items instead of creating a new `AVPlayer` only after the current stream finishes.

- The next remote item is created and inserted before the current item ends.
- The upcoming item receives the configured forward-buffer target.
- Natural transitions update the Now Playing metadata without recreating the player.
- Queue edits, Play Next, shuffle, repeat, and buffer-setting changes rebuild the remote prequeue.
- Settings/Now Playing report **Remote gapless ready** when an upcoming item is prequeued.

This is a network gapless beta. It removes Resonance's previous player-recreation delay, but a server, codec, or file boundary can still introduce a short gap. Local files continue to use the sample-scheduled AVAudioEngine path.

## Recommended tests

1. Refresh the Navidrome library and confirm the duplicate artists/files are gone.
2. Compare Artists and Album Artists to verify tag differences are separated intentionally.
3. Tap and drag the right-side index in local and streaming artist views.
4. Test grid, compact, and large layouts in Streaming Library Options.
5. Test streaming Favorites and Recently Played.
6. Create, rename, reorder, add to, remove from, play, and delete a Navidrome playlist.
7. Play a continuous remote album and confirm the next title is reported as prequeued before the current track ends.
8. Test Repeat One, Repeat All, Play Next, queue reordering, and background/Lock Screen transitions.
9. Play a local 5.1 FLAC afterward and verify the Alpha 3.3 explicit downmix remains unchanged.

## Build checks

`Tools/RegressionChecks.sh` validates Swift 6 parsing, property lists, Xcode project structure, prior MetadataReader and SmartLibraryViews fixes, the explicit 5.1 matrix, Navidrome endpoints, playlist/favorite/scrobble hooks, artist-index hooks, version numbers, and remote prequeue hooks.

`Tools/PreflightBuild.sh` performs a clean unsigned iPhone Simulator build on a Mac with strict concurrency enabled.
