# Resonance Alpha 2.6

A SwiftUI iPhone music-player prototype with Finder/Files transfer, recursive folder indexing, SQLite storage, FLAC/Vorbis metadata parsing, embedded artwork, playback queues, favorites, smart collections, playlists, and persistent Resonance metadata edits.

## Install without erasing the library

Install Alpha 2.6 directly over Alpha 2.5 using the same bundle identifier and signing configuration. Do not delete the installed app first. Deleting it removes the app's Documents folder, SQLite database, favorites, recent-play history, playlists, metadata overrides, and imported music.

## New and fixed in Alpha 2.6

### Correct hexadecimal scale alignment

- The sixteen hexadecimal labels remain evenly spaced.
- Each mark represents the high-nibble values `00`, `10`, `20` … `F0`.
- The final `F` is positioned directly over the slider location for `F0`, rather than over the `FF` endpoint.

### Track metadata editor

- Swipe a track row and choose **Edit Metadata**, or press and hold the track and select **Edit Track Metadata**.
- Edit title, performing artist, album artist, album, track number, disc number, and release year.
- Choose custom artwork from the Photos picker.
- Remove the Resonance artwork override without deleting the audio file.
- Reset a track to the tags and artwork stored in the original file.
- A small pencil badge identifies tracks with Resonance metadata overrides.

### Album-wide metadata editing

- Open an album and tap the pencil button in the upper-right toolbar.
- Change album title, album artist, release year, and artwork for every track in that album in one operation.
- Reset the entire album to its original file metadata.
- Track titles and individual performing artists are preserved during an album-wide edit.

### Safe persistence across scans

- Metadata overrides are stored separately from scanned file metadata.
- Launch, foreground, and manual scans reapply the user's edits after reading the source files.
- Finder transfers and unchanged track IDs continue to preserve playlists, favorites, and metadata edits.
- Custom artwork remains visibly non-embedded and follows the optional red-outline setting.

## Important metadata-writing scope

Alpha 2.6 edits the Resonance library database and does not rewrite MP3 ID3 frames or FLAC Vorbis-comment blocks inside the source audio files. This avoids file-corruption risk while the native tag-writing layer is still being developed.

## Suggested Alpha 2.6 tests

1. Install directly over Alpha 2.5 and verify the existing library and playlists remain.
2. Move the RGB slider to `F0` and confirm the `F` label is directly above the thumb, with even spacing between all labels.
3. Swipe a track, edit its title, artist, album, position, and year, then restart Resonance.
4. Run a manual shared-folder scan and confirm the edited values remain.
5. Select custom track artwork from Photos and verify the red non-embedded outline follows the Settings toggle.
6. Open an album, use the pencil button, and edit its album title, album artist, year, and artwork.
7. Confirm every track in the album moves into the newly named album without changing its track title.
8. Use **Reset to File Metadata** for a track and an album and confirm the original tags return.
9. Verify favorites and playlist membership survive metadata changes and rescans.

## Compatibility baseline

Alpha 2.6 preserves the successful Alpha 2.1–2.5 compatibility fixes, including the current-SDK MetadataReader changes, asynchronous AV metadata loading, Swift 6-safe AVAudioPlayerDelegate proxying, actor-safe database schema creation, safe Core Foundation ownership, Finder File Sharing, document-relative paths, and the resolved orientation and `withUnsafeBytes` warnings.
