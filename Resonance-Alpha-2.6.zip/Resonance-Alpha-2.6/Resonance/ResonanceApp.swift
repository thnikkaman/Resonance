import SwiftUI

@main
struct ResonanceApp: App {
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var library = LibraryStore()
    @StateObject private var player = PlayerController()
    @StateObject private var settings = AppSettings()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(library)
                .environmentObject(player)
                .environmentObject(settings)
                .tint(settings.accentColor)
                .preferredColorScheme(settings.colorScheme)
                .task(id: scenePhase) {
                    guard scenePhase == .active else { return }
                    await library.refreshForActiveState()
                }
        }
    }
}
