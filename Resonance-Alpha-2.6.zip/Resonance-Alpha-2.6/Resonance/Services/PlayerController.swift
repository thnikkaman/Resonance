import AVFoundation
import MediaPlayer
import UIKit

enum RepeatMode: String, CaseIterable, Identifiable {
    case off = "Off"
    case all = "Repeat All"
    case one = "Repeat One"

    var id: String { rawValue }
    var systemImage: String {
        switch self {
        case .off, .all: return "repeat"
        case .one: return "repeat.1"
        }
    }
}

enum SleepTimerOption: String, CaseIterable, Identifiable {
    case off = "Off"
    case fifteenMinutes = "15 Minutes"
    case thirtyMinutes = "30 Minutes"
    case fortyFiveMinutes = "45 Minutes"
    case sixtyMinutes = "60 Minutes"
    case endOfTrack = "End of Track"

    var id: String { rawValue }
    var interval: TimeInterval? {
        switch self {
        case .off, .endOfTrack: return nil
        case .fifteenMinutes: return 15 * 60
        case .thirtyMinutes: return 30 * 60
        case .fortyFiveMinutes: return 45 * 60
        case .sixtyMinutes: return 60 * 60
        }
    }
}

@MainActor
final class PlayerController: NSObject, ObservableObject {
    @Published private(set) var currentTrack: Track?
    @Published private(set) var isPlaying = false
    @Published private(set) var elapsed = 0.0
    @Published private(set) var duration = 0.0
    @Published private(set) var meterLevel = 0.0
    @Published private(set) var queue: [Track] = []
    @Published private(set) var currentQueueIndex = 0
    @Published var shuffleEnabled = false
    @Published var repeatMode: RepeatMode = .off
    @Published var volume = 1.0 {
        didSet { audioPlayer?.volume = Float(min(max(volume, 0), 1)) }
    }
    @Published private(set) var sleepTimerOption: SleepTimerOption = .off
    @Published private(set) var sleepTimerRemaining: TimeInterval = 0

    var onTrackStarted: (@MainActor (Track) -> Void)?

    private var sourceQueue: [Track] = []
    private var audioPlayer: AVAudioPlayer?
    private var playbackTimer: Timer?
    private var sleepTimer: Timer?
    private var lastNowPlayingProgressUpdate = 0.0
    private lazy var audioDelegate = AudioPlayerDelegateProxy(owner: self)

    override init() {
        super.init()
        configureSession()
        configureRemoteCommands()
    }

    var upcomingTracks: [Track] {
        guard !queue.isEmpty, currentQueueIndex + 1 < queue.count else { return [] }
        return Array(queue[(currentQueueIndex + 1)...])
    }

    var sleepTimerLabel: String {
        switch sleepTimerOption {
        case .off: return "Off"
        case .endOfTrack: return "End of Track"
        default:
            let remaining = max(0, Int(sleepTimerRemaining.rounded(.up)))
            return String(format: "%d:%02d", remaining / 60, remaining % 60)
        }
    }

    func artworkData(for track: Track) -> Data? {
        if let artwork = track.artworkData { return artwork }
        return artworkSource(for: track)?.artworkData
    }

    func artworkIsEmbedded(for track: Track) -> Bool {
        if track.artworkData != nil { return track.artworkIsEmbedded }
        return artworkSource(for: track)?.artworkIsEmbedded ?? true
    }

    func play(_ track: Track, in tracks: [Track]) {
        guard tracks.contains(track) else { return }
        sourceQueue = tracks

        if shuffleEnabled {
            let remaining = tracks.filter { $0.id != track.id }.shuffled()
            queue = [track] + remaining
            currentQueueIndex = 0
        } else {
            queue = tracks
            currentQueueIndex = tracks.firstIndex(of: track) ?? 0
        }

        _ = loadAndPlay(track)
    }

    func playQueueItem(_ track: Track) {
        guard let targetIndex = queue.firstIndex(of: track) else { return }
        if loadAndPlay(track) {
            currentQueueIndex = targetIndex
            updateNowPlaying()
        }
    }

    func play() {
        guard let audioPlayer, !audioPlayer.isPlaying else { return }
        audioPlayer.play()
        isPlaying = true
        startPlaybackTimer()
        updateNowPlaying()
    }

    func pause() {
        guard let audioPlayer, audioPlayer.isPlaying else { return }
        audioPlayer.pause()
        isPlaying = false
        updateNowPlaying()
    }

    func toggle() {
        isPlaying ? pause() : play()
    }

    func next() {
        guard !queue.isEmpty else { return }
        let targetIndex = currentQueueIndex + 1
        if queue.indices.contains(targetIndex) {
            if loadAndPlay(queue[targetIndex]) {
                currentQueueIndex = targetIndex
                updateNowPlaying()
            }
        } else if repeatMode == .all, let first = queue.first {
            if loadAndPlay(first) {
                currentQueueIndex = 0
                updateNowPlaying()
            }
        } else {
            stop()
        }
    }

    func previous() {
        if elapsed > 3 {
            seek(to: 0)
            return
        }
        guard !queue.isEmpty else { return }
        let targetIndex = currentQueueIndex - 1
        if queue.indices.contains(targetIndex) {
            if loadAndPlay(queue[targetIndex]) {
                currentQueueIndex = targetIndex
                updateNowPlaying()
            }
        } else if repeatMode == .all, let last = queue.last {
            if loadAndPlay(last) {
                currentQueueIndex = queue.count - 1
                updateNowPlaying()
            }
        } else {
            seek(to: 0)
        }
    }

    func skip(by interval: TimeInterval) {
        guard audioPlayer != nil else { return }
        seek(to: elapsed + interval)
    }

    func toggleShuffle() {
        shuffleEnabled.toggle()
        guard let currentTrack else { return }

        if shuffleEnabled {
            let alreadyPlayed = Array(queue.prefix(currentQueueIndex + 1))
            let upcoming = Array(queue.dropFirst(currentQueueIndex + 1)).shuffled()
            queue = alreadyPlayed + upcoming
        } else {
            let retainedIDs = Set(queue.map(\.id))
            let restoredQueue = sourceQueue.filter { retainedIDs.contains($0.id) }
            if let restoredIndex = restoredQueue.firstIndex(of: currentTrack) {
                queue = restoredQueue
                currentQueueIndex = restoredIndex
            }
        }
        updateNowPlaying()
    }

    func cycleRepeatMode() {
        switch repeatMode {
        case .off: repeatMode = .all
        case .all: repeatMode = .one
        case .one: repeatMode = .off
        }
    }

    func removeUpcoming(atOffsets offsets: IndexSet) {
        let start = currentQueueIndex + 1
        let absoluteIndices = offsets.map { start + $0 }.sorted(by: >)
        let removedIDs = Set(absoluteIndices.compactMap { queue.indices.contains($0) ? queue[$0].id : nil })
        for index in absoluteIndices where queue.indices.contains(index) {
            queue.remove(at: index)
        }
        sourceQueue.removeAll { removedIDs.contains($0.id) }
        updateNowPlaying()
    }

    func clearUpcoming() {
        guard !queue.isEmpty else { return }
        queue = Array(queue.prefix(currentQueueIndex + 1))
        let retainedIDs = Set(queue.map(\.id))
        sourceQueue.removeAll { !retainedIDs.contains($0.id) }
        updateNowPlaying()
    }

    func setSleepTimer(_ option: SleepTimerOption) {
        sleepTimer?.invalidate()
        sleepTimer = nil
        sleepTimerOption = option
        sleepTimerRemaining = option.interval ?? 0

        guard let interval = option.interval else { return }
        let deadline = Date().addingTimeInterval(interval)
        let timer = Timer(timeInterval: 1, repeats: true) { [weak self] timer in
            Task { @MainActor in
                guard let self else {
                    timer.invalidate()
                    return
                }
                self.sleepTimerRemaining = max(0, deadline.timeIntervalSinceNow)
                if self.sleepTimerRemaining <= 0 {
                    timer.invalidate()
                    self.sleepTimer = nil
                    self.sleepTimerOption = .off
                    self.stop()
                }
            }
        }
        sleepTimer = timer
        RunLoop.main.add(timer, forMode: .common)
    }

    func stop() {
        playbackTimer?.invalidate()
        playbackTimer = nil
        sleepTimer?.invalidate()
        sleepTimer = nil
        audioPlayer?.delegate = nil
        audioPlayer?.stop()
        audioPlayer = nil
        isPlaying = false
        elapsed = 0
        duration = 0
        meterLevel = 0
        currentTrack = nil
        queue = []
        sourceQueue = []
        currentQueueIndex = 0
        sleepTimerOption = .off
        sleepTimerRemaining = 0
        lastNowPlayingProgressUpdate = 0
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
    }

    func seek(to value: Double) {
        guard let audioPlayer else { return }
        let clamped = safeSeekPosition(value, duration: audioPlayer.duration)
        audioPlayer.currentTime = clamped
        elapsed = clamped
        updateNowPlayingProgress()
    }

    @discardableResult
    private func loadAndPlay(_ track: Track) -> Bool {
        guard let url = track.fileURL, FileManager.default.fileExists(atPath: url.path) else {
            clearUnplayableTrack()
            return false
        }

        playbackTimer?.invalidate()
        playbackTimer = nil
        audioPlayer?.delegate = nil
        audioPlayer?.stop()
        audioPlayer = nil
        isPlaying = false
        elapsed = 0
        meterLevel = 0

        do {
            let newPlayer = try AVAudioPlayer(contentsOf: url)
            newPlayer.delegate = audioDelegate
            newPlayer.isMeteringEnabled = true
            newPlayer.volume = Float(min(max(volume, 0), 1))
            newPlayer.prepareToPlay()
            audioPlayer = newPlayer

            guard newPlayer.play() else {
                clearUnplayableTrack()
                return false
            }

            currentTrack = track
            onTrackStarted?(track)
            duration = newPlayer.duration
            elapsed = 0
            isPlaying = true
            lastNowPlayingProgressUpdate = 0
            startPlaybackTimer()
            updateNowPlaying()
            return true
        } catch {
            clearUnplayableTrack()
            return false
        }
    }

    private func artworkSource(for track: Track) -> Track? {
        let candidates = queue + sourceQueue
        return candidates.first {
            $0.artworkData != nil &&
            $0.album.caseInsensitiveCompare(track.album) == .orderedSame &&
            $0.albumArtist.caseInsensitiveCompare(track.albumArtist) == .orderedSame
        }
    }

    private func safeSeekPosition(_ requested: Double, duration: Double) -> Double {
        guard duration.isFinite, duration > 0 else { return 0 }
        // Avoid assigning the exact end time. AVAudioPlayer can treat that as a
        // natural completion and immediately advance the queue.
        let endGuard = duration > 1.25 ? duration - 0.75 : duration
        return min(max(0, requested), max(0, endGuard))
    }

    private func clearUnplayableTrack() {
        playbackTimer?.invalidate()
        playbackTimer = nil
        audioPlayer?.delegate = nil
        audioPlayer?.stop()
        audioPlayer = nil
        currentTrack = nil
        isPlaying = false
        elapsed = 0
        duration = 0
        meterLevel = 0
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
    }

    private func startPlaybackTimer() {
        playbackTimer?.invalidate()
        let timer = Timer(timeInterval: 0.12, repeats: true) { [weak self] _ in
            Task { @MainActor in
                guard let self, let audioPlayer = self.audioPlayer else { return }
                self.elapsed = audioPlayer.currentTime
                audioPlayer.updateMeters()
                let decibels = audioPlayer.averagePower(forChannel: 0)
                let linear = pow(10.0, Double(decibels) / 20.0)
                self.meterLevel = audioPlayer.isPlaying ? min(1, max(0.06, linear * 4.5)) : 0.08

                if abs(self.elapsed - self.lastNowPlayingProgressUpdate) >= 0.8 {
                    self.lastNowPlayingProgressUpdate = self.elapsed
                    self.updateNowPlayingProgress()
                }
            }
        }
        playbackTimer = timer
        RunLoop.main.add(timer, forMode: .common)
    }

    fileprivate func handlePlaybackFinished(_ finishedPlayer: AVAudioPlayer, successfully: Bool) {
        guard let audioPlayer, finishedPlayer === audioPlayer else { return }

        if sleepTimerOption == .endOfTrack {
            stop()
        } else if repeatMode == .one, let currentTrack {
            _ = loadAndPlay(currentTrack)
        } else {
            next()
        }
    }

    fileprivate func handleDecodeError(_ failedPlayer: AVAudioPlayer, error: Error?) {
        guard let audioPlayer, failedPlayer === audioPlayer else { return }
        clearUnplayableTrack()
    }

    private func configureSession() {
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try? AVAudioSession.sharedInstance().setActive(true)
    }

    private func configureRemoteCommands() {
        let commands = MPRemoteCommandCenter.shared()

        commands.playCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.play() }
            return .success
        }
        commands.pauseCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.pause() }
            return .success
        }
        commands.nextTrackCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.next() }
            return .success
        }
        commands.previousTrackCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.previous() }
            return .success
        }

        commands.skipForwardCommand.isEnabled = true
        commands.skipForwardCommand.preferredIntervals = [15]
        commands.skipForwardCommand.addTarget { [weak self] event in
            let interval = (event as? MPSkipIntervalCommandEvent)?.interval ?? 15
            Task { @MainActor in self?.skip(by: interval) }
            return .success
        }

        commands.skipBackwardCommand.isEnabled = true
        commands.skipBackwardCommand.preferredIntervals = [15]
        commands.skipBackwardCommand.addTarget { [weak self] event in
            let interval = (event as? MPSkipIntervalCommandEvent)?.interval ?? 15
            Task { @MainActor in self?.skip(by: -interval) }
            return .success
        }

        commands.changePlaybackPositionCommand.addTarget { [weak self] event in
            guard let event = event as? MPChangePlaybackPositionCommandEvent else { return .commandFailed }
            Task { @MainActor in self?.seek(to: event.positionTime) }
            return .success
        }
    }

    private func updateNowPlaying() {
        guard let track = currentTrack else { return }
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: track.title,
            MPMediaItemPropertyArtist: track.artist,
            MPMediaItemPropertyAlbumTitle: track.album,
            MPMediaItemPropertyPlaybackDuration: duration,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: elapsed,
            MPNowPlayingInfoPropertyPlaybackRate: isPlaying ? 1 : 0,
            MPNowPlayingInfoPropertyPlaybackQueueIndex: currentQueueIndex,
            MPNowPlayingInfoPropertyPlaybackQueueCount: queue.count
        ]
        if let data = artworkData(for: track), let image = UIImage(data: data) {
            info[MPMediaItemPropertyArtwork] = MPMediaItemArtwork(boundsSize: image.size) { requestedSize in
                image.resonanceAspectFit(to: requestedSize) ?? image
            }
        }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }

    private func updateNowPlayingProgress() {
        guard var info = MPNowPlayingInfoCenter.default().nowPlayingInfo else {
            updateNowPlaying()
            return
        }
        info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = elapsed
        info[MPNowPlayingInfoPropertyPlaybackRate] = isPlaying ? 1 : 0
        info[MPMediaItemPropertyPlaybackDuration] = duration
        info[MPNowPlayingInfoPropertyPlaybackQueueIndex] = currentQueueIndex
        info[MPNowPlayingInfoPropertyPlaybackQueueCount] = queue.count
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }
}

private final class AudioPlayerDelegateProxy: NSObject, AVAudioPlayerDelegate {
    weak var owner: PlayerController?

    init(owner: PlayerController) {
        self.owner = owner
    }

    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        Task { @MainActor [weak owner] in
            owner?.handlePlaybackFinished(player, successfully: flag)
        }
    }

    func audioPlayerDecodeErrorDidOccur(_ player: AVAudioPlayer, error: Error?) {
        Task { @MainActor [weak owner] in
            owner?.handleDecodeError(player, error: error)
        }
    }
}

private extension UIImage {
    func resonanceAspectFit(to requestedSize: CGSize) -> UIImage? {
        guard requestedSize.width > 0, requestedSize.height > 0 else { return self }
        let scale = min(requestedSize.width / size.width, requestedSize.height / size.height)
        let fitted = CGSize(width: max(1, size.width * scale), height: max(1, size.height * scale))
        return preparingThumbnail(of: fitted)
    }
}
