# Resonance Prototype — Stage 1.5 Navigation & Theme Revision

This revision builds on the first-stage SwiftUI prototype and focuses on test feedback.

## Changes in this build

- Mini-player is inserted above the bottom tab bar rather than covering it.
- Four bottom tabs: Playing, Library, Streaming, and Settings.
- The Now Playing screen has visible Library navigation controls.
- Leftward swipe navigation is supported on Now Playing and album detail screens.
- Album compact rows are reduced to a single text line with minimal vertical padding.
- Hex color input is labeled and split into red, green, and blue channel fields.
- Optional **Apply theme color to text** setting.
- Live theme preview showing album, artist, track, and mini-player styling.
- Expanded Prototype Status section with individual feature states and progress.
- Streaming Library placeholder screen and persistent host, port, and buffer settings.

## Install

1. Unzip the project on your Mac.
2. Open `Resonance.xcodeproj` in Xcode.
3. Select the Resonance target, open **Signing & Capabilities**, and choose your Apple development team.
4. Connect and trust your iPhone.
5. Select the iPhone as the run destination and press Run.

## Current scope

This remains a prototype. Local importing, SQLite indexing, basic AVFoundation playback, library grouping, and UI settings are present. Robust FLAC-specific decoding validation, true configurable gapless buffering, metadata writing, artwork repository lookup, server authentication, and remote audio streaming are not implemented yet.
