import SwiftUI

struct AlbumDetailView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var player: PlayerController
    let album: Album

    var body: some View {
        List {
            Section {
                VStack(spacing: 12) {
                    ArtworkView(data: album.artworkData, embedded: true, size: 220)
                    Text(album.title).font(.title2.bold())
                    Text(album.artist).foregroundStyle(.secondary)
                    Button { if let first = album.tracks.first { player.play(first, in: album.tracks) } } label: {
                        Label("Play Album", systemImage: "play.fill").frame(maxWidth: .infinity)
                    }.buttonStyle(.borderedProminent)
                }.frame(maxWidth: .infinity).listRowBackground(Color.clear)
            }
            Section("Tracks") {
                ForEach(album.tracks) { track in
                    Button { player.play(track, in: album.tracks) } label: {
                        HStack {
                            Text(track.trackNumber > 0 ? "\(track.trackNumber)" : "–").foregroundStyle(.secondary).frame(width: 28, alignment: .trailing)
                            VStack(alignment: .leading) { Text(track.title); Text(track.artist).font(.caption).foregroundStyle(.secondary) }
                            Spacer()
                            Text(format(track.duration)).font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                        }
                    }.buttonStyle(.plain)
                }
            }
        }
        .navigationTitle(album.title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button { dismiss() } label: { Label("Back", systemImage: "chevron.left") }
            }
        }
        .contentShape(Rectangle())
        .gesture(
            DragGesture(minimumDistance: 45)
                .onEnded { value in
                    if value.translation.width < -70 { dismiss() }
                }
        )
    }
}

struct TrackListView: View {
    @EnvironmentObject private var player: PlayerController
    let tracks: [Track]
    var body: some View {
        List(tracks) { track in
            Button { player.play(track, in: tracks) } label: {
                HStack {
                    ArtworkView(data: track.artworkData, embedded: track.artworkIsEmbedded, size: 46)
                    VStack(alignment: .leading) { Text(track.title); Text("\(track.artist) — \(track.album)").font(.caption).foregroundStyle(.secondary).lineLimit(1) }
                    Spacer(); Text(format(track.duration)).font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                }
            }.buttonStyle(.plain)
        }
    }
}

func format(_ seconds: Double) -> String {
    guard seconds.isFinite, seconds > 0 else { return "—:—" }
    return String(format: "%d:%02d", Int(seconds) / 60, Int(seconds) % 60)
}
