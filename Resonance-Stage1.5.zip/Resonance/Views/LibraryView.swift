import SwiftUI
import UniformTypeIdentifiers

struct LibraryView: View {
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var settings: AppSettings
    @State private var importing = false

    var body: some View {
        Group {
            if library.isScanning { ProgressView("Indexing music…") }
            else {
                switch library.grouping {
                case .artists: ArtistListView(artists: library.artists)
                case .albumArtists: ArtistListView(artists: library.albumArtists)
                case .albums: AlbumCollectionView(albums: library.albums)
                case .songs: TrackListView(tracks: library.filteredTracks)
                }
            }
        }
        .navigationTitle("Library")
        .searchable(text: $library.searchText)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Menu {
                    Picker("Browse", selection: $library.grouping) {
                        ForEach(LibraryGrouping.allCases) { Text($0.rawValue).tag($0) }
                    }
                    Picker("Sort", selection: $library.sortDirection) {
                        ForEach(SortDirection.allCases) { Text($0.rawValue).tag($0) }
                    }
                } label: { Label(library.grouping.rawValue, systemImage: "line.3.horizontal.decrease.circle") }
            }
            ToolbarItem(placement: .topBarTrailing) {
                Button { importing = true } label: { Image(systemName: "plus") }
            }
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.audio, .folder], allowsMultipleSelection: true) { result in
            if case .success(let urls) = result { Task { await library.importURLs(urls) } }
        }
    }
}

struct ArtistListView: View {
    let artists: [Artist]
    var body: some View {
        List(artists) { artist in
            NavigationLink(value: artist) {
                HStack(spacing: 14) {
                    PlaceholderArtwork(symbol: "person.fill", size: 48)
                    VStack(alignment: .leading) {
                        Text(artist.name).font(.headline)
                        Text("\(artist.albums.count) album\(artist.albums.count == 1 ? "" : "s")").font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
        }
        .navigationDestination(for: Artist.self) { artist in
            AlbumCollectionView(albums: artist.albums).navigationTitle(artist.name)
        }
    }
}

struct AlbumCollectionView: View {
    @EnvironmentObject private var settings: AppSettings
    let albums: [Album]
    private let columns = Array(repeating: GridItem(.flexible(), spacing: 12), count: 3)

    var body: some View {
        Group {
            if settings.albumLayout == .grid {
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 18) {
                        ForEach(albums) { album in
                            NavigationLink(value: album) { AlbumTile(album: album) }.buttonStyle(.plain)
                        }
                    }.padding()
                }
            } else {
                List(albums) { album in
                    NavigationLink(value: album) {
                        if settings.albumLayout == .compact {
                            HStack(spacing: 8) {
                                ArtworkView(data: album.artworkData, embedded: true, size: 28)
                                Text(album.title).font(.subheadline.weight(.medium)).lineLimit(1)
                                Text("— \(album.artist)").font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
                            }
                            .padding(.vertical, 1)
                        } else {
                            HStack(spacing: 12) {
                                ArtworkView(data: album.artworkData, embedded: true, size: 84)
                                VStack(alignment: .leading) {
                                    Text(album.title).font(.headline)
                                    Text(album.artist).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                    .listRowInsets(EdgeInsets(top: settings.albumLayout == .compact ? 2 : 8, leading: 16, bottom: settings.albumLayout == .compact ? 2 : 8, trailing: 16))
                }
            }
        }
        .navigationDestination(for: Album.self) { AlbumDetailView(album: $0) }
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Picker("Layout", selection: $settings.albumLayout) {
                        ForEach(AlbumLayout.allCases) { Text($0.rawValue).tag($0) }
                    }
                } label: { Image(systemName: settings.albumLayout == .grid ? "square.grid.3x3" : "list.bullet") }
            }
        }
    }
}

struct AlbumTile: View {
    let album: Album
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ArtworkView(data: album.artworkData, embedded: true, size: 110)
                .frame(maxWidth: .infinity)
            Text(album.title).font(.caption.weight(.semibold)).lineLimit(1)
            Text(album.artist).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
        }
    }
}
