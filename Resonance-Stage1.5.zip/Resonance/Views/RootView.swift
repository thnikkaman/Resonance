import SwiftUI

enum AppTab: Hashable {
    case playing, library, streaming, settings
}

struct RootView: View {
    @EnvironmentObject private var player: PlayerController
    @EnvironmentObject private var settings: AppSettings
    @State private var selectedTab: AppTab = .library

    var body: some View {
        TabView(selection: $selectedTab) {
            NavigationStack {
                NowPlayingView(openLibrary: { selectedTab = .library })
            }
            .tabItem { Label("Playing", systemImage: "music.note") }
            .tag(AppTab.playing)

            NavigationStack { LibraryView() }
                .tabItem { Label("Library", systemImage: "square.stack") }
                .tag(AppTab.library)

            NavigationStack { StreamingLibraryView() }
                .tabItem { Label("Streaming", systemImage: "network") }
                .tag(AppTab.streaming)

            NavigationStack { SettingsView() }
                .tabItem { Label("Settings", systemImage: "gearshape") }
                .tag(AppTab.settings)
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            if player.currentTrack != nil && selectedTab != .playing {
                MiniPlayerView(openNowPlaying: { selectedTab = .playing })
                    .padding(.horizontal, 8)
                    .padding(.bottom, 2)
            }
        }
        .foregroundStyle(settings.applyThemeColorToText ? settings.accentColor : Color.primary)
    }
}

struct StreamingLibraryView: View {
    @EnvironmentObject private var settings: AppSettings

    var body: some View {
        List {
            Section("Private music server") {
                if settings.streamHost.isEmpty {
                    ContentUnavailableView(
                        "No Streaming Library",
                        systemImage: "externaldrive.badge.wifi",
                        description: Text("Enter your Tailscale-reachable server address in Settings, then connect to browse your remote music library.")
                    )
                } else {
                    LabeledContent("Server", value: settings.streamHost)
                    LabeledContent("Port", value: settings.streamPort.isEmpty ? "Server default" : settings.streamPort)
                    LabeledContent("Buffer", value: "\(Int(settings.networkBufferMB)) MB")
                    Button("Test Connection") { }
                        .buttonStyle(.borderedProminent)
                }
            }

            Section("Stage status") {
                Label("Server browser UI ready", systemImage: "checkmark.circle.fill")
                Label("Authentication and streaming engine planned", systemImage: "hammer")
            }
        }
        .navigationTitle("Streaming Library")
    }
}
