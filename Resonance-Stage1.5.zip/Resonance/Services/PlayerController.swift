import AVFoundation
import MediaPlayer

@MainActor
final class PlayerController: NSObject, ObservableObject, AVAudioPlayerDelegate {
    @Published private(set) var currentTrack: Track?
    @Published private(set) var isPlaying = false
    @Published private(set) var elapsed = 0.0
    @Published private(set) var duration = 0.0
    @Published var queue: [Track] = []

    private var audioPlayer: AVAudioPlayer?
    private var timer: Timer?
    private var index = 0

    override init() {
        super.init()
        configureSession()
        configureRemoteCommands()
    }

    func play(_ track: Track, in tracks: [Track]) {
        queue = tracks
        index = max(0, tracks.firstIndex(of: track) ?? 0)
        loadAndPlay(track)
    }

    func toggle() {
        guard let audioPlayer else { return }
        if audioPlayer.isPlaying { audioPlayer.pause() } else { audioPlayer.play() }
        isPlaying = audioPlayer.isPlaying
        updateNowPlaying()
    }

    func next() {
        guard !queue.isEmpty else { return }
        index = min(index + 1, queue.count - 1)
        loadAndPlay(queue[index])
    }

    func previous() {
        if elapsed > 3 { seek(to: 0); return }
        guard !queue.isEmpty else { return }
        index = max(index - 1, 0)
        loadAndPlay(queue[index])
    }

    func stop() {
        audioPlayer?.stop(); audioPlayer = nil
        timer?.invalidate(); timer = nil
        isPlaying = false; elapsed = 0
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
    }

    func seek(to value: Double) {
        audioPlayer?.currentTime = value
        elapsed = value
    }

    private func loadAndPlay(_ track: Track) {
        currentTrack = track
        duration = track.duration
        guard let url = track.fileURL else {
            isPlaying = false
            return
        }
        do {
            let player = try AVAudioPlayer(contentsOf: url)
            player.delegate = self
            player.prepareToPlay()
            player.play()
            audioPlayer = player
            duration = player.duration
            isPlaying = true
            startTimer()
            updateNowPlaying()
        } catch {
            isPlaying = false
        }
    }

    private func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.elapsed = self?.audioPlayer?.currentTime ?? 0 }
        }
    }

    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        if index + 1 < queue.count { next() } else { stop() }
    }

    private func configureSession() {
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try? AVAudioSession.sharedInstance().setActive(true)
    }

    private func configureRemoteCommands() {
        let commands = MPRemoteCommandCenter.shared()
        commands.playCommand.addTarget { [weak self] _ in self?.toggle(); return .success }
        commands.pauseCommand.addTarget { [weak self] _ in self?.toggle(); return .success }
        commands.nextTrackCommand.addTarget { [weak self] _ in self?.next(); return .success }
        commands.previousTrackCommand.addTarget { [weak self] _ in self?.previous(); return .success }
    }

    private func updateNowPlaying() {
        guard let track = currentTrack else { return }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [
            MPMediaItemPropertyTitle: track.title,
            MPMediaItemPropertyArtist: track.artist,
            MPMediaItemPropertyAlbumTitle: track.album,
            MPMediaItemPropertyPlaybackDuration: duration,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: elapsed,
            MPNowPlayingInfoPropertyPlaybackRate: isPlaying ? 1 : 0
        ]
    }
}
