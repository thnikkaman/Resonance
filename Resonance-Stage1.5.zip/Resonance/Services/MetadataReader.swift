import AVFoundation
import Foundation

struct MetadataReader {
    static let supportedExtensions: Set<String> = ["flac", "mp3", "m4a", "aac", "wav", "aif", "aiff", "caf", "alac"]

    func track(from url: URL) async -> Track? {
        guard Self.supportedExtensions.contains(url.pathExtension.lowercased()) else { return nil }
        let asset = AVURLAsset(url: url)
        let duration = (try? await asset.load(.duration).seconds) ?? 0
        let metadata = (try? await asset.load(.commonMetadata)) ?? []
        var title = url.deletingPathExtension().lastPathComponent
        var artist = "Unknown Artist"
        var album = "Unknown Album"
        var artwork: Data?

        for item in metadata {
            guard let key = item.commonKey else { continue }
            switch key {
            case .commonKeyTitle: title = (try? await item.load(.stringValue)) ?? title
            case .commonKeyArtist: artist = (try? await item.load(.stringValue)) ?? artist
            case .commonKeyAlbumName: album = (try? await item.load(.stringValue)) ?? album
            case .commonKeyArtwork: artwork = try? await item.load(.dataValue)
            default: break
            }
        }
        let inferredTrack = Int(url.deletingPathExtension().lastPathComponent.prefix { $0.isNumber }) ?? 0
        return Track(title: title, artist: artist, album: album, trackNumber: inferredTrack,
                     duration: duration, fileURL: url, artworkData: artwork,
                     artworkIsEmbedded: artwork != nil)
    }
}
