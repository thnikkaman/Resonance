import Foundation
import CryptoKit

struct RemoteLibraryManifest: Decodable, Sendable {
    let version: Int?
    let name: String?
    let tracks: [RemoteTrackRecord]
}

struct RemoteTrackRecord: Decodable, Sendable {
    let id: String?
    let title: String
    let artist: String
    let albumArtist: String?
    let album: String
    let trackNumber: Int?
    let discNumber: Int?
    let releaseYear: Int?
    let duration: Double?
    let fileSize: Int64?
    let path: String
    let artwork: String?
    let artworkBase64: String?
}

struct RemoteTrackItem: Identifiable, Hashable, Codable, Sendable {
    let id: UUID
    let title: String
    let artist: String
    let albumArtist: String
    let album: String
    let trackNumber: Int
    let discNumber: Int
    let releaseYear: Int
    let duration: Double
    let fileSizeBytes: Int64
    let streamURL: URL
    let artworkURL: URL?
    let artworkBase64: String?

    var albumKey: String { "\(albumArtist.lowercased())|\(album.lowercased())" }

    func asTrack(artworkData: Data?) -> Track {
        Track(
            id: id,
            title: title,
            artist: artist,
            albumArtist: albumArtist,
            album: album,
            trackNumber: trackNumber,
            discNumber: discNumber,
            releaseYear: releaseYear,
            duration: duration,
            fileURL: streamURL,
            artworkData: artworkData,
            artworkIsEmbedded: artworkData != nil,
            dateAdded: .distantPast,
            sourceByteSize: fileSizeBytes
        )
    }
}

struct RemoteAlbum: Identifiable, Hashable, Sendable {
    let id: String
    let title: String
    let artist: String
    let tracks: [RemoteTrackItem]

    var artworkURL: URL? { tracks.compactMap(\.artworkURL).first }
    var artworkBase64: String? { tracks.compactMap(\.artworkBase64).first }
    var releaseYear: Int { tracks.map(\.releaseYear).filter { $0 > 0 }.min() ?? 0 }
}

struct RemoteArtist: Identifiable, Hashable, Sendable {
    let id: String
    let name: String
    let albums: [RemoteAlbum]

    var artworkURL: URL? { albums.compactMap(\.artworkURL).first }
    var artworkBase64: String? { albums.compactMap(\.artworkBase64).first }
    var tracks: [RemoteTrackItem] { albums.flatMap(\.tracks) }
}

enum RemoteBrowseGrouping: String, CaseIterable, Identifiable {
    case artists = "Artists"
    case albums = "Albums"
    case songs = "Songs"
    var id: String { rawValue }
}

@MainActor
final class RemoteLibraryStore: ObservableObject {
    @Published private(set) var tracks: [RemoteTrackItem] = []
    @Published private(set) var serverName = "Remote Library"
    @Published private(set) var connectionStatus = "Not connected"
    @Published private(set) var lastRefresh: Date?
    @Published private(set) var isLoading = false
    @Published var searchText = ""
    @Published var grouping: RemoteBrowseGrouping = .artists

    private let artworkCache = NSCache<NSURL, NSData>()
    private static let cachedTracksURL: URL = {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        return base.appendingPathComponent("remote-library-cache.json")
    }()

    init() {
        if let data = try? Data(contentsOf: Self.cachedTracksURL),
           let cached = try? JSONDecoder().decode([RemoteTrackItem].self, from: data) {
            tracks = cached
            connectionStatus = cached.isEmpty ? "Not connected" : "Cached manifest library available"
        }
    }

    var filteredTracks: [RemoteTrackItem] {
        let input = searchText.isEmpty ? tracks : tracks.filter {
            [$0.title, $0.artist, $0.albumArtist, $0.album]
                .contains { $0.localizedCaseInsensitiveContains(searchText) }
        }
        return input.sorted {
            ($0.artist, $0.album, $0.discNumber, $0.trackNumber, $0.title) <
            ($1.artist, $1.album, $1.discNumber, $1.trackNumber, $1.title)
        }
    }

    var albums: [RemoteAlbum] {
        Dictionary(grouping: filteredTracks, by: \.albumKey).map { key, values in
            let sorted = values.sorted {
                ($0.discNumber, $0.trackNumber, $0.title) < ($1.discNumber, $1.trackNumber, $1.title)
            }
            return RemoteAlbum(
                id: key,
                title: sorted.first?.album ?? "Unknown Album",
                artist: sorted.first?.albumArtist ?? "Unknown Artist",
                tracks: sorted
            )
        }
        .sorted { $0.title.localizedStandardCompare($1.title) == .orderedAscending }
    }

    var artists: [RemoteArtist] {
        Dictionary(grouping: albums, by: { $0.artist }).map { name, albums in
            RemoteArtist(
                id: name.lowercased(),
                name: name,
                albums: albums.sorted { $0.title.localizedStandardCompare($1.title) == .orderedAscending }
            )
        }
        .sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }

    func testConnection(using settings: AppSettings) async {
        isLoading = true
        defer { isLoading = false }

        do {
            switch settings.streamBackend {
            case .subsonic:
                let client = try makeSubsonicClient(using: settings)
                connectionStatus = "Testing Subsonic connection…"
                let server = try await client.ping()
                serverName = server.displayName
                connectionStatus = "Connected — \(server.displayName)"
            case .resonanceManifest:
                guard let url = configuredContentURL(path: settings.streamManifestPath, using: settings) else {
                    throw RemoteLibraryError.missingServerAddress
                }
                connectionStatus = "Testing \(url.host ?? "server")…"
                let (data, response) = try await URLSession.shared.data(for: request(for: url))
                try validate(response: response, data: data)
                let manifest = try JSONDecoder().decode(RemoteLibraryManifest.self, from: data)
                serverName = manifest.name?.trimmingCharacters(in: .whitespacesAndNewlines).nonEmpty ?? "Remote Library"
                connectionStatus = "Connected — \(manifest.tracks.count) tracks available"
            }
        } catch {
            connectionStatus = "Connection failed: \(error.localizedDescription)"
        }
    }

    func refresh(using settings: AppSettings) async {
        isLoading = true
        defer { isLoading = false }

        do {
            switch settings.streamBackend {
            case .subsonic:
                try await refreshSubsonic(using: settings)
            case .resonanceManifest:
                try await refreshManifest(using: settings)
            }
        } catch {
            connectionStatus = "Refresh failed: \(error.localizedDescription)"
        }
    }

    func play(_ selected: RemoteTrackItem, in context: [RemoteTrackItem], using player: PlayerController) async {
        let ordered = context.isEmpty ? [selected] : context
        let prepared = await preparePlaybackTracks(ordered, priority: selected)
        guard let target = prepared.first(where: { $0.id == selected.id }) else { return }
        player.play(target, in: prepared)
    }

    func playAlbum(_ album: RemoteAlbum, using player: PlayerController, shuffle: Bool = false) async {
        let prepared = await preparePlaybackTracks(album.tracks, priority: album.tracks.first)
        guard !prepared.isEmpty else { return }
        if shuffle {
            player.shuffleAndPlay(prepared)
        } else if let first = prepared.first {
            player.play(first, in: prepared)
        }
    }

    func playArtist(_ artist: RemoteArtist, using player: PlayerController, shuffle: Bool = false) async {
        let ordered = artist.albums.flatMap(\.tracks)
        let prepared = await preparePlaybackTracks(ordered, priority: ordered.first)
        guard !prepared.isEmpty else { return }
        if shuffle {
            player.shuffleAndPlay(prepared)
        } else if let first = prepared.first {
            player.play(first, in: prepared)
        }
    }

    func artworkData(for item: RemoteTrackItem) async -> Data? {
        if let encoded = item.artworkBase64, let data = Data(base64Encoded: encoded) { return data }
        guard let url = item.artworkURL else { return nil }
        if let cached = artworkCache.object(forKey: url as NSURL) { return cached as Data }

        do {
            let (data, response) = try await URLSession.shared.data(for: request(for: url))
            guard let http = response as? HTTPURLResponse,
                  (200..<300).contains(http.statusCode),
                  data.count <= 12 * 1_048_576 else { return nil }
            artworkCache.setObject(data as NSData, forKey: url as NSURL)
            return data
        } catch {
            return nil
        }
    }

    private func refreshManifest(using settings: AppSettings) async throws {
        guard let manifestURL = configuredContentURL(path: settings.streamManifestPath, using: settings) else {
            throw RemoteLibraryError.missingServerAddress
        }
        connectionStatus = "Loading Resonance manifest…"
        let (data, response) = try await URLSession.shared.data(for: request(for: manifestURL))
        try validate(response: response, data: data)
        let manifest = try JSONDecoder().decode(RemoteLibraryManifest.self, from: data)
        let resolved = manifest.tracks.compactMap { resolveManifestTrack($0, relativeTo: manifestURL) }
        tracks = resolved
        serverName = manifest.name?.trimmingCharacters(in: .whitespacesAndNewlines).nonEmpty ?? "Remote Library"
        lastRefresh = Date()
        connectionStatus = "Connected — \(resolved.count) tracks indexed"
        if let stored = try? JSONEncoder().encode(resolved) {
            try? stored.write(to: Self.cachedTracksURL, options: .atomic)
        }
    }

    private func refreshSubsonic(using settings: AppSettings) async throws {
        let client = try makeSubsonicClient(using: settings)
        connectionStatus = "Connecting to Navidrome / Subsonic…"
        let server = try await client.ping()
        serverName = server.displayName

        connectionStatus = "Loading album index…"
        let summaries = try await client.fetchAlbumSummaries()
        var resolved: [RemoteTrackItem] = []
        resolved.reserveCapacity(summaries.reduce(0) { $0 + max(0, $1.songCount ?? 0) })

        let batchSize = 8
        for batchStart in stride(from: 0, to: summaries.count, by: batchSize) {
            let batchEnd = min(batchStart + batchSize, summaries.count)
            let batch = Array(summaries[batchStart..<batchEnd])
            let batchTracks = await withTaskGroup(of: [RemoteTrackItem].self, returning: [RemoteTrackItem].self) { group in
                for summary in batch {
                    group.addTask {
                        (try? await client.fetchTracks(for: summary)) ?? []
                    }
                }
                var result: [RemoteTrackItem] = []
                for await albumTracks in group { result.append(contentsOf: albumTracks) }
                return result
            }
            resolved.append(contentsOf: batchTracks)
            connectionStatus = "Indexing albums \(batchEnd) of \(summaries.count)…"
        }

        tracks = resolved.sorted {
            ($0.artist, $0.album, $0.discNumber, $0.trackNumber, $0.title) <
            ($1.artist, $1.album, $1.discNumber, $1.trackNumber, $1.title)
        }
        lastRefresh = Date()
        connectionStatus = "Connected — \(tracks.count) tracks indexed from \(server.displayName)"

        // Authenticated Subsonic stream URLs are deliberately not written to disk.
        try? FileManager.default.removeItem(at: Self.cachedTracksURL)
    }

    private func makeSubsonicClient(using settings: AppSettings) throws -> SubsonicClient {
        guard !settings.streamUsername.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw RemoteLibraryError.missingUsername
        }
        guard !settings.streamPassword.isEmpty else { throw RemoteLibraryError.missingPassword }
        guard let apiURL = configuredContentURL(path: settings.streamManifestPath, using: settings) else {
            throw RemoteLibraryError.missingServerAddress
        }
        return SubsonicClient(
            apiBaseURL: apiURL,
            username: settings.streamUsername.trimmingCharacters(in: .whitespacesAndNewlines),
            password: settings.streamPassword
        )
    }

    private func configuredContentURL(path: String, using settings: AppSettings) -> URL? {
        let rawHost = settings.streamHost.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !rawHost.isEmpty else { return nil }

        var components: URLComponents
        if rawHost.contains("://"), let supplied = URLComponents(string: rawHost) {
            components = supplied
        } else {
            components = URLComponents()
            components.scheme = settings.streamUseHTTPS ? "https" : "http"
            components.host = rawHost
        }

        let trimmedPort = settings.streamPort.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmedPort.isEmpty, let port = Int(trimmedPort), port > 0 { components.port = port }
        components.query = nil
        components.fragment = nil

        let basePath = components.path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let requestedPath = path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        if requestedPath.isEmpty {
            components.path = basePath.isEmpty ? "/" : "/" + basePath
        } else if basePath == requestedPath || basePath.hasSuffix("/" + requestedPath) {
            components.path = "/" + basePath
        } else {
            components.path = "/" + [basePath, requestedPath].filter { !$0.isEmpty }.joined(separator: "/")
        }
        return components.url
    }

    private func preparePlaybackTracks(
        _ items: [RemoteTrackItem],
        priority: RemoteTrackItem?
    ) async -> [Track] {
        var artworkByKey: [String: Data] = [:]
        let prioritized = priority.map { [$0] } ?? []
        let uniqueArtworkItems = (prioritized + items).reduce(into: [RemoteTrackItem]()) { result, item in
            guard artworkByKey[item.albumKey] == nil,
                  !result.contains(where: { $0.albumKey == item.albumKey }) else { return }
            if result.count < 24 || item.id == priority?.id { result.append(item) }
        }

        for item in uniqueArtworkItems {
            if let data = await artworkData(for: item) { artworkByKey[item.albumKey] = data }
        }

        return items.map { item in item.asTrack(artworkData: artworkByKey[item.albumKey]) }
    }

    private func request(for url: URL) -> URLRequest {
        var request = URLRequest(url: url)
        request.timeoutInterval = 20
        request.cachePolicy = .reloadRevalidatingCacheData
        request.setValue("application/json, audio/*, image/*;q=0.9, */*;q=0.1", forHTTPHeaderField: "Accept")
        return request
    }

    private func validate(response: URLResponse, data: Data) throws {
        guard let http = response as? HTTPURLResponse else { throw RemoteLibraryError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else {
            throw RemoteLibraryError.httpStatus(http.statusCode, String(data: data.prefix(300), encoding: .utf8))
        }
    }

    private func resolveManifestTrack(_ record: RemoteTrackRecord, relativeTo manifestURL: URL) -> RemoteTrackItem? {
        guard let streamURL = URL(string: record.path, relativeTo: manifestURL)?.absoluteURL else { return nil }
        let artworkURL = record.artwork.flatMap { URL(string: $0, relativeTo: manifestURL)?.absoluteURL }
        let stableSource = record.id?.nonEmpty ?? streamURL.absoluteString
        return RemoteTrackItem(
            id: UUID(uuidString: stableSource) ?? Self.stableUUID(for: stableSource),
            title: record.title.nonEmpty ?? streamURL.deletingPathExtension().lastPathComponent,
            artist: record.artist.nonEmpty ?? "Unknown Artist",
            albumArtist: record.albumArtist?.nonEmpty ?? record.artist.nonEmpty ?? "Unknown Artist",
            album: record.album.nonEmpty ?? "Unknown Album",
            trackNumber: max(0, record.trackNumber ?? 0),
            discNumber: max(1, record.discNumber ?? 1),
            releaseYear: max(0, record.releaseYear ?? 0),
            duration: max(0, record.duration ?? 0),
            fileSizeBytes: max(0, record.fileSize ?? 0),
            streamURL: streamURL,
            artworkURL: artworkURL,
            artworkBase64: record.artworkBase64
        )
    }

    fileprivate static func stableUUID(for string: String) -> UUID {
        func hash(seed: UInt64) -> UInt64 {
            var value = seed
            for byte in string.utf8 {
                value ^= UInt64(byte)
                value &*= 1_099_511_628_211
            }
            return value
        }
        let high = hash(seed: 14_695_981_039_346_656_037)
        let low = hash(seed: 7_801_984_618_907_684_001)
        let raw = String(format: "%016llX%016llX", high, low)
        let uuidString = "\(raw.prefix(8))-\(raw.dropFirst(8).prefix(4))-\(raw.dropFirst(12).prefix(4))-\(raw.dropFirst(16).prefix(4))-\(raw.dropFirst(20).prefix(12))"
        return UUID(uuidString: uuidString) ?? UUID()
    }
}

private struct SubsonicClient: Sendable {
    let apiBaseURL: URL
    let username: String
    let password: String

    func ping() async throws -> SubsonicServerInfo {
        let envelope: SubsonicPingEnvelope = try await fetch("ping.view", queryItems: [])
        try validate(status: envelope.response.status, error: envelope.response.error)
        return SubsonicServerInfo(
            type: envelope.response.type,
            version: envelope.response.serverVersion,
            openSubsonic: envelope.response.openSubsonic ?? false
        )
    }

    func fetchAlbumSummaries() async throws -> [SubsonicAlbumSummary] {
        let pageSize = 500
        var offset = 0
        var albums: [SubsonicAlbumSummary] = []

        while true {
            let envelope: SubsonicAlbumListEnvelope = try await fetch(
                "getAlbumList2.view",
                queryItems: [
                    URLQueryItem(name: "type", value: "alphabeticalByName"),
                    URLQueryItem(name: "size", value: String(pageSize)),
                    URLQueryItem(name: "offset", value: String(offset))
                ]
            )
            try validate(status: envelope.response.status, error: envelope.response.error)
            let page = envelope.response.albumList2?.album ?? []
            albums.append(contentsOf: page)
            if page.count < pageSize { break }
            offset += page.count
            if offset >= 100_000 { break }
        }
        return albums
    }

    func fetchTracks(for summary: SubsonicAlbumSummary) async throws -> [RemoteTrackItem] {
        let envelope: SubsonicAlbumEnvelope = try await fetch(
            "getAlbum.view",
            queryItems: [URLQueryItem(name: "id", value: summary.id)]
        )
        try validate(status: envelope.response.status, error: envelope.response.error)
        guard let album = envelope.response.album else { return [] }

        return try (album.song ?? []).map { song in
            let streamURL = try endpointURL(
                "stream.view",
                queryItems: [
                    URLQueryItem(name: "id", value: song.id),
                    URLQueryItem(name: "format", value: "raw"),
                    URLQueryItem(name: "estimateContentLength", value: "true")
                ]
            )
            let coverIdentifier = song.coverArt?.nonEmpty ?? album.coverArt?.nonEmpty ?? summary.coverArt?.nonEmpty
            let artworkURL = try coverIdentifier.map {
                try endpointURL(
                    "getCoverArt.view",
                    queryItems: [
                        URLQueryItem(name: "id", value: $0),
                        URLQueryItem(name: "size", value: "1200")
                    ]
                )
            }
            let albumArtist = song.albumArtist?.nonEmpty
                ?? song.displayAlbumArtist?.nonEmpty
                ?? album.artist?.nonEmpty
                ?? summary.artist?.nonEmpty
                ?? song.artist?.nonEmpty
                ?? "Unknown Artist"
            let artist = song.artist?.nonEmpty ?? albumArtist
            let albumTitle = song.album?.nonEmpty ?? album.name.nonEmpty ?? summary.name.nonEmpty ?? "Unknown Album"
            let stableSource = "subsonic|\(apiBaseURL.absoluteString)|\(song.id)"

            return RemoteTrackItem(
                id: RemoteLibraryStore.stableUUID(for: stableSource),
                title: song.title.nonEmpty ?? "Unknown Track",
                artist: artist,
                albumArtist: albumArtist,
                album: albumTitle,
                trackNumber: max(0, song.track ?? 0),
                discNumber: max(1, song.discNumber ?? 1),
                releaseYear: max(0, song.year ?? album.year ?? summary.year ?? 0),
                duration: max(0, song.duration ?? 0),
                fileSizeBytes: max(0, song.size ?? 0),
                streamURL: streamURL,
                artworkURL: artworkURL,
                artworkBase64: nil
            )
        }
    }

    private func fetch<T: Decodable & Sendable>(_ endpoint: String, queryItems: [URLQueryItem]) async throws -> T {
        let url = try endpointURL(endpoint, queryItems: queryItems)
        var request = URLRequest(url: url)
        request.timeoutInterval = 30
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw RemoteLibraryError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else {
            throw RemoteLibraryError.httpStatus(http.statusCode, String(data: data.prefix(300), encoding: .utf8))
        }
        do {
            return try JSONDecoder().decode(T.self, from: data)
        } catch {
            let preview = String(data: data.prefix(300), encoding: .utf8)
            throw RemoteLibraryError.subsonicDecoding(preview)
        }
    }

    private func endpointURL(_ endpoint: String, queryItems: [URLQueryItem]) throws -> URL {
        guard var components = URLComponents(url: apiBaseURL, resolvingAgainstBaseURL: false) else {
            throw RemoteLibraryError.invalidServerAddress
        }
        let basePath = components.path.hasSuffix("/") ? String(components.path.dropLast()) : components.path
        components.path = basePath + "/" + endpoint

        let salt = UUID().uuidString.replacingOccurrences(of: "-", with: "").prefix(16).lowercased()
        let tokenSource = Data((password + salt).utf8)
        let token = Insecure.MD5.hash(data: tokenSource).map { String(format: "%02x", $0) }.joined()
        components.queryItems = [
            URLQueryItem(name: "u", value: username),
            URLQueryItem(name: "t", value: token),
            URLQueryItem(name: "s", value: salt),
            URLQueryItem(name: "v", value: "1.16.1"),
            URLQueryItem(name: "c", value: "Resonance"),
            URLQueryItem(name: "f", value: "json")
        ] + queryItems
        guard let url = components.url else { throw RemoteLibraryError.invalidServerAddress }
        return url
    }

    private func validate(status: String, error: SubsonicErrorInfo?) throws {
        guard status.lowercased() == "ok" else {
            throw RemoteLibraryError.subsonicError(error?.code, error?.message)
        }
    }
}

private struct SubsonicServerInfo: Sendable {
    let type: String?
    let version: String?
    let openSubsonic: Bool

    var displayName: String {
        let server = type?.trimmingCharacters(in: .whitespacesAndNewlines).nonEmpty ?? "Subsonic server"
        if let version = version?.trimmingCharacters(in: .whitespacesAndNewlines).nonEmpty {
            return "\(server) \(version)"
        }
        return openSubsonic ? "\(server) (OpenSubsonic)" : server
    }
}

private struct SubsonicErrorInfo: Decodable, Sendable {
    let code: Int?
    let message: String?
}

private struct SubsonicPingEnvelope: Decodable, Sendable {
    let response: Response
    enum CodingKeys: String, CodingKey { case response = "subsonic-response" }

    struct Response: Decodable, Sendable {
        let status: String
        let type: String?
        let serverVersion: String?
        let openSubsonic: Bool?
        let error: SubsonicErrorInfo?
    }
}

private struct SubsonicAlbumListEnvelope: Decodable, Sendable {
    let response: Response
    enum CodingKeys: String, CodingKey { case response = "subsonic-response" }

    struct Response: Decodable, Sendable {
        let status: String
        let albumList2: AlbumList?
        let error: SubsonicErrorInfo?
    }

    struct AlbumList: Decodable, Sendable {
        let album: [SubsonicAlbumSummary]?
    }
}

private struct SubsonicAlbumSummary: Decodable, Sendable {
    let id: String
    let name: String
    let artist: String?
    let coverArt: String?
    let songCount: Int?
    let year: Int?
}

private struct SubsonicAlbumEnvelope: Decodable, Sendable {
    let response: Response
    enum CodingKeys: String, CodingKey { case response = "subsonic-response" }

    struct Response: Decodable, Sendable {
        let status: String
        let album: Album?
        let error: SubsonicErrorInfo?
    }

    struct Album: Decodable, Sendable {
        let id: String
        let name: String
        let artist: String?
        let coverArt: String?
        let year: Int?
        let song: [Song]?
    }

    struct Song: Decodable, Sendable {
        let id: String
        let title: String
        let album: String?
        let artist: String?
        let albumArtist: String?
        let displayAlbumArtist: String?
        let track: Int?
        let discNumber: Int?
        let year: Int?
        let duration: Double?
        let size: Int64?
        let coverArt: String?
    }
}

enum RemoteLibraryError: LocalizedError {
    case invalidResponse
    case invalidServerAddress
    case missingServerAddress
    case missingUsername
    case missingPassword
    case httpStatus(Int, String?)
    case subsonicError(Int?, String?)
    case subsonicDecoding(String?)

    var errorDescription: String? {
        switch self {
        case .invalidResponse:
            return "The server returned an invalid response."
        case .invalidServerAddress:
            return "The server address or API path is invalid."
        case .missingServerAddress:
            return "Enter a server URL or Tailscale host first."
        case .missingUsername:
            return "Enter the Navidrome / Subsonic username."
        case .missingPassword:
            return "Enter the Navidrome / Subsonic password."
        case let .httpStatus(code, message):
            if let message = message?.trimmingCharacters(in: .whitespacesAndNewlines), !message.isEmpty {
                return "Server returned HTTP \(code): \(message)"
            }
            return "Server returned HTTP \(code)."
        case let .subsonicError(code, message):
            let codeText = code.map { " (code \($0))" } ?? ""
            return (message?.nonEmpty ?? "The Subsonic server rejected the request") + codeText
        case let .subsonicDecoding(preview):
            if let preview = preview?.trimmingCharacters(in: .whitespacesAndNewlines).nonEmpty {
                return "The server did not return Subsonic JSON: \(preview)"
            }
            return "The server did not return valid Subsonic JSON."
        }
    }
}

private extension String {
    var nonEmpty: String? { isEmpty ? nil : self }
}
