import SwiftUI

enum AppTab: Hashable {
    case playing, library, streaming, settings
}

struct RootView: View {
    @EnvironmentObject private var player: PlayerController
    @EnvironmentObject private var library: LibraryStore
    @EnvironmentObject private var settings: AppSettings
    @State private var selectedTab: AppTab = .library

    var body: some View {
        ZStack(alignment: .bottom) {
            TabView(selection: $selectedTab) {
                NavigationStack {
                    NowPlayingView(openLibrary: { selectedTab = .library })
                }
                .tabItem { Label("Playing", systemImage: "music.note") }
                .tag(AppTab.playing)

                NavigationStack { LibraryView() }
                    .tabItem { Label("Library", systemImage: "square.stack") }
                    .tag(AppTab.library)

                NavigationStack {
                    StreamingLibraryView(
                        openLibrary: { selectedTab = .library },
                        openSettings: { selectedTab = .settings }
                    )
                }
                    .tabItem { Label("Streaming", systemImage: "network") }
                    .tag(AppTab.streaming)

                NavigationStack { SettingsView(openLibrary: { selectedTab = .library }) }
                    .tabItem { Label("Settings", systemImage: "gearshape") }
                    .tag(AppTab.settings)
            }

            if player.currentTrack != nil && selectedTab != .playing {
                MiniPlayerView(openNowPlaying: { selectedTab = .playing })
                    .padding(.horizontal, 8)
                    .padding(.bottom, 58)
                    .zIndex(10)
            }
        }
        .foregroundStyle(settings.applyThemeColorToText ? settings.accentColor : Color.primary)
        .tint(settings.accentColor)
        .onAppear {
            player.onTrackStarted = { track in
                if !track.isRemote { library.markPlayed(track) }
            }
        }
        .onChange(of: settings.preloadNextTrack) { _, _ in
            player.refreshPlaybackConfiguration()
        }
        .onChange(of: settings.localBufferMB) { _, _ in
            player.refreshPlaybackConfiguration()
        }
        .onChange(of: settings.networkBufferMB) { _, _ in
            player.refreshPlaybackConfiguration()
        }
    }
}
