import SwiftUI
import UIKit

struct StreamingLibraryView: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var remote: RemoteLibraryStore
    @EnvironmentObject private var player: PlayerController
    let openLibrary: () -> Void
    let openSettings: () -> Void

    var body: some View {
        Group {
            if settings.streamHost.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                ContentUnavailableView {
                    Label("No Remote Server", systemImage: "externaldrive.badge.wifi")
                } description: {
                    Text("Add a server URL or Tailscale host and choose the correct backend in Settings.")
                } actions: {
                    Button("Open Streaming Settings", action: openSettings)
                        .buttonStyle(.borderedProminent)
                }
            } else {
                List {
                    Section {
                        HStack(alignment: .top, spacing: 12) {
                            Image(systemName: remote.isLoading ? "network.badge.shield.half.filled" : "externaldrive.connected.to.line.below")
                                .font(.title2)
                                .foregroundStyle(settings.accentColor)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(remote.serverName).font(.headline)
                                Text(settings.streamBackend.shortName)
                                    .font(.caption2.weight(.semibold))
                                    .foregroundStyle(settings.accentColor)
                                Text(remote.connectionStatus)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                if let lastRefresh = remote.lastRefresh {
                                    Text("Updated \(lastRefresh.formatted(date: .abbreviated, time: .shortened))")
                                        .font(.caption2)
                                        .foregroundStyle(.secondary)
                                }
                            }
                            Spacer()
                            if remote.isLoading { ProgressView() }
                        }
                    }

                    Section {
                        Picker("Browse", selection: $remote.grouping) {
                            ForEach(RemoteBrowseGrouping.allCases) { grouping in
                                Text(grouping.rawValue).tag(grouping)
                            }
                        }
                        .pickerStyle(.segmented)
                    }

                    switch remote.grouping {
                    case .artists:
                        ForEach(remote.artists) { artist in
                            NavigationLink {
                                RemoteArtistDetailView(artist: artist)
                            } label: {
                                RemoteCollectionRow(
                                    title: artist.name,
                                    subtitle: "\(artist.albums.count) albums • \(artist.tracks.count) tracks",
                                    artworkURL: artist.artworkURL,
                                    artworkBase64: artist.artworkBase64
                                )
                            }
                        }
                    case .albums:
                        ForEach(remote.albums) { album in
                            NavigationLink {
                                RemoteAlbumDetailView(album: album)
                            } label: {
                                RemoteCollectionRow(
                                    title: album.title,
                                    subtitle: album.releaseYear > 0 ? "\(album.artist) • \(album.releaseYear)" : album.artist,
                                    artworkURL: album.artworkURL,
                                    artworkBase64: album.artworkBase64
                                )
                            }
                        }
                    case .songs:
                        ForEach(remote.filteredTracks) { track in
                            Button {
                                Task { await remote.play(track, in: remote.filteredTracks, using: player) }
                            } label: {
                                RemoteTrackRow(track: track, isPlaying: player.currentTrack?.id == track.id)
                            }
                            .buttonStyle(.plain)
                        }
                    }

                    if !remote.isLoading && remote.filteredTracks.isEmpty {
                        ContentUnavailableView(
                            "No Remote Music",
                            systemImage: "music.note.list",
                            description: Text("Refresh the remote library, verify the selected backend, or change the current search.")
                        )
                    }
                }
                .searchable(text: $remote.searchText, prompt: "Search remote music")
                .refreshable { await remote.refresh(using: settings) }
            }
        }
        .navigationTitle("Streaming Library")
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button(action: openLibrary) { Label("Library", systemImage: "chevron.left") }
            }
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button(action: openSettings) { Image(systemName: "server.rack") }
                Button {
                    Task { await remote.refresh(using: settings) }
                } label: {
                    Image(systemName: "arrow.clockwise")
                }
                .disabled(remote.isLoading || settings.streamHost.isEmpty)
            }
        }
        .task {
            if !settings.streamHost.isEmpty && (remote.tracks.isEmpty || remote.lastRefresh == nil) {
                await remote.refresh(using: settings)
            }
        }
        .contentShape(Rectangle())
        .gesture(
            DragGesture(minimumDistance: 45)
                .onEnded { value in
                    if value.startLocation.x < 36 && value.translation.width > 70 { openLibrary() }
                }
        )
    }
}

private struct RemoteArtistDetailView: View {
    @EnvironmentObject private var remote: RemoteLibraryStore
    @EnvironmentObject private var player: PlayerController
    let artist: RemoteArtist

    var body: some View {
        List {
            Section {
                HStack(spacing: 12) {
                    RemoteArtwork(url: artist.artworkURL, base64: artist.artworkBase64, size: 82)
                    VStack(alignment: .leading, spacing: 6) {
                        Text(artist.name).font(.title2.bold())
                        Text("\(artist.albums.count) albums • \(artist.tracks.count) tracks")
                            .foregroundStyle(.secondary)
                        HStack {
                            Button("Play Artist") {
                                Task { await remote.playArtist(artist, using: player) }
                            }
                            .buttonStyle(.borderedProminent)
                            Button("Shuffle") {
                                Task { await remote.playArtist(artist, using: player, shuffle: true) }
                            }
                            .buttonStyle(.bordered)
                        }
                    }
                }
                .padding(.vertical, 6)
            }

            Section("Albums") {
                ForEach(artist.albums) { album in
                    NavigationLink {
                        RemoteAlbumDetailView(album: album)
                    } label: {
                        RemoteCollectionRow(
                            title: album.title,
                            subtitle: album.releaseYear > 0 ? String(album.releaseYear) : "Release date unavailable",
                            artworkURL: album.artworkURL,
                            artworkBase64: album.artworkBase64
                        )
                    }
                }
            }
        }
        .navigationTitle(artist.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct RemoteAlbumDetailView: View {
    @EnvironmentObject private var remote: RemoteLibraryStore
    @EnvironmentObject private var player: PlayerController
    let album: RemoteAlbum

    var body: some View {
        List {
            Section {
                HStack(alignment: .top, spacing: 14) {
                    RemoteArtwork(url: album.artworkURL, base64: album.artworkBase64, size: 118)
                    VStack(alignment: .leading, spacing: 5) {
                        Text(album.title).font(.title2.bold())
                        Text(album.artist).foregroundStyle(.secondary)
                        if album.releaseYear > 0 { Text(String(album.releaseYear)).foregroundStyle(.secondary) }
                        Button {
                            Task { await remote.playAlbum(album, using: player) }
                        } label: {
                            Label("Play Album", systemImage: "play.fill")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }
                .padding(.vertical, 6)
            }

            Section("Tracks") {
                ForEach(album.tracks) { track in
                    Button {
                        Task { await remote.play(track, in: album.tracks, using: player) }
                    } label: {
                        RemoteTrackRow(track: track, isPlaying: player.currentTrack?.id == track.id)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .navigationTitle(album.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct RemoteCollectionRow: View {
    let title: String
    let subtitle: String
    let artworkURL: URL?
    let artworkBase64: String?

    var body: some View {
        HStack(spacing: 11) {
            RemoteArtwork(url: artworkURL, base64: artworkBase64, size: 52)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).lineLimit(1)
                Text(subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
        }
        .padding(.vertical, 2)
    }
}

private struct RemoteTrackRow: View {
    let track: RemoteTrackItem
    let isPlaying: Bool

    var body: some View {
        HStack(spacing: 10) {
            if isPlaying {
                Image(systemName: "waveform")
                    .foregroundStyle(.tint)
                    .frame(width: 18)
            } else {
                Text(track.trackNumber > 0 ? String(track.trackNumber) : "—")
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
                    .frame(width: 18)
            }
            RemoteArtwork(url: track.artworkURL, base64: track.artworkBase64, size: 42)
            VStack(alignment: .leading, spacing: 2) {
                Text(track.title).lineLimit(1)
                Text("\(track.artist) • \(track.album)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 2) {
                Text(formatDuration(track.duration))
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
                if track.fileSizeBytes > 0 {
                    Text(ByteCountFormatter.string(fromByteCount: track.fileSizeBytes, countStyle: .file))
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                }
            }
        }
        .contentShape(Rectangle())
    }
}

private struct RemoteArtwork: View {
    let url: URL?
    let base64: String?
    let size: CGFloat

    var body: some View {
        Group {
            if let base64, let data = Data(base64Encoded: base64), let image = UIImage(data: data) {
                Image(uiImage: image).resizable().scaledToFill()
            } else if let url {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case let .success(image): image.resizable().scaledToFill()
                    case .failure: placeholder
                    default: ZStack { placeholder; ProgressView().controlSize(.small) }
                    }
                }
            } else {
                placeholder
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: max(7, size * 0.09)))
    }

    private var placeholder: some View {
        ZStack {
            RoundedRectangle(cornerRadius: max(7, size * 0.09)).fill(.secondary.opacity(0.15))
            Image(systemName: "music.note").foregroundStyle(.secondary)
        }
    }
}

private func formatDuration(_ duration: Double) -> String {
    guard duration.isFinite, duration > 0 else { return "—:—" }
    let seconds = Int(duration.rounded())
    return String(format: "%d:%02d", seconds / 60, seconds % 60)
}
