# Resonance Alpha 3.5

Version 0.3.5, build 35.

## Native Navidrome / Subsonic / OpenSubsonic support

Alpha 3.5 fixes the Alpha 3.4 protocol mismatch. Alpha 3.4 expected Resonance's custom JSON manifest, while Navidrome exposes the Subsonic/OpenSubsonic REST API.

The Streaming Library settings now include a backend selector:

- **Navidrome / Subsonic / OpenSubsonic**
- **Resonance Manifest**

### Recommended Navidrome configuration

- Backend: **Navidrome / Subsonic / OpenSubsonic**
- Server URL: your HTTPS Navidrome URL or Tailscale hostname
- Port: blank for standard HTTPS, or `443`
- API path: `/rest`
- Username: your Navidrome username
- Password: your Navidrome password

The password is stored in the iOS Keychain. Resonance uses salted Subsonic token authentication and requests JSON responses.

### Navidrome connection and indexing

- Connection testing uses `/rest/ping.view`.
- Album indexing uses paged `/rest/getAlbumList2.view` calls.
- Track metadata uses `/rest/getAlbum.view`.
- Artwork uses `/rest/getCoverArt.view`.
- Playback uses `/rest/stream.view` with `format=raw`.
- Album requests are loaded in small concurrent batches so the interface remains responsive.
- Authenticated stream URLs are kept in memory and are not written to the remote-library cache.
- Navidrome string IDs are retained as stable Resonance track UUIDs.

The existing Streaming Library interface continues to support artist, album, and song browsing, search, artwork, background playback, lock-screen controls, seeking, queue playback, repeat modes, and the configurable forward-buffer target.

## Resonance Manifest backend

The custom Alpha 3.4 protocol is still available. Select **Resonance Manifest** to use `Tools/ResonanceServer.py`.

```bash
python3 -m pip install mutagen
python3 Tools/ResonanceServer.py "/path/to/Music" --port 8080
```

Default manifest settings:

- Port: `8080`
- Manifest path: `/resonance/library.json`
- HTTPS: off for trusted LAN or Tailscale testing unless the server is placed behind HTTPS

## Upgrade notes

Install Alpha 3.5 directly over Alpha 3.4. Do not delete the existing app first.

On first launch after the upgrade, Streaming Library defaults migrate to the Navidrome/Subsonic backend:

- Port `8080` is cleared
- Manifest path `/resonance/library.json` becomes API path `/rest`
- HTTPS is enabled

A custom manifest user can switch the backend back to **Resonance Manifest**, which restores the normal manifest defaults.

## Suggested test plan

1. Open Settings > Streaming Library.
2. Choose **Navidrome / Subsonic / OpenSubsonic**.
3. Enter the HTTPS server URL or Tailscale hostname.
4. Leave Port blank or enter `443`.
5. Enter `/rest` as the API path.
6. Enter the Navidrome username and password.
7. Press **Test Connection** and confirm the server name/version appears.
8. Press **Refresh Remote Library**.
9. Browse Artists, Albums, and Songs and verify artwork and metadata.
10. Play FLAC and MP3 tracks and test seeking, buffering, next/previous, lock-screen controls, and background playback.
11. Restart Resonance and confirm the Keychain credential remains available.
12. Switch to the Resonance Manifest backend and confirm the included companion server still works.

## Compile preflight

Run `Tools/PreflightBuild.sh` on the Mac before device installation. It performs a clean unsigned simulator build with strict concurrency checking.
