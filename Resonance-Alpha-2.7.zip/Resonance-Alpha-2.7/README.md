# Resonance Alpha 2.7

A SwiftUI iPhone music-player prototype with Finder/Files transfer, recursive indexing, SQLite storage, FLAC/Vorbis metadata parsing, embedded artwork, playback queues, favorites, smart collections, playlists, and persistent Resonance metadata edits.

## Install without erasing the library

Install Alpha 2.7 directly over Alpha 2.6 using the same bundle identifier and signing configuration. Do not delete the installed app first. Deleting it removes the app's Documents folder, SQLite database, favorites, recent-play history, playlists, metadata overrides, artist artwork overrides, and imported music.

## New in Alpha 2.7

### Long-press album editing

- Touch and hold an album in the main Albums library, an artist's album grid/list, or the album header.
- Choose **Edit Album Metadata**.
- Album title, album artist, release year, and artwork remain editable.
- Every track title and track number is displayed in a grey read-only reference section.
- Track titles, track numbers, disc numbers, and performing artists are not changed by the album-wide operation.
- The existing album pencil button remains available.

### Long-press artist editing

- Touch and hold an artist tile, artist list row, or the artist header.
- Choose **Edit Artist Metadata**.
- Artist editing is intentionally restricted to:
  - Artist name (or album-artist name while browsing by Album Artists)
  - Artwork used for the artist display
- Renaming an artist updates all tracks represented by that artist entry.
- When a performing artist and album artist originally match, both remain aligned after the rename.
- Artist artwork is stored separately from album artwork, so individual album covers are not replaced.
- Artist artwork can be selected from Photos, removed, or reset to inherit album artwork again.
- Edited artist entries display a small pencil badge.

### Persistence and upgrade behavior

- Artist-display artwork is persisted in Application Support.
- Track metadata overrides continue to use stable track IDs.
- Finder rescans and app upgrades reapply artist and album edits without changing playlist or favorite membership.
- This phase still edits Resonance's library data rather than rewriting the original MP3/FLAC tag blocks.

## Suggested Alpha 2.7 tests

1. Install directly over Alpha 2.6 and verify the existing library, playlists, favorites, and metadata edits remain.
2. Touch and hold an album in the main Albums screen and open its editor.
3. Confirm track titles and track numbers are grey and cannot be edited in the album-wide editor.
4. Rename an album, change its year and artwork, then restart and rescan Resonance.
5. Touch and hold an artist tile and rename the artist.
6. Confirm every represented track moves under the new artist name while album names and track positions remain unchanged.
7. Select custom artist artwork and confirm it appears on the artist tile, artist list row, artist header, and All Albums tile without replacing album covers.
8. Use **Use Album Artwork Again** and confirm the artist display returns to inherited album artwork.
9. Browse by **Album Artists**, edit one entry, and verify only the album-artist field changes for the represented tracks.
10. Confirm favorites, playlists, playback, and Finder scanning continue to work after these edits.

## Compatibility baseline

Alpha 2.7 preserves the successful Alpha 2.1–2.6 compatibility fixes, including the two current-SDK `MetadataReader.swift` corrections, asynchronous AV metadata loading, Swift 6-safe `AVAudioPlayerDelegate` proxying, actor-safe database schema creation, safe Core Foundation ownership, Finder File Sharing, document-relative paths, and the resolved orientation and `withUnsafeBytes` warnings.
